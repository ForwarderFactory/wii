<?php
$text = $_GET['t'];

$image = imagecreate(68,25);
$white = imagecolorallocate($image,255,255,255);
$gray = imagecolorallocate($image,200,200,200);
$lightgray = imagecolorallocate($image,230,230,230);
$black = imagecolorallocate($image,1,1,1);

imagerectangle($image,0,0,67,24,$black);
imagerectangle($image,1,1,66,23,$gray);
imagerectangle($image,2,2,65,22,$lightgray);
imagerectangle($image,3,3,64,21,$lightgray);

imagestring($image,4,6,5,$text,$black);

header("Content-Type: Image/PNG");
imagepng($image);
?>