<?php
$game = urldecode($_GET['game']);
$resolution = $_GET['resolution'];
$resolution = explode("_",$resolution);
$x = $resolution[0];
$y = $resolution[1];
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<head><meta http-equiv="Content-Type" content="text/html;charset=utf-8" >
<title>Arcade - Game</title>
<style type="text/css">
#main {
	width: 608px;
	margin-left: auto;
	margin-right: auto;
}
</style>
</head>
<body>
<div id="main">
<center>
<!--Yes, I know, the dreaded <center> tag, but we're dealing with embedding flash here.
<embed> is not actually W3C valid, and flash is well known for pissing all over everything.
I could use other methods to include the flash that would allow me to center in a better
fashion, but I feel the ability to force a movie to start in low quality for play on the
Wii overshadows any need to be valid markup.-->
<object width="<?php echo $x; ?>" height="<?php echo $y; ?>" >
<param name="movie" value="./flash/<?php echo $game; ?>">
<param name="quality" value="low">
<param name="play" value="true">
<embed src="./flash/<?php echo $game; ?>" quality="low" play='true' width="<?php echo $x; ?>" height="<?php echo $y; ?>" TYPE="application/x-shockwave-flash"></embed>
</embed>
</object> 

</center>
</div>