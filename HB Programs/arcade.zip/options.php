<?php
$file = $_GET['file'];

function resolutions($list) {
	global $file;
	foreach($list as $resolution) {
		$resolution_dis = str_replace("_","x",$resolution);
		echo "<a href=\"./display.php?game=$file&resolution=$resolution\"><img src=\"./button.php?t=$resolution_dis\"></a>&nbsp;&nbsp;&nbsp;";
	}
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<head><meta http-equiv="Content-Type" content="text/html;charset=utf-8" >
<title>Arcade - Size</title>
<style type="text/css">
#main {
	width: 390px;
	margin-left: auto;
	margin-right: auto;
}
#title {
	text-align: center;
	font-size: 125%;
	font-weight: bold;
}
img {
	border: none
}
</style>
</head>
<body>

<div id="main">
<div id="title">4:3 (Standard)</div>

<?php
$list = array('600_450','500_375','400_300','300_225','200_150');
resolutions($list);
?>

<br><br>
<div id="title">16:9 (Widescreen)</div>

<?php
$list = array('600_338','500_281','400_225','300_169','200_113');
resolutions($list);
?>

<br><br>
<div id="title">2:3 (Tallscreen)</div>

<?php
$list = array('300_450','250_375','200_300','150_225','100_150');
resolutions($list);
?>

</div>
</body>