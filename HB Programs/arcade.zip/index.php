<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<head><meta http-equiv="Content-Type" content="text/html;charset=utf-8" >
<title>Arcade - Main</title>
<style type="text/css">
a:link { color: #000099; }
a:visited { color: #000099; }
a:active { color: #000099; }
a { text-decoration: none; }

td.c1 { background-color: #f9f9ff; }
td.c2 { background-color: #e9efff; }

#main {
	width: 600px;
	margin-left: auto;
	margin-right: auto;
}
#title {
	text-align: center;
	font-size: 125%;
	font-weight: bold;
}
</style>
</head>
<body>
<div id="title">Home Flash Arcade</div>
<div id="main">
<table>

<?php
$dir = @opendir("./flash");

while ($file = readdir($dir)) {
	if ($file != "." && $file != "..") {
		$number++;
		if ($row == 0){ echo "<tr><td class=\"c1\">"; $row = 1; } else { echo "<tr><td class=\"c2\">"; $row = 0; }
		$filename = str_replace(".swf","",$file);
		$filename = str_replace("_"," ",$filename);
		$file = urlencode($file);
		echo "<a href=\"options.php?file=$file\">", $filename, "</a></td></tr>";
	}
}
closedir($dir);
?>

</table>
</div>
</body>