The Homebrew Channel
1.0.5
http://hbc.hackmii.com
http://wiibrew.org

2009/09/29

In this archive, you will find the following files:

* README.txt                    This file
* boot.dol                      Main channel installer
* wiiload/                      USBGecko / TCP loader client
*       win32/wiiload.exe           Precompiled binary for Windows
*       lin32/wiiload               Precompiled binary for Linux (x86)
*       osx/wiiload                 Precompiled binary for Mac OS X (Universal)
*       wiiload.tgz                 Source code

       REMINDER ABOUT ELF FILES:

Old ELF files were incorrect and will not work. Please use DOL files or
recompile with the latest version of devkitPPC. You can use the following
command to convert a broken ELF file to a DOL file:

   powerpc-gekko-objcopy -O binary boot.elf boot.dol

       Update instructions:

If you have previously installed The Homebrew Channel, you can update it. If
this is the first time you are installing it, see below for Installation
Instructions. The easiest way to update is using the built-in Online Update
functionality. Simply configure the WiFi network settings for your Wii for
proper Internet connectivity, and boot up the channel. If the connection is
established, you'll see an opaque white (not semitransparent) world icon
in the lower right corner, and an update prompt will automatically appear.
Accept it to begin downloading the update. If you cannot or do not want to
connect your Wii to the Internet, simply run the boot.dol file using any
homebrew booting method. For example, you can upload it using wiiload or
you can make a directory inside /apps (for example, /apps/Update) and copy
boot.dol there. Then, simply run it from the previous version of the channel.

       Installation instructions:

The suggested way to install the Homebrew Channel is by using Zelda: The
Twilight Pricess with the Twilight Hack, which is available at
http://wiibrew.org/index.php?title=Twilight_Hack.  After installing the
Twilight Hack savegame, format an SD card (as FAT16; must be <=2GB, non-SDHC)
and place the contents of this distribution in the root directory of that card.
Boot.dol must be in the root directory, and you must have a directory named
"apps" inside the root directory.  (You can delete the wiiload files from the
SD card, as they are not needed.)

Execute the Twilight Hack, and it will load and run boot.dol from the SD card.
You will be presented with a disclaimer screen about the dangers of installing
this hack (discussed here as well, below); follow the instructions.  After this
process has completed, you should have a new Homebrew Channel in your System
Menu.  You may safely delete the boot.dol file from the SD card; it is no
longer needed.

      Adding and customizing apps:

All user applications should be stored in their own subdirectory inside of
apps/; some examples have been provided.  Each subdirectory should have at
least three files; ScummVM will be used as an example.

* apps/ScummVM/boot.[dol|elf]   main executable to be loaded
* apps/ScummVM/icon.png         icon to be displayed in the Homebrew Channel
                                    Menu; should be 128 x 48
* apps/ScummVM/meta.xml         XML description of the channel.  This format
                                    will change for future releases of the
                                    Homebrew channel, but we will try to remain
                                    backwards-compatible.   See the included
                                    files for information on what data should
                                    be included in this file.

      Staying current with new releases:

Relax, you will not need to do anything to keep up with new releases of the
Homebrew Channel.  When a new version is available, a message will appear
giving you the option to download and install the new version, if your Wii
is configured to connect to the Internet.

      Uninstallation:

You may uninstall the channel as you would any other channel, by using the Data
Management screen of the Wii Menu. Erasing every last trace of The Homebrew
Channel is not practical on a complex system such as the Wii.  If a need arises,
we will develop a more thorough uninstaller application.

***************************************************************

RISKS, CAUTIONS, and SYSTEM UPDATES:

Any persistent modification to your system (meaning, anything that does not go
away when you turn off your Wii) carries some inherent risk.  We have worked
hard to avoid this whereever possible, but we are unable to test all possible
configurations.

We do, however, believe that our channel is safer to install than any other
homebrew channel that has been released, and once you have installed it we hope
you will never need to install another!

A special note about System Updates:
The Homebrew Channel relies on certain security flaws (fakesigned TMD and
ticket) that exist in older versions of the Wii's software.  The most recent
update as of this writing (dated 23 October 2008) was the first update to
completely correct these flaws.  This version of The Homebrew Channel
incorporates a workaround for this (by exploiting a different flaw), and will
work with this version of the Wii's software.  However, this new flaw may also
be fixed in the future. When it is, you may not be able to install this
channel for the first time.

The effects on users who have already installed the channel depend on the
particular nature of the update.  Up until now, they have not been affected
and The Homebrew Channel continued to work normally; however, this might
change in the future.  Excluding a deliberate attempt to cause harm to users,
we believe there is no danger to your system, even if you upgrade.

That having been said, we are releasing this software to you in the hope that
you will find it useful.  We can not and will not offer you any warranty on the
functionality of this software, or its impact on your Wii System.   We have
made our best effort to ensure its safety and to honestly explain the risks
involved, but the decision (and responsibility) is ultimately up to you.

We recommend that you check for news at http://wiibrew.org about compatibility
with new Nintendo System Updates before installing them; we will test each
update as soon as it is publicly available, and will announce whether any
issues have been discovered.

Note that the above information applies solely to The Homebrew Channel itself,
and not to any applications launched from it. We cannot be held responsible for
any damage caused by these applications, nor do you get bitching rights if
something happens. As The Homebrew Channel is delivered with no warranty
whatsoever, we also cannot be held responsible for any damage caused by it.
However, in that case, you do get bitching rights.

***************************************************************

SALES AND SCAMS

The Homebrew Channel is not licensed for redistribution, sale, or bundling.
We reserve the right to request the removal of any redistributed copies of
this software. Any kind of sale, bundling, or association with commercial
activity is strictly forbidden.

Copyright (C) 2008, 2009 Team Twiizers, all rights reserved.

