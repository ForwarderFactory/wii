Wiibrew.org Homebrew Channel
Beta 7 (first public beta)

2008/05/23

In this archive, you will find the following files:

* README.txt                    This file
* boot.elf                      Main channel installer
* wiiload/                      USBGecko / TCP loader client
*       win32/wiiload.exe           Precompiled binary for Windows
*       lin32/wiiload               Precompiled binary for Linux (x86)
*       osx/wiiload                 Precompiled binary for Mac OS X (Universal)
*       wiiload.tgz                 Source code

       Installation instructions:

The suggested way to install the Homebrew Channel is by using Zelda: The
Twilight Pricess with the Twilight Hack, which is available at
http://wiibrew.org/index.php?title=Twilight_Hack.  After installing the
Twilight Hack savegame, format an SD card (as FAT16; must be <=2GB, non-SDHC)
and place the contents of this distribution in the root directory of that card.
Boot.elf must be in the root directory, and you must have a directory named
"apps" inside the root directory.  (You can delete the wiiload files from the
SD card, as they are not needed.)

Execute the Twilight Hack, and it will load and run boot.elf from the SD card.
You will be presented with a disclaimer screen about the dangers of installing
this hack (discussed here as well, below); follow the instructions.  After this
process has completed, you should have a new Homebrew Channel in your System
Menu.  You may safely delete the boot.elf file from the SD card; it is no
longer needed.

      Adding and customizing apps:

All user applications should be stored in their own subdirectory inside of
apps/; some examples have been provided.  Each subdirectory should have at
least three files; ScummVM will be used as an example.

* apps/ScummVM/boot.[dol|elf]   main executable to be loaded
* apps/ScummVM/icon.png         icon to be displayed in the Homebrew Channel
                                    Menu; should be 128 x 48
* apps/ScummVM/meta.xml         XML description of the channel.  This format
                                    will change for future releases of the
                                    Homebrew channel, but we will try to remain
                                    backwards-compatible.   See the included
                                    files for information on what data should
                                    be included in this file.

      Staying current with new releases:

Relax, you will not need to do anything to keep up with new releases of the
Homebrew Channel.  When a new version is available, a message will appear
giving you the option to download and install the new version.

      Uninstallation:

You may uninstall the channel as you would any other channel, by using the Data
Management screen of the Wii Menu.

***************************************************************

RISKS, CAUTIONS, and SYSTEM UPDATES:

Any persistent modification to your system (meaning, anything that does not go
away when you turn off your Wii) carries some inherent risk.  We have worked
hard to avoid this whereever possible, but we are unable to test all possible
configurations.

We do, however, believe that our channel is safer to install than any other
homebrew channel that has been released, and once you have installed it we hope
you will never need to install another!

A special note about System Updates:
The Homebrew Channel relies on certain security flaws (fakesigned TMD and
ticket) that may eventually be fixed in future versions of the Wii System
Software.  When these flaws are fixed, you may not be able to install this
channel for the first time.

It is not clear what will happen to users who have already installed this
channel.  We have done extensive simulation testing with the current System
Menu and the (currently dormant) IOS37, and we believe there is no danger to
your system, even if you upgrade.

That having been said, we are releasing this software to you in the hope that
you will find it useful.  We can not and will not offer you any warranty on the
functionality of this software, or its impact on your Wii System.   We have
made our best effort to ensure its safety and to honestly explain the risks
involved, but the decision (and responsibility) is ultimately up to you.

We recommend that you check for news at http://wiibrew.org about compatibility
with new Nintendo System Updates before installing them; we will test each
update as soon as it is publicly available, and will announce whether any
issues have been discovered.

