CHANGELOG 1.1 :

* Added rumble support.
* Added possibility to change the font. 
The font must be font.png and must be 1024*8 in "WiiHome" folder.
* Added POWER button support (without "exception (dsi) occured!")
* Added possibility to add a music in mp3 format. T
he music must be music.mp3 in "WiiHome" folder.
* Improvements in memory manager. 

Tutorial : Install Wii Home

* Place WiiHome.dol at the root of the SD card
* Go to preloader (0.27 minimum)
* Click on "settings"
* Change "autoboot" to "file"
* Change "return to" to "Systemmenu"
* Click on "save settings"
* Back to home and click on "install/load dol file"
* Select "WIIHOME.DOL" and press A button
* Turn off and turn on the Wii
* Congratulations !

Tutorial : Themes

Themes are located in the folder WiiHome at the root of the SD / SDHC. 
The theme images files must be in PNG format. Here is the list of files:

* background.png : background. The image must be 640*480.
* button.png : button. The image must be 500*100.
* button_selected.png : button selected. The image must be 500*100.
* font.png : font. The image must be 1024*8.
* music.mp3 : music.

To have a transparent background, the color pink is not needed. A simple background transparent is 
enough. The alpha transparency is supported. Remember to fill the theme.txt file to enter your 
author name, etc ...