+------------------------------------------+
|   [+] Custom IOS Installer (v36 rev 05)  |
|       developed by Waninkoko             |
+------------------------------------------+
|         wwww.teknoconsolas.info          |
+------------------------------------------+


[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.


[ DESCRIPTION ]:

- This is a Custom IOS, an IOS modified to add some new features
  not available in the official IOS.

  This IOS has been made to be used ONLY with homebrew software.

  The Custom IOS installs as IOS249 and it does not modify any other
  IOS so it is secure to install.


[ REQUISITES ]:

- "IOS36-64-v1042.wad" original WAD file.


[ HOW TO INSTALL IT ]:

- Copy "IOS36-64-v1042.wad" file to the root of a SD card.
- Insert the SD card on your Wii.
- Run the installer.


[ KUDOS ]:

- Team Twiizers and devkitPRO devs for their great work in libogc.
- All the betatesters.
- nitrotux, for his IOS5.
- neimod, for the Custom IOS module.