+------------------------------------------+
|   [+] Custom IOS Installer (v36 rev 05)  |
|       developed by Waninkoko             |
+------------------------------------------+
|         www.teknoconsolas.info           |
+------------------------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DA�O EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- Esto es un Custom IOS, un IOS modificado para a�adir nuevas
  caracteristicas no disponibles en el IOS oficial.

  Este IOS ha sido creado para ser usado UNICAMENTE con software
  casero.

  El Custom IOS se instala como IOS249 y no modifica ningun otro
  IOS por lo que es seguro de instalar.


[ REQUISITOS ]:

- El fichero WAD "IOS36-64-v1042.wad" original.


[ COMO INSTALARLO ]:

- Copia el fichero "IOS36-64-v1042.wad" a la raiz de una tarjeta SD.
- Inserta la tarjeta SD en tu Wii.
- Ejecuta el instalador.


[ KUDOS ]:

- Team Twiizers y devkitPRO devs por su gran trabajo en libogc.
- Todos los betatesters.
- nitrotux, por su IOS5.
- neimod, por el Custom IOS module.
