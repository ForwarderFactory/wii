+-------------------------------------+
|   [+] Custom IOS Uninstaller v1.1   |
|       developed by Waninkoko        |
+-------------------------------------+
|       www.teknoconsolas.info        |
+-------------------------------------+


[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.


[ DESCRIPTION ]:

- This application allows you to uninstall any Custom IOS installed
  in your Wii console.


[ HOW TO USE ]:

- Run the application with any method to load homebrew.


[ NOTES ]:

- This uninstaller works only with Custom IOS37 rev 03 or higher.


[ KUDOS ]:

- Team Twiizers and devkitPRO devs for their great work in libogc.
- All the betatesters.
- nitrotux, for his IOS5.
