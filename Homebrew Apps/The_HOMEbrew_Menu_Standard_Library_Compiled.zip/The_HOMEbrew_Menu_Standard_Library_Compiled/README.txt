Credits:

PinballWizard - Original concept and design

Warpedflash - Artowrk

drmr - hand artworks

Arikado - Coding

Special Thanks: Tantric

More info: http://wiibrew.org/wiki/The_HOMEbrew_Menu_Standard_Library