#ifndef _HBMENUHEAD_H_

//Include Buffers
#include "background_png.h"
#include "logo_png.h"
#include "returntoloader_png.h"
#include "returntowiimenu_png.h"
#include "shutdown_png.h"
#include "reset_png.h"
#include "irimage1_png.h"
#include "irimage2_png.h"
#include "irimage3_png.h"
#include "irimage4_png.h"
#include "syncimage1_png.h"
#include "syncimage2_png.h"
#include "syncimage3_png.h"
#include "syncimage4_png.h"
#include "syncimageb_png.h"

using namespace wsp;

//Prototypes
void homemenu(GameWindow *gwd);//Displays the menu


#endif



	
