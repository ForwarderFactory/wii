+--------------------------------------------------+
| Wii Duplicated Channel Remover v2.1 by Waninkoko |
+--------------------------------------------------+
|              www.teknoconsolas.info              |
+--------------------------------------------------+

+--------------+
| DESCRIPCION: |
+--------------+

Esta aplicacion elimina los canales duplicados que se instalan tras actualizar la
Wii con un juego de diferente region.


+--------------+
| COMO USARLO: |
+--------------+

Simplemente ejecuta la aplicacion y autodetectara los canales duplicados y los eliminara.


+--------+
| NOTAS: |
+--------+

NOTA IMPORTANT: ��Usa la version especifica para tu Wii!!
DISCLAIMER:     No me hago responsable de los posibles da�os que puedan ocurrir.


+--------+
| KUDOS: |
+--------+

bushing, marcan, pistu and Vasco_Almeida.
