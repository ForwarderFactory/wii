+-----------------------------------+
| WAD Uninstaller v1.1 by Waninkoko |
+-----------------------------------+
|       www.teknoconsolas.info      |
+-----------------------------------+


+--------------+
| DESCRIPTION: |
+--------------+

This application uninstalls COMPLETELY (removes tickets
and contents) from the Wii the specified titles.


+-------------+
| HOW TO USE: |
+-------------+

1. Create a folder called "wad" in the root of the SD card.
2. Copy the WADs you want to uninstall in the "wad" folder.
3. Run this application.


+--------+
| KUDOS: |
+--------+

- bushing and marcan, for their help.
- Everybody who helped me in the testing process.
