
     ______ ______________     ______  __________
    (______)     ___     /____(______)_\   _____/___.
    |      |      |/    /     |      |  \____       |
    |______|______|\__________|______|______________|spot 

                      bring you in 2008


                       HiivelyPlay 2.0


      Play HivelyTracker and AHX songs on your Wii!
               * NOW WITH 400% MORE AWESOME *


                     Code: Xeron/IRIS
                 Hively logo: Spot/Up Rough


                http://www.hivelytracker.com
                    http://www.irishq.dk


How to install it:

1) Get and install the homebrew channel
2) Copy the contents of the "SDCard" directory to the root
   of your SDCard
3) Copy any additional AHX or HVL files you want into
   "/hvltunes" on the SDCard
4) Go to the homebrew channel
5) Select HiivelyPlay!

