+-------------------------------+
| WAD Manager v1.0 by Waninkoko |
+-------------------------------+
|    www.teknoconsolas.info     |
+-------------------------------+


+--------------+
| DESCRIPCION: |
+--------------+

WAD Manager es una aplicacion para (des)instalar paquetes WAD.

La aplicacion muestra todos los paquetes WAD disponibles en la
tarjeta SD para asi poder elegir cuales (des)instalar.

Incluye soporte para el Wiimote.


+--------------+
| COMO USARLO: |
+--------------+

1. Crea un directorio llamado "wad" en la raiz de la tarjeta SD.
2. Copia todos los paquetes WAD en el directorio creado en el paso 1.
3. Ejecuta la aplicacion con cualquier metodo para cargar homebrew.


+--------+
| KUDOS: |
+--------+

- bushing and marcan (el canal homebrew es muy bueno)
- todos mis testeadores (pistu, SoraK05, danny.ml...)
