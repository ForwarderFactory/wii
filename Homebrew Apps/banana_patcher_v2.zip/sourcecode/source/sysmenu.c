#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <sdcard/wiisd_io.h>

#include "state.h"
#include "certs.h"
#include "fat.h"
#include "wiibasics.h"

/* Externs */
extern void unstub_start(u32);

/* Dol Header structure */
typedef struct {
	u32 textoff[7];
	u32 dataoff[11];
	u8 *textmem[7];
	u8 *datamem[11];
	u32 textsize[7];
	u32 datasize[11];
	u8 *bssmem;
	u32 bsssize;
	u32 entry;
	u32 unused[7];
} dolhdr;

/* Ticket structure */
typedef struct {
	sig_rsa2048 signature;
	tik tik_data;
} ticket;

/* Constants */
#define SYSMENU_ADDR		0x8132FF80
#define SYSMENU_LEN		0x380000
#define SYSMENU_TITLEID		0x100000002ULL

// Preloader-style hacks file
#define HACKS_FILE "sd:/banana_hacks.txt"

//Color constants
#define BLACK	0
#define WHITE	7

//Predefined hacks
#define MAX_PREDEFINED_SM					11
#define REMOVE_NO_COPY_PROTECTION_NVALUES	9
#define NO_HEALTH_CHECK_NVALUES				1
#define MOVE_DISC_CHANNEL_NVALUES			1
#define REGIONFREE_GC_NVALUES				2

struct predef_hacks{
	u32 smversion;
	u8 realVersion;
	char region;

	u32 remove_no_copy_protection[REMOVE_NO_COPY_PROTECTION_NVALUES*2];
	u32 no_health_check[NO_HEALTH_CHECK_NVALUES*2];
	u32 move_disc_channel[MOVE_DISC_CHANNEL_NVALUES*2];
	u32 region_free_gc[REGIONFREE_GC_NVALUES*2];
};

const struct predef_hacks predefinedSMs[MAX_PREDEFINED_SM]={
	{//4.2U
		481, 42, 'U',

		//Remove no copy protection
		{0x813C55EC,0x813C55F0,0x8134E260,0x815C2624,0x81353F5C,0x8134E270,0x8134E274,0x8134E278,0x8134E27C,
		0x7C000000,0x4182001C,0x7C000000,0x38600001,0x3BE00000,0x801C0024,0x5400003C,0x901C0024,0x48000018},

		//No health check
		{0x81656FF4,
		0x81409C9C},

		//Move disc channel
		{0x813AFC00,
		0x60000000},

		//Region free GC
		{0x8137D90C,0x8137D910,
		0x900DA5D8,0x38000032
		}
	},
	{//4.2E
		482, 42, 'E',

		//Remove no copy protection
		{0x813C56E8,0x813C56EC,0x8134E2D4,0x815C2720,0x81353FD0,0x8134E2E4,0x8134E2E8,0x8134E2EC,0x8134E2F0,
		0x7C000000,0x4182001C,0x7C000000,0x38600001,0x3BE00000,0x801C0024,0x5400003C,0x901C0024,0x48000018},

		//No health check
		{0x816572B4,
		0x81409D98},

		//Move disc channel
		{0x813AFCFC,
		0x60000000},

		//Region free GC
		{0x8137D9B4,0x8137D9B8,
		0x900DA5D8,0x38000032}
	},
	{//4.2J
		480, 42, 'J',

		//Remove no copy protection
		{0x813C493C,0x813C4940,0x8134D740,0x815EB564,0x8135343C,0x8134D750,0x8134D754,0x8134D758,0x8134D75C,
		0x7C000000,0x4182001C,0x7C000000,0x38600001,0x3BE00000,0x801C0024,0x5400003C,0x901C0024,0x48000018},

		//No health check
		{0x816878D4,
		0x81408F88},

		//Move disc channel
		{0x813AEEEC,
		0x60000000},

		//Region free GC
		{0x8137CDC0,0x8137CDC4,
		0x900DA5D8,0x38000032}
	},
	{//4.2K
		486, 42, 'K',

		//Remove no copy protection
		{0x813C49A4,0x813C49A8,0x8134D6F8,0x8159B388,0x813533F4,0x8134D708,0x8134D70C,0x8134D710,0x8134D714,
		0x7C000000,0x4182001C,0x7C000000,0x38600001,0x3BE00000,0x801C0024,0x5400003C,0x901C0024,0x48000018},

		//No health check
		{0x8162BEBC,
		0x8140915C},

		//Move disc channel
		{0x813AEF40,
		0x60000000},

		//Region free GC
		{0x8137CCA0,0x8137CCA4,
		0x900DA5D8,0x38000032}
	},
	{//4.1J
		448, 41, 'J',

		//Remove no copy protection
		{0x813C40D8,0x813C40DC,0x8134D6C0,0x815EABAC,0x81353E64,0x8134D6D0,0x8134D6D4,0x8134D6D8,0x8134D6DC,
		0x7C000000,0x4182001C,0x7C000000,0x38600001,0x3BE00000,0x801C0024,0x5400003C,0x901C0024,0x48000018},

		//No health check
		{0x81686934,
		0x814086BC},

		//Move disc channel
		{0x813AE770,
		0x60000000},

		//Region free GC
		{0x8137C930,0x8137C934,
		0x900DA5D8,0x38000032}
	},
	{//4.1U
		449, 41, 'U',

		//Remove no copy protection
		{0x813C4D88,0x813C4D8C,0x8134E1E0,0x815C1C70,0x81353DF0,0x8134E1F0,0x8134E1F4,0x8134E1F8,0x8134E1FC,
		0x7C000000,0x4182001C,0x7C000000,0x38600001,0x3BE00000,0x801C0024,0x5400003C,0x901C0024,0x48000018},

		//No health check
		{0x81656084,
		0x814093D4},

		//Move disc channel
		{0x813AF484,
		0x60000000},

		//Region free GC
		{0x8137D47C,0x8137D480,
		0x900DA5D8,0x38000032}
	},
	{//4.1E
		450, 41, 'E',

		//Remove no copy protection
		{0x813C4E84,0x813C4E88,0x8134E254,0x815C1D6C,0x81353E64,0x8134E264,0x8134E268,0x8134E26C,0x8134E270,
		0x7C000000,0x4182001C,0x7C000000,0x38600001,0x3BE00000,0x801C0024,0x5400003C,0x901C0024,0x48000018},

		//No health check
		{0x81656344,
		0x814094D0},

		//Move disc channel
		{0x813AF580,
		0x60000000},

		//Region free GC
		{0x8137D524,0x8137D528,
		0x900DA5D8,0x38000032}
	},
	{//4.0U
		417, 40, 'U',

		//Remove no copy protection
		{0x8134E1E0,0x8134E1F0,0x8134E1F4,0x8134E1F8,0x8134E1FC,0x81353DF8,0x813C4C88,0x813C4C8C,0x815C1B48,
		0x7C000000,0x801C0024,0x5400003C,0x901C0024,0x48000018,0x3BE00000,0x7C000000,0x4182001C,0x38600001},

		//No health check
		{0x81655F04,
		0x814092D4},

		//Move disc channel
		{0x813AF388,
		0x60000000},

		//Region free GC
		{0x00000000,0x00000000,
		0x00000000,0x00000000}
	},
	{//4.0E
		418, 40, 'E',

		//Remove no copy protection
		{0x813C4D84,0x813C4D88,0x8134E254,0x815C1C44,0x81353E6C,0x8134E264,0x8134E268,0x8134E26C,0x8134E270,
		0x7C000000,0x4182001C,0x7C000000,0x38600001,0x3BE00000,0x801C0024,0x5400003C,0x901C0024,0x48000018},

		//No health check
		{0x816561E4,
		0x814093D0},

		//Move disc channel
		{0x813AF484,
		0x60000000},

		//Region free GC
		{0x00000000,0x00000000,
		0x00000000,0x00000000}
	},
	{//3.2U
		289, 32, 'U',

		//Remove no copy protection (only 8 hacks, repeating the last one)
		{0x813BD0F0,0x8134AA38,0x815992E8,0x81350370,0x8134AA48,0x8134AA4C,0x8134AA50,0x8134AA54,0x8134AA54,
		0x7C000000,0x7C000000,0x38600001,0x3BE00000,0x801D0024,0x5400003C,0x901D0024,0x48000018,0x48000018},

		//No health check
		{0x81626428,
		0x813EACFC},

		//Move disc channel
		{0x813A7D88,
		0x60000000},

		//Region free GC
		{0x81377838,0x8137783C,
		0x900DA5D8,0x38000032}
	},
	{//3.2E
		290, 32, 'E',

		//Remove no copy protection (only 8 hacks, repeating the last one)
		{0x813BD1EC,0x8134AAAC,0x815993E4,0x813503E4,0x8134AABC,0x8134AAC0,0x8134AAC4,0x8134AAC8,0x8134AAC8,
		0x7C000000,0x7C000000,0x38600001,0x3BE00000,0x801D0024,0x5400003C,0x901D0024,0x48000018,0x48000018},

		//No health check
		{0x81626708,
		0x813EADF8},

		//Move disc channel
		{0x813A7E84,
		0x60000000},

		//Region free GC
		{0x813778E0,0x813778E4,
		0x900DA5D8,0x38000032}
	}
};

char* substr(char* oldString,int start,int length){
	char *newString=malloc(length*(sizeof(char))+1);
	int i;
	for(i=0;i<length;i++){
		newString[i]=oldString[start+i];
	}
	newString[length]='\0';

	return newString;
}


bool Read_And_Apply_Patches(u32 smversion){
	char *archivoLeido=NULL;
	__io_wiisd.startup();
	s32 ret=fatMountSimple("sd", &__io_wiisd);
	if(ret<0){
		printf("* ERROR: I can't initialize SD. No card inserted?\n");
		wait_anyKey();
		return false;
	}

	ret = Fat_ReadFile(HACKS_FILE, (void *)&archivoLeido);

	fatUnmount("sd");
	__io_wiisd.shutdown();

	if(ret>0){
		u32 start=0;
		u32 length=0;
		u32 maxLength=strlen(archivoLeido);
		u32 codesStack[32];
		u8 stackIn=0;
		u8 stackOut=0;
		printf("* %s found.",HACKS_FILE);
		bool enabled=false;
		bool endOfFile=false;
		while(!endOfFile){
			length++;
			if(start+length==maxLength){
				endOfFile=true;
			}
			if((archivoLeido[start+length]==13 && archivoLeido[start+length+1]==10) || endOfFile){
				char* cortado=substr(archivoLeido,start,length);
				if(cortado[0]=='[' && cortado[length-1]==']'){
					if(enabled){
						printf("OK!");
					}
					printf("\n  * Found %s patch... ",cortado);
					stackIn=0;
					stackOut=0;
					enabled=true;
				}else if(length>8){
					char* tag=substr(cortado,0,7);
					if(strcmp(tag,"version")==0){
						int codeversion=atoi(substr(cortado,8,length-8));
						if(smversion!=codeversion){
							enabled=false;
							printf(" Invalid version.");
						}
					}else if(strcmp(tag,"offset=")==0){
						int i;
						for(i=7;i<length;i+=11){
							u32 hex=0;
							sscanf(substr(cortado,i,10), "%X", &hex);
							codesStack[stackIn++]=hex;
						}
					}else if(strcmp(tag,"value=0")==0 && enabled==true){
						int i;
						for(i=6;i<length;i+=11){
							u32 offset=codesStack[stackOut++];
							u32 value=0;
							sscanf(substr(cortado,i,10), "%X", &value);
							*(u32 *)offset=value;
						}
					}
					
				}
				
				start=start+length+2;
				length=0;
			}
		}
		if(enabled){
			printf("OK!");
		}

		free(archivoLeido);
		return true;
	}else{
		return false;
	}
}



bool predefined_patches_menu(u32 smversion){
	u8 i,j;
	bool found=false;
	printf("* Custom hacks file (%s) not found.\n",HACKS_FILE);
	printf("* Trying to use predefined hacks...\n");
	for(i=0;i<MAX_PREDEFINED_SM;i++){
		if(smversion==predefinedSMs[i].smversion){
			found=true;
			break;
		}
	}
	if(found){
		bool noCopyProtectionHack=true;
		bool healthScreenHack=true;
		bool moveDiscChannelHack=true;
		bool gamecubeRegionFreeHack=false;
		u8 uno=predefinedSMs[i].realVersion/10;
		u8 dos=predefinedSMs[i].realVersion%10;

		for(;;){
		    printf("\x1b[2J"); //clear console
			printf("\x1b[%u;%um", BLACK+30,0); //set title colors
			printf("\x1b[%u;%um", WHITE+40,1);
			printf("                       \n");
			printf("    Banana  Patcher    \n");
			printf("   PREDEFINED  HACKS   \n");
			printf("                       \n");
			printf("\x1b[%u;%um", BLACK+40,0); //restore console colors
			printf("\x1b[%u;%um", WHITE+30,1);
			fflush(stdout);
			printf("\nThere are predefined hacks for %d.%d%c.\n\n\n",uno,dos,predefinedSMs[i].region);

			printf("Use the D-PAD to enable/disable predefined hacks.\n");
			printf("Press A to reboot your Wii with the enabled hacks.\n\n");


			printf("[UP]     ");
			if(noCopyProtectionHack)
				printf("Remove no copy protection");
			printf("\n[LEFT]   ");
			if(healthScreenHack)
				printf("No health check");
			printf("\n[RIGHT]  ");
			if(moveDiscChannelHack)
				printf("Move disc channel");
			printf("\n[DOWN]   ");
			if(gamecubeRegionFreeHack)
				printf("Region Free GC");

			u32 pressed=wait_anyKey();
			if(pressed==WPAD_BUTTON_UP)
				noCopyProtectionHack=!noCopyProtectionHack;
			else if(pressed==WPAD_BUTTON_LEFT)
				healthScreenHack=!healthScreenHack;
			else if(pressed==WPAD_BUTTON_RIGHT)
				moveDiscChannelHack=!moveDiscChannelHack;
			else if(pressed==WPAD_BUTTON_DOWN && predefinedSMs[i].region_free_gc[0]!=0x00000000)
				gamecubeRegionFreeHack=!gamecubeRegionFreeHack;
			else if(pressed==WPAD_BUTTON_A)
				break;
		}

		if(noCopyProtectionHack)
			for(j=0;j<REMOVE_NO_COPY_PROTECTION_NVALUES;j++){
				u32 offset=predefinedSMs[i].remove_no_copy_protection[j];
				u32 value=predefinedSMs[i].remove_no_copy_protection[REMOVE_NO_COPY_PROTECTION_NVALUES+j];
				*(u32 *)offset=value;
			}

		if(healthScreenHack)
			for(j=0;j<NO_HEALTH_CHECK_NVALUES;j++){
				u32 offset=predefinedSMs[i].no_health_check[j];
				u32 value=predefinedSMs[i].no_health_check[NO_HEALTH_CHECK_NVALUES+j];
				*(u32 *)offset=value;
			}

		if(moveDiscChannelHack)
			for(j=0;j<MOVE_DISC_CHANNEL_NVALUES;j++){
				u32 offset=predefinedSMs[i].move_disc_channel[j];
				u32 value=predefinedSMs[i].move_disc_channel[MOVE_DISC_CHANNEL_NVALUES+j];
				*(u32 *)offset=value;
			}

		if(gamecubeRegionFreeHack)
			for(j=0;j<REGIONFREE_GC_NVALUES;j++){
				u32 offset=predefinedSMs[i].region_free_gc[j];
				u32 value=predefinedSMs[i].region_free_gc[REGIONFREE_GC_NVALUES+j];
				*(u32 *)offset=value;
			}
	}else{
		printf("* ERROR: Your SM has not predefined hacks.\n");
		printf("         You must use a custom hacks file (%s).\n",HACKS_FILE);
		wait_anyKey();
	}
	return true;
}

s32 Sysmenu_Load(u32 *entry, u16 index){
	static dolhdr dol ATTRIBUTE_ALIGN(32);

	u32 cnt;
	s32 fd, ret;

	/* Open content */
	fd = ES_OpenContent(index);
	if (fd < 0)
		return fd;

	/* Read content */
	ret = ES_ReadContent(fd, (u8 *)&dol, sizeof(dolhdr));
	if (ret < 0)
		return ret;

	memset(dol.bssmem, 0, dol.bsssize);

	/* Read data */
	for (cnt = 0; cnt < 7; cnt++)
		if (dol.textoff[cnt] >= sizeof(dolhdr)) {
			ret = ES_SeekContent(fd, dol.textoff[cnt], 0);
			if (ret != dol.textoff[cnt])
				return -1;

			ret = ES_ReadContent(fd, dol.textmem[cnt], dol.textsize[cnt]);
			if (ret != dol.textsize[cnt])
				return -1;
		}

	for (cnt = 0; cnt < 11; cnt++)
		if (dol.dataoff[cnt] >= sizeof(dolhdr)) {
			ret = ES_SeekContent(fd, dol.dataoff[cnt], 0);
			if (ret != dol.dataoff[cnt])
				return -1;

			ret = ES_ReadContent(fd, dol.datamem[cnt], dol.datasize[cnt]);
			if (ret != dol.datasize[cnt])
				return -1;
		}

	/* Close content */
	ES_CloseContent(fd);

	/* Set entry point */
	*entry = dol.entry;

	return 0;
}

s32 Sysmenu_Identify(void){
	static ticket s_tik ATTRIBUTE_ALIGN(32);
	signed_blob *p_certs = NULL, *p_tik = NULL, *p_tmd = NULL;

	u32 certs_len, tik_len, tmd_len;
	s32 ret;

	/* Retrieve certificates */
	ret = Sys_GetCerts(&p_certs, &certs_len);
	if (ret < 0)
		return ret;

	/* Set ticket length */
	tik_len = sizeof(s_tik);

	memset(&s_tik, 0, tik_len);

	/* Generate ticket */
	strcpy(s_tik.tik_data.issuer, "Root-CA00000001-XS00000003");
	memset(s_tik.tik_data.cidx_mask, 0xFF, 32);

	s_tik.signature.type = ES_SIG_RSA2048;

	/* Set pointer */
	p_tik = (signed_blob *)&s_tik;

	/* Retrieve TMD length */
	ret = ES_GetStoredTMDSize(SYSMENU_TITLEID, &tmd_len);
	if (ret < 0)
		goto out;

	/* Allocate memory */
	p_tmd = (signed_blob *)memalign(32, tmd_len);
	if (!p_tmd) {
		ret = -1;
		goto out;
	}

	/* Retrieve TMD */
	ret = ES_GetStoredTMD(SYSMENU_TITLEID, p_tmd, tmd_len);
	if (ret < 0)
		goto out;

	/* Identify as system menu */
	ret = ES_Identify(p_certs, certs_len, p_tmd, tmd_len, p_tik, tik_len, NULL);

out:
	/* Free memory */
	if (p_tmd)
		free(p_tmd);

	return ret;
}

s32 Sysmenu_Bootindex(void){
	signed_blob *p_tmd = NULL;

	u32 len;
	s32 ret;

	/* Retrieve TMD length */
	ret = ES_GetStoredTMDSize(SYSMENU_TITLEID, &len);
	if (ret < 0)
		goto out;

	/* Allocate memory */
	p_tmd = (signed_blob *)memalign(32, len);
	if (!p_tmd)
		return -1;

	/* Retrieve TMD */
	ret = ES_GetStoredTMD(SYSMENU_TITLEID, p_tmd, len);
	if (ret < 0)
		goto out;

	/* Get boot index */
	ret = ((tmd *)SIGNATURE_PAYLOAD(p_tmd))->boot_index;

out:
	/* Free memory */
	if (p_tmd)
		free(p_tmd);

	return ret;
}

u32 get_sysmenu_version(){
	s32 ret;
	u32 tmd_size;

	ret=ES_GetStoredTMDSize(TITLE_ID(1,2), &tmd_size);
	static u8 tmd_buf[MAX_SIGNED_TMD_SIZE] ATTRIBUTE_ALIGN(32);
	signed_blob *s_tmd=(signed_blob *)tmd_buf;
	ret=ES_GetStoredTMD(TITLE_ID(1,2), s_tmd, tmd_size);

	tmd *t=SIGNATURE_PAYLOAD(s_tmd);
	u32 tidh=t->title_id >> 32;
	u32 tidl=t->title_id & 0xFFFFFFFF;

	if(tidh==1 && tidl==2 && t->title_version){
		printf("* Found System Menu (v%u - IOS%u).\n",(u32)t->title_version,(u32)t->sys_version);
		return (u32)t->title_version;
	}else{
		return 0;
	}
}

s32 Sysmenu_Launch(void){
	u32 entry, index;
	s32 ret;
	u32 smversion;

	/* Read current state flags */
	ret = State_Initialize();
	if (ret < 0) {
		printf("* ERROR: Could not read current state flags! (ret = %d)\n", ret);
		return ret;
	}

	/* Identify as system menu */
	ret = Sysmenu_Identify();
	if (ret < 0) {
		printf("* ERROR: Could not identify as system menu! (ret = %d)\n", ret);
		printf("  Did you select a valid IOS?\n");
		return ret;
	}

	// Get system menu version
	smversion=get_sysmenu_version();
	if(smversion==0){
		printf("* ERROR: I can't get System Menu version.\n");
		return -1;
	}

	printf("* Loading System Menu into memory...");
	fflush(stdout);

	/* Get system menu boot index */
	ret = Sysmenu_Bootindex();
	if (ret < 0) {
		printf("* ERROR: Could not retrieve boot index! (ret = %d)\n", ret);
		return ret;
	}

	index = ret;

	/* Load system menu */
	ret = Sysmenu_Load(&entry, index);
	if (ret < 0) {
		printf("* ERROR: Could not load system menu executable! (ret = %d)\n", ret);
		return ret;
	}
	printf(" OK!\n");

	/* Patch system menu */
	bool last_step=Read_And_Apply_Patches(smversion);
	if(!last_step){
		predefined_patches_menu(smversion);
	}

	/* Set state flags */
	ret = State_ReturnToMenu();
	if (ret < 0) {
		printf("* ERROR: Could not set state flags! (ret = %d)\n", ret);
		return ret;
	}

	SYS_ResetSystem(SYS_SHUTDOWN, 0, 0);
	DCFlushRange((u8 *)SYSMENU_ADDR, SYSMENU_LEN);

	/* Jump to entry point */
	unstub_start(entry);

	printf(" returned!\n");

	return 0;
}
