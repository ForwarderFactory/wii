#ifndef _SYSMENU_H_
#define _SYSMENU_H_

/* Prototypes */
s32 Sysmenu_Launch(void);

#endif
