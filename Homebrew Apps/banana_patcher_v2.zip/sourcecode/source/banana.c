/*
 * Banana Patcher v1 (C) 2009 Marc
 *
 * based on Waninkoko's Menu Patcher
 * patch file style from Preloader
 *
 * This utility will allow to apply on-the-fly the same patches
 * that Preloader uses without having to modify the NAND.
 */
 
#include <stdio.h>
#include <ogcsys.h>
#include <gccore.h>
#include <wiiuse/wpad.h>
#include "sysmenu.h"
#include "wiibasics.h"

//Color constants
#define BLACK	0
#define WHITE	7

#define MAX_IOS	17
const u8 ioses[]={249,250,16,21,33,34,35,36,37,38,53,55,60,70,202,222,223,224};

int main(int argc, char **argv){
	u8 ios=0;
	basicInit();
	WPAD_Init();

	for(;;){
	    printf("\x1b[2J"); //clear console
		printf("\x1b[%u;%um", BLACK+30,0); //set title colors
		printf("\x1b[%u;%um", WHITE+40,1);
		printf("                       \n");
		printf("   Banana Patcher v2   \n");
		printf("      - by Marc -      \n");
		printf("                       \n");
		printf("\x1b[%u;%um", BLACK+40,0); //restore console colors
		printf("\x1b[%u;%um", WHITE+30,1);
		fflush(stdout);
		printf("\n\nSelect an IOS with the fake-sign bug to use with Banana Patcher:\n");
		printf("(any installed cIOS is recommended)\n");
		printf("           <<  ");
		printf("IOS%d",ioses[ios]);
		printf("  >>\n");
		printf("Press A to continue\n\n");

		u32 pressed = wait_anyKey();
		if(pressed==WPAD_BUTTON_RIGHT){
			if(ios<MAX_IOS)
				ios++;
			else
				ios=0;
		}else if(pressed==WPAD_BUTTON_LEFT){
			if(ios>0)
				ios--;
			else
				ios=MAX_IOS;
		}else if(pressed==WPAD_BUTTON_A){
			break;
		}
	}
	printf("IOS reloading...\n");
	WPAD_Disconnect(0);
	WPAD_Shutdown();
	s32 ret = IOS_ReloadIOS(ioses[ios]);
	WPAD_Init();

	if(ret<0){
		printf("\n\n* ERROR: I can't use that IOS (err: %d).\n",ret);
	}else{
		//Launch System Menu
		Sysmenu_Launch();
	}

	//Wait for a button and restart
	printf("(press any button to continue)\n\n");
	wait_anyKey();

	printf("Returning to loader...\n");
	fflush(stdout);

	return 0;
}
