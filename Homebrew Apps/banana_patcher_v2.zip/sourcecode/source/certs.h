#ifndef _CERTS_H_
#define _CERTS_H_

/* Prototypes */
s32  Sys_GetCerts(signed_blob **, u32 *);

#endif
