#ifndef _WII_BASICS_H_
#define _WII_BASICS_H_


#define TITLE_ID(x,y)		(((u64)(x) << 32) | (y))

// Scan the pads and return buttons
u32 getButtons(void);

u32 wait_anyKey(void);

// Do basic Wii init: Video, console, WPAD
void basicInit(void);

#endif
