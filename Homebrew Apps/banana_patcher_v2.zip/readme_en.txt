BANANA PATCHER v2
-----------------
Banana Patcher is able to apply on-the-fly Preloader patches to System Menu
without installing anything to the NAND. Some of the code was taken from
Waninkoko's Menu Patcher.

Useful for:
* Copy your copy-protected saves to SD easily
* Move Disc Channel
* Play your GC imports

Banana Patcher needs an IOS with trucha bug (any cIOS will work).


How to use
----------
Banana Patcher uses the same Preloader hacks file format. The only difference
is that you must place the hacks file in sd:/banana_hacks.txt.
Don't try to run Banana Patcher with a lot of hacks, because the Wii System
Menu can become very unstable. Remove the ones your are not going to use.

In the hacks subdirectory you can find some example files, just take the one you
need and rename it to sd:/banana_hacks.txt.


Predefined hacks
----------------
If you are only going to use the most important hacks just run Banana Patcher
without the sd:/banana_hacks.txt file and you will be able to choose which
hacks you want to enable:
* Remove the copy-protection of your savegames
* Move Disc Channel
* Gamecube Region Free
Banana Patcher includes these predefined hacks for:
* 4.2U
* 4.2E
* 4.2J
* 4.2K
* 4.1J
* 4.1U
* 4.1E
* 4.0U
* 4.0E
* 3.2U
* 3.2E
With the exception of Gamecube Region Free hack, which is not available on 4.0U or 4.0E.


History
-------
v1 (2009.07.28)
* first version

v2 (2010.02.16)
* added IOS selector at start (you don't need a patched IOS36 anymore, just use any cIOS)
* added predefined hacks (you don't need the banana_hacks.txt file for main hacks)
* added new hack files (thanks to marinos35)



--by Marc
http://usuaris.tinet.cat/mark/