BANANA PATCHER v2
-----------------
Banana Patcher es capaz de aplicar al vuelo los parches de Preloader en tu
Men� de Wii sin necesidad de instalar nada en la NAND. Parte del c�digo est�
basado en el Menu Patcher de Waninkoko.

�til para:
*Copiar las partidas con protecci�n anti-copia a la SD f�cilmente
*Mover el Canal Disco
*Jugar juegos de GC de importaci�n

Banana Patcher necesita un IOS con bug trucha (cualquier cIOS vale).


C�mo se usa
-----------
Banana Patcher usa el mismo formato de archivo de hacks que Preloader. La
�nica diferencia es que tienes que colocar el archivo en sd:/banana_hacks.txt.
No intentes ejecutar Banana Patcher con muchos hacks activados, porque el men�
de Wii se puede volver muy inestable. Quita los que no vayas a usar.

En el directorio hacks se encuentran varios archivos de ejemplo, simplemente coge
el que necesites y ren�mbralo a sd:/banana_hacks.txt.


Hacks predefinidos
------------------
Si solo vas a usar los hacks m�s importantes, tan solo ejecuta Banana Patcher
sin el archivo sd:/banana_hacks.txt y podr�s seleccionar qu� hacks quieres activar:
* Quitar la protecci�n anti-copia de las partidas protegidas
* Mover Canal Disco
* Gamecube Region Free
Banana Patcher incluye hacks predefinidos para:
* 4.2U
* 4.2E
* 4.2J
* 4.2K
* 4.1J
* 4.1U
* 4.1E
* 4.0U
* 4.0E
* 3.2U
* 3.2E
Con la excepci�n del hack Gamecube Region Free hack, que no est� disponible en 4.0U o 4.0E.


Historial
---------
v1 (2009.07.28)
* primera versi�n

v2 (2010.02.16)
* a�adido selector de IOS a usar al inicio (ya no es necesario un IOS36 parcheado)
* a�adidos hacks predefinidos (no se requiere el archivo banana_hacks.txt para algunos hacks)
* a�adidos nuevos archivos de hacks para 4.2 (gracias a marinos35)


--by Marc
http://usuaris.tinet.cat/mark/