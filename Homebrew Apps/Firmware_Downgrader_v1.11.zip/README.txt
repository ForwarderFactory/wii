+-------------------------------------------+
|   [+] SoftMii Firmware Downgrader v1.11   |
|       developed by Waninkoko              |
+-------------------------------------------+
|            www.teknoconsolas.es           |
+-------------------------------------------+


[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.


[ DESCRIPTION ]:

- This application allows you to downgrade your Wii firmware to any
  available version on the Nintendo servers.

  Also, it allows you to change the Wii console region, to match the
  new installed firmware region, and the Wii Shop country code.


[ NOTES ]:

- If you install a firmware from a different region without changing
  the console region, you will get a semibrick.

  I recommend changing the console region to match the firmware
  region and avoid future problems.


[ REQUISITES ]:

- Custom IOS37 rev 03 or higher.
- Internet connection.


[ HOW TO USE ]:

- Run the application and select the firmware to install.


[ KUDOS ]:

- Team Twiizers/devkitPRO
- tona
- frontier
- All my betatesters.
