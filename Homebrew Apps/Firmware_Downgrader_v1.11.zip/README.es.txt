+-------------------------------------------+
|   [+] SoftMii Firmware Downgrader v1.11   |
|       developed by Waninkoko              |
+-------------------------------------------+
|            www.teknoconsolas.es           |
+-------------------------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DA�O EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- Esta aplicacion te permite downgradear el firmware de tu consola
  Wii a cualquier version disponible en los servidores de Nintendo.

  Ademas, la aplicacion tambien te permite cambiar la region de tu
  consola Wii, para que coincida con la region del nuevo firmware
  instalado, y el codigo de pais de la tienda Wii.


[ NOTAS ]:

- Si instalas un firmware de region diferente sin cambiar la region
  de la consola, obtendras un semibrick.

  Recomiendo cambiar la region de la consola para que coincida con la
  region del firmware y evitar futuros problemas.


[ REQUISITOS ]:

- Custom IOS37 rev 03 o superior.
- Conexion a internet.


[ COMO USARLO ]:

- Ejecuta la aplicacion y selecciona la version de firmware a instalar.


[ KUDOS ]:

- Team Twiizers/devkitPRO
- tona
- frontier
- Todos los betatesters.
