+--------------------------------+
|   [+] Firmware Updater v4.0    |
|       developed by Waninkoko   |
+--------------------------------+
|       www.teknoconsolas.es     |
+--------------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DA�O EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- Esta aplicacion te permite actualizar el firmware de tu consola instalando
  unicamente las aplicaciones necesarias para ello (IOS, System Menu, canales...).

  Gracias a ello se pueden mantener ciertas caracteristicas como el bug Trucha que
  afecta a las primeras versiones de IOS.


[ REQUISITOS ]:

- 150-250 bloques libres.
- Conexion a internet.


[ COMO USARLO ]:

- Ejecuta la aplicacion con cualquier metodo de carga de homebrew y la actualizacion
  se hara de forma automatica.


[ KUDOS ]:

- Team Twiizers y devkitPRO -> libogc
- frontier                  -> libpng
- Todos mis betatesters.