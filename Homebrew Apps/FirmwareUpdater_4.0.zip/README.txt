+--------------------------------+
|   [+] Firmware Updater v4.0    |
|       developed by Waninkoko   |
+--------------------------------+
|       www.teknoconsolas.es     |
+--------------------------------+


[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.


[ DESCRIPTION ]:

- This application allows you to update your console's firmware installing only the
  needed applications (IOS, System Menu, channels...).

  Thanks to it you can keep some features like Trucha bug that affected first IOS
  versions.


[ REQUISITES ]:

- 150-250 free blocks.
- Internet connection.


[ HOW TO USE ]:

- Run the application with any method to load homebrew and the update will be done
  automatically.


[ KUDOS ]:

- Team Twiizers and devkitPRO -> libogc
- frontier                    -> libpng
- All my betatesters.
