+------------------------------------------+
|   [+] Wii DVD Dumper (Custom IOS) v1.1   |
|       developed by Waninkoko             |
+------------------------------------------+
|          www.teknoconsolas.info          |
+------------------------------------------+


[ DESCRIPTION ]:

- This application allows you to dump a GC/Wii DVD to a SD card
  using the Custom IOS (IOS249).


[ HOW TO USE ]:

- Run the application with any method to load homebrew. Select
  the split size, the disc type and insert the DVD disc and a
  SD card with enough space.


[ NOTES ]:

- You need the Custom IOS (IOS249) to use this application!


[ KUDOS ]:

- Team Twiizers and devkitPRO devs for their great work in libogc.
- All the betatesters.
