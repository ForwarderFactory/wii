+------------------------------------------+
|   [+] Wii DVD Dumper (Custom IOS) v1.1   |
|       developed by Waninkoko             |
+------------------------------------------+
|          www.teknoconsolas.info          |
+------------------------------------------+


[ DESCRIPCION ]:

- Esta aplicacion te permite dumpear a DVD de GC/Wii a una tarjeta
  SD usando el Custom IOS (IOS249).


[ COMO USARLO ]:

- Ejecuta la aplicacion con cualquier metodo para cargar homebrew.
  Selecciona el tama�o de particion, el tipo de disco e inserta el
  disco DVD y una tarjeta SD con espacio suficiente.


[ NOTAS ]:

- �Necesitas el Custom IOS (IOS249) para usar esta aplicacion!


[ KUDOS ]:

- Team Twiizers y devkitPRO devs por su gran trabajo en libogc.
- Todos los betatesters.
