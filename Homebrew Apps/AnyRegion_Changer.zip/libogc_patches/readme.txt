Description of patches:

network_wii.patch:
Adds a "Deinitialization" function to the networking interface.

es_opentitlecontent.patch:
crediar's patch to add the ES_OpenTitleContent function.