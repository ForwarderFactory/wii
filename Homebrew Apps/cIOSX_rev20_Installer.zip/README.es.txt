+--------------------------------------+
|   [+] Custom IOS Installer (rev 20)  |
|       developed by Waninkoko         |
+--------------------------------------+
|         www.teknoconsolas.es         |
+--------------------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DA�O EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- Esto es un Custom IOS, un IOS modificado para añadir nuevas
  caracteristicas no disponibles en el IOS oficial.

  Este IOS ha sido creado para ser usado UNICAMENTE con software
  casero.

  El Custom IOS se instala en un slot libre y no modifica ningun
  otro IOS por lo que es seguro de instalar.


[ REQUISITOS ]:

- El fichero WAD de la version de IOS que se utilizara como base (para la instalacion por WAD).
- Conexion a internet (para la instalacion por red).


[ COMO INSTALARLO ]:

  Instalacion por WAD:

- Copia el fichero WAD del IOS a utilizar como base en el directorio raiz de un dispositivo de almacenamiento (tarjeta SD o dispositivo USB).
- Inserta el dispositivo de almacenamiento en la Wii.
- Ejecuta el instalador.
- Elige la version de IOS a utilizar como base (por defecto viene la recomendada).
- Elige la opcion "WAD Installation".
- Elige el dispositivo de almacenamiento donde has copiado el fichero WAD.


  Instalacion por red:

- Ejecuta el instalador.
- Elige la version de IOS a utilizar como base (por defecto viene la recomendada).
- Elige la opcion "Network Installation".


[ KUDOS ]:

- Team Twiizers y devkitPRO devs por su gran trabajo en libogc.
- Todos los betatesters.
- WiiGator, por su trabajo en el DIP plugin.
- kwiirk, por su modulo EHCI.
- Hermes, por sus mejoras en el modulo EHCI.
- sorg, por el parche para la comprobacion de presencia de disco.
- Shizzza, por la imagen de fondo.
- nitrotux, por su IOS5.
- neimod, por el Custom IOS module.


[ MAS KUDOS ]:

Gracias a:

- Skarface0
- Linkinworm
- ManuMtz
- hectorscasa
- Kabiigon
- skarface0
- Nicksasa
- itsblah
- HulkHodn
- Vlad
- Denus
- Todos los que donaron para conseguirme un USB Gecko.
- Y al resto de betatesters.
