============
 BRAWLSTATS
============

BrawlStats is a Wii application that will have to be run after a Super
Smash Bros. Brawl session.
It will store automatically on your SD your results and then you will be
able to navigate freely through a clean GUI that will show you a lot of
information that Brawl doesn't store (or doesn't show). It also gives
different trophies to players that achieve certain records.
It can be like a database of your Brawl matches.


What I need?
------------
* Homebrew Channel 1.0.7 or later
* Super Smash Bros. Brawl save data (PAL or NTSC-USA)
* SD card


Usage
-----
Run BrawlStats for the first time. This will create the needed data on your SD.

Once you have the data on your SD you can play Super Smash Bros. Brawl as long
as you want.

After the Brawl session, you must run BrawlStats again. It will ask you if you
want to create a new session, answer always YES. And now you will be able to
see all the information about that session! :D

From now on, you will have to run BrawlStats after any Brawl session.
If you don't follow this rule, next session you create will have the information
of the last session plus the previous unsaved one, so remember to run BrawlStats
after any session.



Menu & controls
---------------
BrawlStats has a simple graphical user interface that we will divide in
tabs, and every tab is divided by pages.

Controls:
* A: next page
* B: previous page
* +: next page
* -: previous page
* D-PAD: navigate and/or scroll tables in the current page
* 2: save screenshot to SD
* HOME: help screen/exit

Explanation of tabs and pages:

* TAB 1: Sessions
  The most important one. It will start empty, but after every session it
  will grow bigger as a nice Brawl sessions database.
   * Page 1: Sessions list, it also shows the selected session winners.
             Up/Down: select session.
   * Page 2: Selected session player ranking.
             Left/Right: change the table sort method.
             Up/Down: scroll table.
   * Page 3: Selected session character ranking.
             Left/Right: change the table sort method.
             Up/Down: scroll table.
   * Page 4: Melee-style stats (versus).
             This will be only available if the players have not selected
             the same characters on the selected session.

* TAB 2: Players
  Here you can see the general stats of players.
   * Page 1: Players list.
             Left/Right: browse players.
             Up/Down: scroll time spent on every character table.
   * Page 2: General player ranking.
             Left/Right: change the table sort method.
             Up/Down: scroll table.
   * Page 3: General player ranking (stats per match).
             Left/Right: change the table sort method.
             Up/Down: scroll table.

* TAB 3: Characters
  Here you can see the general stats of characters.
   * Page 1: Characters list.
             Left/Right: browse characters.
             Up/Down: scroll KO table.
   * Page 2: General character ranking.
             Left/Right: change the table sort method.
             Up/Down: scroll table.
   * Page 3: General character ranking (stats per match).
             Left/Right: change the table sort method.
             Up/Down: scroll table.

* TAB 4: General & help
   * Shows some general stats like the total of matches or play time
     and a little help in how to navigate in BrawlStats.
     HOME: Exit.


IOS Reload
----------
BrawlStats v1 uses AHBPROT in order to have access to NAND and read SSBB savegame.
However, you can also force an IOS reload.
Remove the commment lines (<!-- and -->) and edit the IOS number to use on meta.xml
file. Example for IOS236:
<arguments>
    <arg>--ios=236</arg>
</arguments>


History
-------
beta1 (2010.02.09)
* first version

beta2 (2010.02.27)
* some small bug fixes
* some cosmetic changes
* added a page indicator so you can know in what page you are
* the ranking per matches now shows a new column that indicates the total matches
* added a new help screen on the last tab
* the return to Wii menu function works
* numbers now use a fixed width font

beta3 (2010.03.15)
* fixed an important bug when you reach 10 sessions

RC1 (2010.08.31)
* a totally new graphical user interface
* added trophy system

v1 (2010.12.13)
* uses AHBPROT, no cIOS needed anymore (meta.xml was also updated)
* sessions now are stored at sd:/config/brawlstats/, you will have to move your
  old sessions to the new path

v1.1 (2011.03.09)
* fixed AHBPROT for older IOS, it's more compatible now
* fixed BrawlStats use percentage last tab
* added snapshot feature (press 2 at any page)
* faster scrolling tables by holding up/down
* some cosmetic changes

v1.2 (2011.04.30)
* warns user if a session was not created correctly
  (due to a corrupted SD card, for example)
* shows a loading bar when reading sessions from SD

v1.2.1 (2011.10.15)
* improved compatibility with some SD cards
* fixes the corrupted sessions bug



--by Marc
http://usuaris.tinet.cat/mark/