void Device_ROPEN(void);
void Device_RCLOS(void);
void Device_RREAD(void);
void Device_RWRIT(void);
void Device_RSTAT(void);
void Device_RSPEC(void);
void Device_RINIT(void);


