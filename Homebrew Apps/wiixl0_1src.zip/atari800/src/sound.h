#ifndef _sound_h
#define _sound_h

void Sound_Initialise(int *argc, char *argv[]);
void Sound_Exit(void);
void Sound_Update(void);
void Sound_Pause(void);
void Sound_Continue(void);

#endif /* _sound_h */
