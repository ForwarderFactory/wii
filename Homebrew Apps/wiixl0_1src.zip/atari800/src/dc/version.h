/* provides Atari800DC version */

#ifndef __VERSIONDC_H_
#define __VERSIONDC_H_

#define A800DCVERHI  0
#define A800DCVERLO  77
#define A800DCVERASC "0.77beta"

#endif /* #ifndef __VERSIONDC_H_ */
