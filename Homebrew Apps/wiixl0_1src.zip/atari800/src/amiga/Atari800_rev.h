#define VERSION		2
#define REVISION	4
#define DATE		"16.3.2005"
#define VERS		"Atari800 2.4"
#define VSTRING		"Atari800 2.4 (16.3.2005)\r\n"
#define VERSTAG		"\0$VER: Atari800 2.4 (16.3.2005)"
