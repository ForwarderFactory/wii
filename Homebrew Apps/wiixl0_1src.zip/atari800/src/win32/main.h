#ifndef _MAIN_H_
#define _MAIN_H_

extern char *myname;
extern HWND hWndMain;
extern HINSTANCE myInstance;

#endif /* _MAIN_H_ */
