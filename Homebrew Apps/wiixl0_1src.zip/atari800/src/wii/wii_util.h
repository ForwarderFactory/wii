#ifndef WII_UTIL_H
#define WII_UTIL_H

#define DIR_SEP_CHAR '/'
#define DIR_SEP_STR  "/"

extern void Util_getextension( char *filename, char *ext );

#endif
