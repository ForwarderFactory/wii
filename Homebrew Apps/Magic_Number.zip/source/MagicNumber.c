// #######################################################
// ## Magic Number                                      ##
// ##												    ##
// ## HardCoal99's first Wii program	 - 11/24/2008   ##
// ## 													##
// ## User attempts to guess a randomized number.       ##
// ##													##
// ## Easter Egg: Wii LED light will shine with an      ##
// ## intensity matching ratio of magic number to max   ##
// ## possible number. EX. in Beginner, if 3 is the     ##
// ## random number, the LED will shine at 60%          ##
// ## brightness. Impress friends by always guessing    ##
// ## the correct number in beginner mode.              ##
// #######################################################

#include <stdio.h>
#include <stdlib.h>
#include <gccore.h>
#include <unistd.h>
#include <wiiuse/wpad.h>
#include <wiiuse/wiilight.h>

static void *xfb = NULL;
static GXRModeObj *rmode = NULL;

int maxrand, life, max, min, randnum;
int Level = 0;
int picknum = 1;

// #######################################################
// ############ Print Game Menu###########################
// #######################################################
void PrintMenu()
{
	printf("\x1b[6;2HSelect a difficulty mode: ");
	
	printf("\x1b[7;2HLevel 1: Beginner (1-5)");
	printf("\x1b[8;2HLevel 2: Easy (1-10)");
    printf("\x1b[9;2HLevel 3: Medium (1-35)");
    printf("\x1b[10;2HLevel 4: Hard (1-100)");
    printf("\x1b[11;2HLevel 5: Masters (1-350)");
    printf("\x1b[12;2HLevel 6: Impossible (1-500)");
	
	printf("\x1b[13;2HUse up/down arrows and press 'A' to select mode.");	
}

// ##########################################################
// ###############Select Game Difficulty#####################
// ##########################################################
void SelectDifficulty()
{
	printf("\x1b[15;2HLevel 1: Beginner (1-5)                   ");
	
	// Print Level
	while (1) {
		// Call WPAD_ScanPads each loop, this reads the latest controller states
		WPAD_ScanPads();
		
		if (WPAD_ButtonsDown(0) & WPAD_BUTTON_DOWN ){ 
			Level = Level + 1;
			if (Level > 5 ) Level = 0;
			
			switch (Level) {
				case 0:
				printf("\x1b[15;2HLevel 1: Beginner (1-5)                   ");
				break;
	
				case 1:
				printf("\x1b[15;2HLevel 2: Easy (1-10)                    ");
				break;
	
				case 2:
				printf("\x1b[15;2HLevel 3: Medium (1-35)                  ");
				break;
	
				case 3:
				printf("\x1b[15;2HLevel 4: Hard (1-100)                   ");
				break;
	
				case 4:
				printf("\x1b[15;2HLevel 5: Masters (1-350)               ");
				break;
	
				case 5:
				printf("\x1b[15;2HLevel 6: Impossible (1-500)            ");
				break;
			}
		}

		if (WPAD_ButtonsDown(0) & WPAD_BUTTON_UP ){ 
			Level = Level - 1;
			if (Level < 0 ) Level = 5;
			
			switch (Level) {
				case 0:
				printf("\x1b[15;2HLevel 1: Beginner (1-5)                   ");
				break;
	
				case 1:
				printf("\x1b[15;2HLevel 2: Easy (1-10)                    ");
				break;
	
				case 2:
				printf("\x1b[15;2HLevel 3: Medium (1-35)                  ");
				break;
	
				case 3:
				printf("\x1b[15;2HLevel 4: Hard (1-100)                   ");
				break;
	
				case 4:
				printf("\x1b[15;2HLevel 5: Masters (1-350)               ");
				break;
	
				case 5:
				printf("\x1b[15;2HLevel 6: Impossible (1-500)            ");
				break;
			}			
		}
		
		if (WPAD_ButtonsDown(0) & WPAD_BUTTON_A ) {
			switch(Level) {
				case 0: maxrand = 5; life = 2; max = 5; min = 1;
				break;
	
				case 1: maxrand = 10; life = 3; max = 10; min = 1;
				break;
	
				case 2: maxrand = 35; life = 4; max = 35; min = 1;
				break;
	
				case 3: maxrand = 100; life = 5; max = 100; min = 1;
				break;
	
				case 4: maxrand = 350; life = 6; max = 350; min = 1;
				break;
	
				case 5: maxrand = 500; life = 7; max = 500; min = 1;
				break;
			}
			// Break out of loop to continue game setup
			break;
		}	
		// We return to the launcher application via exit
		if (WPAD_ButtonsDown(0)  & WPAD_BUTTON_HOME ) exit(0);
	}	
	
}

// ##########################################################
// ###############Set the Magic Random Number################
// ##########################################################
void SetRand()
{
	// Set random number
	srand( (unsigned)time( NULL ) ); // initiate rand() function
	randnum = rand() % maxrand;  // j= get a random value between 1 and maxrand
	randnum = randnum + 1;
	int lightlevel = (randnum * 255);
	lightlevel = (lightlevel / maxrand);
	WIILIGHT_SetLevel(lightlevel);
	WIILIGHT_TurnOn();
}

// ##########################################################
// ###############Clear the Screen###########################
// ##########################################################
void ClearScreen()
{
	
	//set the background color to blue
	printf ("\x1b[44m");
	printf("\x1b[2J");
	printf("\x1b[1;0H");
}

// ##########################################################
// ###############Pick the Magic Number######################
// ##########################################################
void PickNum()
{
	printf("\x1b[6;2HPlease guess the magic number by using Up/Down keys.");
	printf("\x1b[7;2HPress the 'A' button to select.");
	
	printf("\x1b[8;2H  %d    ", picknum);
	
	while (1) {
		// Call WPAD_ScanPads each loop, this reads the latest controller states
		WPAD_ScanPads();
		
		if (WPAD_ButtonsHeld(0) & WPAD_BUTTON_DOWN ) {
			if (picknum < max)
				picknum = picknum + 1;
				printf("\x1b[8;2H  %d    ", picknum);
				usleep(40000);
		}
		
		if (WPAD_ButtonsHeld(0) & WPAD_BUTTON_UP ) {
			if (picknum > min)
				picknum = picknum - 1;
				printf("\x1b[8;2H  %d    ", picknum);
				usleep(40000);
		}
		
		if (WPAD_ButtonsDown(0) & WPAD_BUTTON_A ) {
			break;
		}
		
		// We return to the launcher application via exit
		if (WPAD_ButtonsDown(0)  & WPAD_BUTTON_HOME ) exit(0);
	}	
}

// ##########################################################
// ###############Get Results################################
// ##########################################################
void Results()
{
	while (life >= 0) 
	{
		if (picknum == randnum) {
			printf("\x1b[16;2HYou Found the Correct Number!!!               ");
			break;
		}
						
		if (picknum > randnum) {
			printf("\x1b[10;2HToo Big!!!                      ");
			life = life - 1;
			max = picknum - 1;
			picknum = picknum - 1;
		}
		
		if (picknum < randnum) {
			printf("\x1b[10;2HToo Small!!!                    ");
			life = life - 1;
			min = picknum + 1;
			picknum = picknum + 1;
		}
		
		if (life < 0) {
			printf("\x1b[16;2HYou Lose!!! The magic number was %d                    ",randnum);
			break;
		}
		
		printf("\x1b[13;2HLives Left: %d                  ",life);
		
		PickNum();
	}	
}

// ##########################################################
// ###############Reset Variables############################
// ##########################################################
void ClearVars() {
	maxrand = 0;
	life = 0;
	max = 0;
	min = 0;
	randnum = 0;
	Level = 0;
	picknum = 1;
}

// ##########################################################
// ###############Main Function##############################
// ##########################################################
//---------------------------------------------------------------------------------
int main(int argc, char **argv) {
//---------------------------------------------------------------------------------

	// Initialise the video system
	VIDEO_Init();
	
	// This function initialises the attached controllers
	WPAD_Init();
	
	// Obtain the preferred video mode from the system
	// This will correspond to the settings in the Wii menu
	rmode = VIDEO_GetPreferredMode(NULL);

	// Allocate memory for the display in the uncached region
	xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
	
	// Initialise the console, required for printf
	console_init(xfb,20,20,rmode->fbWidth,rmode->xfbHeight,rmode->fbWidth*VI_DISPLAY_PIX_SZ);
	
	// Set up the video registers with the chosen mode
	VIDEO_Configure(rmode);
	
	// Tell the video hardware where our display memory is
	VIDEO_SetNextFramebuffer(xfb);
	
	// Make the display visible
	VIDEO_SetBlack(FALSE);

	// Flush the video register changes to the hardware
	VIDEO_Flush();

	// Wait for Video setup to complete
	VIDEO_WaitVSync();
	if(rmode->viTVMode&VI_NON_INTERLACE) VIDEO_WaitVSync();

	// Start the Wii Lite Stuff....
	WIILIGHT_Init();

	// Start the game
	ClearScreen();
	ClearVars();
	PrintMenu();
	SelectDifficulty();
	SetRand();
	ClearScreen();
	PickNum();
	Results();
	WIILIGHT_TurnOff();
	printf("\x1b[18;2HPress 'A' to play again.  Home to exit.");
	
	//Unless user exits, continue to run the game
	while(1) {
		WPAD_ScanPads();
		
		if (WPAD_ButtonsDown(0) & WPAD_BUTTON_A ) {
			ClearScreen();
			ClearVars();
			PrintMenu();
			SelectDifficulty();
			SetRand();
			ClearScreen();
			PickNum();
			Results();
			WIILIGHT_TurnOff();
			printf("\x1b[18;2HPress 'A' to play again.  Home to exit.");
		}
		
		// We return to the launcher application via exit
		if (WPAD_ButtonsDown(0)  & WPAD_BUTTON_HOME ) exit(0);
	}
	return 0;
}

