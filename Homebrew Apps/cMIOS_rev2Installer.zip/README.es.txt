+------------------------------------------+
|   [+] Custom MIOS Installer (rev 02)     |
|       developed by Waninkoko/WiiGator    |
+------------------------------------------+
|         wwww.teknoconsolas.info          |
+------------------------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DA�O EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- Esto es un Custom MIOS, un MIOS modificado para añadir algunas caracteristicas nuevas
  no disponibles en el MIOS oficial.


[ REQUISITOS ]:

- El fichero WAD "RVL-mios-v8.wad" (para la instalacion por WAD).
- Conexion a internet (para la instalacion por red).


[ COMO INSTALARLO ]:

  Instalacion por WAD:

- Copia el fichero "RVL-mios-v8.wad" a la raiz de una tarjeta SD.
- Inserta la tarjeta SD en la Wii.
- Ejecuta la instalacion y elige la opcion "WAD Installation".


  Instalacion por red:

- Ejecuta la instalacion y elige la opcion "Network Installation".


[ NOTAS ]:

- Si se mantiene pulsado en boton B (mando GC) mientras se carga una backup,
  aparecera un menu con diversas opciones de arranque como seleccion de modo
  de video, etc.


[ KUDOS ]:

- Team Twiizers y devkitPRO devs por su trabajo en el libogc.
- Megaman, por su Wii Gamecube Homebrew Launcher.
- linkinworm, por la musica de fondo.
- Todos los betatesters.
