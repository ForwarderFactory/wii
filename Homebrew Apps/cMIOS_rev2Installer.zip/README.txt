+------------------------------------------+
|   [+] Custom MIOS Installer (rev 02)     |
|       developed by Waninkoko/WiiGator    |
+------------------------------------------+
|         wwww.teknoconsolas.info          |
+------------------------------------------+


[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.


[ DESCRIPTION ]:

- This is a Custom MIOS, a modified MIOS with some new added features that are
  not available in the official MIOS.


[ REQUISITES ]:

- "RVL-mios-v8.wad" original WAD file (for WAD installation).
- Network connection (for Network installation).


[ HOW TO INSTALL IT ]:

  WAD Installation:

- Copy "RVL-mios-v8.wad" to the root of a SD card.
- Insert the SD card on your Wii.
- Run the installer and select "WAD Installation".


  Network Installation:

- Run the installer and select "Network Installation".


[ NOTES ]:

- If the B button (GC pad) is held while launching a backup, a menu will appear with
  some boot options like video mode selection, etc.


[ KUDOS ]:

- Team Twiizers and devkitPRO devs for their great work in libogc.
- Megaman, for his Wii Gamecube Homebrew Launcher.
- linkinworm, for the background music.
- All the betatesters.
