#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gccore.h>
#include <malloc.h>

#include "IOSPatcher.h"
#include "iospatch.h"
#include "wad.h"
#include "tools.h"
#include "network.h"
#include "uninstall.h"

#define IOS36version 3351
#define MAGIC1 0x81001EC8
#define MAGIC2 0xBADC0DE
#define MAGIC3 0x81001234
#define MAGIC4 0x446f7065

// Prevent IOS36 loading at startup
s32 __IOS_LoadStartupIOS()
{
	return 0;
}

s32 __u8Cmp(const void *a, const void *b)
{
	return *(u8 *)a-*(u8 *)b;
}


int main(int argc, char* argv[])
{
	int ret;
	u32 pressed;
	u32 pressedGC;	

	Init_Console();
	printf("\x1b[%u;%um", 37, false);

	PAD_Init();
	WPAD_Init();
	WPAD_SetDataFormat(WPAD_CHAN_0, WPAD_FMT_BTNS_ACC_IR);					

	printheadline();


	ret = *((int *)MAGIC1);
	if (ret == MAGIC2) {
		ret = *((int *)MAGIC3);
		if (ret == MAGIC4) {
			ret = *((int *)MAGIC3 + 1);
			printf("\nSo this now makes %d times you've tried to rerun me, pirate.\n", ret);
			printf("I told you before, you need to try harder than that.\n\n");
			printf("Keep trying and I'll give you a hint...\n\n");
			if (ret > 5) {
				printf("You're persistent aren't you?  Here's a hint:\nShow me that you don't pirate all of your Wii games.\n\n");
			}
			if (ret > 10) {
				printf("You're really persistent!  The hint means to play a game normally in your Wii.\n");
				printf("There are other ways around the trap too, but figure them out yourself.\n");
			}
			ret++;
		} else {
			ret = 2;
			printf("\nSo you tell me you're a pirate and you expect that running\n");
			printf("the application a second time is enough for me to forgive you?\n");
			printf("You're going to have to try something harder than that, mate.\n");
			*((int *)MAGIC3) = MAGIC4;
		}
		*((int *)MAGIC3 + 1) = ret;
		sleep(ret*2);
		printf("\nPress any button to exit...\n");
		waitforbuttonpress(NULL, NULL);
	
		Reboot();
	}

	
	
	printf("WARNING: If you are not connected to the Internet, this app might crash.\n");
	printf("If you get a DSI error, rerun the app and be a little quicker.\n\n");
	printf("\nThis Application will install IOS236 onto your Wii.\n");
	printf("It relies on the fact that you launched this app with.\n");
	printf("the AHBPROT flags set, so you must be using HBC 1.07 or\n");
	printf("later.\n");
	printf("\nIOS236 is a patched IOS36 v3351 and this app can be used\n");
	printf("instead of the Trucha Bug Restorer, upon which the app\n");
	printf("was based.\n");
	printf("\nThis application should work on all Wii firmwares 4.3 and below,\n");
	printf("and as long as the HBC supports AHBPROT, it should work on newer\n");
	printf("firmwares too.  It is safe to use this application to reinstall\n");
	printf("IOS236 or replace a different IOS236.\n");
	printf("\nThanks, in no particular order, go to Wiipower, oggzee, Team Twiizers,\n");
	printf("tona, Joseph Jordan and anybody else who has code included in\n");
	printf("the app.  The app was quite a simple job, built upon their\n");
	printf("actual real work.\n");
	/*printf("\nPlease Wait...\n");
	
	time_t t = time(NULL) + 7;
	while (time(NULL) < t)
	{
		WPAD_ScanPads();
		PAD_ScanPads();
		if(WPAD_ButtonsDown(0) || PAD_ButtonsDown(0)) 
		{
			printf("Don't be impatient, press any button to exit...\n");
			waitforbuttonpress(NULL, NULL);
			Reboot();
		}
	}*/

	printf("Press 1 or Start to start the application...\n");

	
	waitforbuttonpress(&pressed, &pressedGC);
	if (pressed != WPAD_BUTTON_1 && pressedGC != PAD_BUTTON_START)
	{
		printf("Other button pressed, press any button to exit...\n");
		waitforbuttonpress(NULL, NULL);
		Reboot();
	}

	printf("Performing Step 1\n");

	printf("Patching IOS\n");
	if (!IOSPATCH_Apply()) {
        printf("Unable to initialise the initial patches.\n");
		printf("This either means you didn't follow the download\n");
		printf("and launching instructions correctly, or your IOS\n");
		printf("is not vulnerable for an unknown reason.\n");
		printf("Perhaps you need to update the Homebrew Channel (HBC).\n");
		printf("Installation cannot continue.  Press any button to exit...\n");
        waitforbuttonpress(NULL, NULL);
		Reboot();
    }
	printf("IOS patched\n");
	printf("About to install IOS236\n");

	ret = Install_patched_IOS(36, IOS36version, true, true, true, true, 236, 65535, false);
	if (ret < 0) {
		printf("IOS236 Install failed.  Press any button to exit...\n");
		waitforbuttonpress(NULL, NULL);
		Reboot();
	}

	printf("\nStep 1 Complete!\n");
	printf("\nStep 2 is an alteration that is only needed if you plan\n");
	printf("to play games you don't own the original disc for.\n");
	printf("Do you need this alteration?\n\n");
	printf("Press the 1 or X button if you want to play pirated games.\n");
	printf("Press the 2 or Y button if you have no need for piracy.\n");
	char found = 0;
	while(!found) {
		waitforbuttonpress(&pressed, &pressedGC);
		if (pressed == WPAD_BUTTON_1 || pressedGC == PAD_BUTTON_X) {
			found = 1;
		}
		if (pressed == WPAD_BUTTON_2 || pressedGC == PAD_BUTTON_Y) {
			found = 2;
		}
	}

	if (found == 1) {
		printf("\nPerforming Step 2\n");
		ISFS_Initialize();
		Uninstall_DeleteTicket(1, 236);
		Uninstall_DeleteTitle(1, 236);
		ISFS_Deinitialize();
		*((int *)MAGIC1) = MAGIC2;
		printf("\nStep 2 Complete!\n");
		printf("\nStep 2 was to delete IOS236.  You will need\n");
		printf("to install it again.\n\n");
		printf("Shame on you for being a pirate!\n");
		printf("Sorry if you were just curious or not paying\n");
		printf("attention, but you need to learn to be careful.\n\n");
		printf("While I can't stop you from lying next time,\n");
		printf("I can at least have the satisfaction that I've\n");
		printf("wasted some of your time.\n");
		printf("\nSeriously, though.  Developers do deserve to be paid\n");
		printf("to provide you with entertainment.  At least consider\n");
		printf("buying any game that you play a lot, or that you enjoy\n");
		printf("enough to finish.\n");
		printf("\nOh, and just be glad I didn't delete your HBC ;)\n");
		sleep(10);
		printf("Press any button to exit\n");
		waitforbuttonpress(NULL, NULL);
		Reboot();
	}

	printf("IOS236 Installation is complete!\n");
	printf("Press any button to exit...\n");
	waitforbuttonpress(NULL, NULL);
	
	Reboot();

	return 0;
}
