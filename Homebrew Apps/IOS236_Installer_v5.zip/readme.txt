IOS236 Installer v5

This application is a simplification of Trucha Bug Restorer.
It installs a patched IOS36 into the IOS236 slot.
It must be launched using the AHBPROT method, so will only
work with HBC 1.07 or higher.  The meta.xml file is important.

Simple instructions for using the application can be found at:
http://gwht.wikidot.com/ios236

To install, simply copy the IOS236 directory and its contents
to your apps directory on your SD card or USB drive.  Thus,
you will have sd:/apps/IOS236/boot.dol as one of the files.

While this installation should be safe, it does install stuff
to your Wii's NAND.  Do not use it if potential for power
outages occur as it could brick your system.  

To perform an offline install, use NUS Downloader to get
IOS36 v3551 as IOS36-64-3351.wad and copy it to the root
directory of your SD card or drive.  Note that the app might
crash if left alone too long when the Wii is not connected to
the Internet, so don't waste time.

Version history:
v5 - Upgraded to libogc 1.8.4 to fix network bug.  This release is untested, though.
v4 - Borrowed console code from Cfg to help stability
   - Can still get a DSI crash if you wait too long with no network,
     but you have a lot more time now
   - Removed delay at startup to aid offline installers
v3 - Another change to avoid DSI errors
   - Changed buttons needed at Step 2
v2 - A few changes to avoid DSI errors
   - Changed version number of installed IOS236 to 65535
v1 - Initial release

This application was based on Trucha Bug Restorer by WiiPower
and also used the iospatch code from FTPii
TBR was based on PatchMii by bushing, svpe and tona
and also contains code from:
Raven's Menu Loader Clone (IOS selection code)
Waninkoko's WAD Manager (WAD code)
AnyTitleDeleter (TITLE_UPPER and TITLE_LOWER)