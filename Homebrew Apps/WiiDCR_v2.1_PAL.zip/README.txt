+--------------------------------------------------+
| Wii Duplicated Channel Remover v2.1 by Waninkoko |
+--------------------------------------------------+
|              www.teknoconsolas.info              |
+--------------------------------------------------+

+--------------+
| DESCRIPTION: |
+--------------+

This application removes the duplicated channels installed after upgrading the Wii
with a game from a different region.


+-------------+
| HOW TO USE: |
+-------------+

Just run the application and it will autodetect the duplicated channels and remove them.


+--------+
| NOTES: |
+--------+

IMPORTANT NOTE: Use the specific version for your Wii!!
DISCLAIMER:     I don't take any responsability if your Wii gets damaged.


+--------+
| KUDOS: |
+--------+

bushing, marcan, pistu and Vasco_Almeida.
