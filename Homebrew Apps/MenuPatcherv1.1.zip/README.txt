+--------------------------------+
|   [+] MenuPatcher v1.1         |
|       developed by Waninkoko   |
+--------------------------------+
|     wwww.teknoconsolas.info    |
+--------------------------------+


[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.


[ DESCRIPTION ]:

- This application patches the System Menu in memory to run it under
  Custom IOS and allow backup loading through disc channel.


[ KUDOS ]:

- Team Twiizers and devkitPRO devs for their great work in libogc.
- marcan, unstub code.
- All the betatesters.