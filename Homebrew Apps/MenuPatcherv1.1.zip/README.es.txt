+--------------------------------+
|   [+] MenuPatcher v1.1         |
|       developed by Waninkoko   |
+--------------------------------+
|     wwww.teknoconsolas.info    |
+--------------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DAÑO EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- Esta aplicacion parchea el System Menu en memoria para ejecutarlo
  bajo Custom IOS y permitir la carga de backups a traves del Canal Disco.


[ KUDOS ]:

- Team Twiizers y devkitPRO devs por su gran trabajo en libogc.
- marcan, unstub code.
- Todos los betatesters.
