+------------------------------------+
|   [+] Custom IOS Downgrader v1.0   |
|       developed by Waninkoko       |
+------------------------------------+
|       www.teknoconsolas.info       |
+------------------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DA�O EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- Esta aplicacion te permite downgradear el firmware de tu Wii a
  cualquier version disponible.


[ REQUISITOS ]:

- Custom IOS37 rev 03 o superior.
- Conexion a internet.


[ COMO USARLO ]:

- Ejecuta la aplicacion y selecciona la version de firmware a instalar.


[ KUDOS ]:

- Team Twiizers y devkitPRO devs por su gran trabajo en libogc.
- Todos los betatesters.
- nitrotux, por su IOS5.
