#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <wiiuse/wpad.h>
#include <ogc/ipc.h>
#include <gccore.h>
#include <di/di.h>

GXRModeObj *rmode;
void* xfb = NULL;

volatile int read_semaphore = 1;
int read_callback(int ret, void* usrdata);

int get_buttons(){
	WPAD_ScanPads();
	return WPAD_ButtonsDown(0);
}

void init_all(){
	VIDEO_Init();
	WPAD_Init();
 
	rmode = VIDEO_GetPreferredMode(NULL);
	
	xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
	
	console_init (xfb, 20, 64, rmode->fbWidth, rmode->xfbHeight, rmode->fbWidth * 2);
	
	VIDEO_Configure(rmode);
	VIDEO_ClearFrameBuffer(rmode, xfb, COLOR_BLACK);
	VIDEO_SetNextFramebuffer(xfb);
	VIDEO_SetBlack(FALSE);
	VIDEO_Flush();
	VIDEO_WaitVSync();
	
	if(rmode->viTVMode&VI_NON_INTERLACE) VIDEO_WaitVSync();
}	
	

int main(){
	DI_Init();
	DI_DriveID di_id;
	uint32_t val;

	init_all();
	DI_Mount();
	printf("\nDVDX stub init complete, waiting for drive\n");
	int ios = IOS_GetVersion();
	printf("Reloaded IOS%d\n",ios);
	while(DI_GetStatus() & DVD_INIT);

	if(DI_GetStatus() & DVD_READY){
		uint8_t *buf = memalign(32, 0x800);
		if(!buf){
			printf("Memory allocation failed, returning.\n");
			DI_Close();
			exit(-1);
		}

		if(DI_GetStatus() & DVD_D0)
			printf("Currently in D0 mode\n");
		if(DI_GetStatus() & DVD_A8)
			printf("Currently in A8 mode\n");
		
		DI_Identify(&di_id);
		printf("Your drives firmware was written on: %08X\n",di_id.rel_date);
		printf("Drive device code: %04X\n",di_id.dev_code);

		DI_Eject();

		printf("Please take your disc and press A on your WiiMote to continue.\n");
		while(!(get_buttons() & WPAD_BUTTON_A));
		printf("\n\n");
		DI_GetCoverRegister(&val);	

		if(val & 0x1)	// True if no disc inside, use (val & 0x2) for true if disc inside.
			printf("No disc inside! Please re-insert your disc.\n");
		else
			printf("There's a disc inside, but it ain't spinning! Spinning it up for you.\n");

		DI_Mount();
		printf("Waiting on re-init\n\n");
		while(DI_GetStatus() & DVD_INIT);

		int ret = DI_ReadDVD(buf, 1, 1);
		printf("DI_ReadDVD returns %d\n",ret);

		if(ret){
			DI_GetError(&val);
			printf("The read failed, DI_GetError returned: 0x%08X\n",val);
			printf("Press HOME to go back to the loader\n");
			while(!(get_buttons() & WPAD_BUTTON_HOME));
			DI_Close();
			exit(0);
		}

		DI_ReadDVDAsync(buf, 1, 0, read_callback);
		while(read_semaphore);
		printf("Async read done!\n");

		DI_ReadDVDPhysical(buf);
		int x,y,i = 0;

		printf("Physical sector of your disc:\n");

		for(x = 0; x < 0x10; x++){
			for(y = 0; y < 0x14; y++){
				i++;
				printf("%02X ",buf[i]);
			}
			printf("\n");
		}
		free(buf);

	}
	else
	{
		printf("An error has occured, current status: 0x%08X\n",DI_GetStatus());
	}
	printf("Closed DI device. Press HOME to go back to the loader\n");
	while(!(get_buttons() & WPAD_BUTTON_HOME));
	DI_Close();
	exit(0);
}

int read_callback(int ret, void* usrdata){
	read_semaphore = 0;
	return 0;
}
