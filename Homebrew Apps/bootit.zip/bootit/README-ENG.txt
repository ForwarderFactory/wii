----------------------
- Introducci�n
----------------------

Bliight is a generic filesystem loader for wiilinux, which should let you boot a filesystem installed on any wiilinux
compatible device. It also lets you boot from a filesystem image, qhich should simplifcate the use of wiilinux to
those users that don�t want to do partitions on their sdcard.

This kernel has support for wireless modules, to use these modules you must install udev and wireless tools on xwhiite. These
applications and the kernel modules for the wireless/network adapters are included on the bliight and xwhiite filesystem images
given with this tool. The only wireless driver tested is Ralink rt73 usb.


----------------------
- Necessary tools
----------------------

1) 1GB SDcard (2GB for bliight), or a similar usb hard disck, formatted on Fat32 (NTFS doesn�t works, as writting isn�t supported by the kernel)
2) USB Keyboard
3) A wii console with the Homebrew channel or twilight hack installed

Optional:

4) USB-HUB * read known problems
5) USB mouse * read known problems
6) USB wireless/ethernet adapter * read known problems

----------------------
- Instalaci�n
----------------------

1) Copy the "apps" directory to the root of your SDCard
2) If you want to boot a preinstalled wiilinux filesystem (using whiite or whiite installer), copy the  "pivot_root" and "chroot" files 
   inside the "extra" directory to your filesystem "/bin" directory, and create a directory called "/old-root" in the root of your filesystem.

3) If you want to boot any of the filesystem images  (bliight.img or xwhiite.img), copy them to the root of your device (SDCard or USB hard disk)

----------------------
- Configuration
----------------------

1) Launch "boot-it" using the Homebrew Channel. The first time it will show you a menu:

- Boot installed system : Lets you access the boot menu
- Return to Wii menu : Lets you reboot

2) Use the keyboad arrows to move up/down the selected option, ad press "Enter". If you selected 
"Boot installed system" oyou will see a new menu:
- USB : To boot a filesystem installed on a USB hard disk partition 
- SDCard : To boot a filesystem installed on a SDCard partition 
- Disc image : To boot a filesystem image file on a USB or SDCard

If you select USB or SDCard, you will see a menu to select the partition (1,2,3...). Introduce the partition number. and press enter.
If everithing is OK, it will start to boot that filesystem

If you select "Disc image", It will ask you the device where it is installed (USB o SDCard), and then you will have to introduce
the filename (bliight.img, xwhiite.img, etc...).

If everything is OK, a file called "wiilinux.cfg" will be created in the root of your SDCard. There will be saved the configuration. If
you want to reconfigure "boot it", delete that file.


----------------------
-  Known problems
----------------------

Q) The USB Keyboard does not work.
A) If you have a USB mous plugged in, iterchange the usb port where they are plugged, or unplug the mouse

Q) It says that some files are missing (pivot_root, chroot, old-root)
A) If you are booting a previously installed wiilinux (xwhiite or bliight installed in the second partition of your sdcard) you will 
have to copy the contents of the "extras" directory to the root of your wiilinux filesystem.


----------------------
-  Thanks
----------------------
Thanks to all the wii-linux developpers:
- The gc-linux team and Isobel, who did this possible
- All the #wii-linux contributors: Muzer, Bertjan, T7g... the list is very long
- Special thanks to t7g and berjan for "bliight" and "xwhiite"
- Of course, thanks to the Team Twiizers, for their Homebrew channel and Twilight hack

Any problems, ask them on #wiilinux at efnet.
