----------------------
- Introducci�n
----------------------

Se trata de un gestor de arranque para wii-linux, el cual deber�a permitir arrancar un sistema de ficheros instalado en cualquier dispositivo compatible con wii-linux. Adem�s, permite arrancar desde una imagen del sistema de archivos, lo que facilitar� su uso a aquellos usuarios que no quieran realizar una partici�n o que en un momento dado quieran recuperar el espacio usado en los dispositivos sin necesidad de perder su instalaci�n.

Este kernel tiene soporte para m�dulos de wireless, para instalar los drivers ser� necesario tener instalado udev en xwhiite, y las wireless tools. Estas aplcaciones, los drivers y firmwares soportados por el kernel est�n inlcuidos en las im�genes de bliight y xwhiite suministradas. El �nico driver wireless testeado es el Ralink rt73 usb.

----------------------
- Materiales necesarios
----------------------

1) Tarjeta SD de al menos 1 GB (2GB para la imagen de bliight), o pendrive de similares caracter�sticas, formateados en Fat32 (NTFS no vale, ya que no est� soportada la escritura en este sistema de ficheros dentro del kernel)
2) Teclado USB
3) Tener instalado el Homebrew Channel o el Twilight hack en la consola

Opcional:

4) USB-HUB * leer problemas conocidos
5) Rat�n USB * leer problemas conocidos
6) Adaptador USB wireless/ethernet * leer problemas conocidos

----------------------
- Instalaci�n
----------------------

1) Copiar el directorio "apps" a la ra�z de una tarjeta SD.
2) En caso de intentar arrancar un sistema de ficheros preinstalado, copiar los archivos "pivot_root" y "chroot" dentro del directorio "extra" al directorio "/bin" dentro de vuestra instalacion previa, y cread un directorio llamado "/old-root" en la ra�z de vuestro sistema de ficheros.
3) En caso de querer usar alguno de las im�genes de sistemas de ficheros disponibles (bliight.img o xwhiite.img), copiadlas en la ra�z del dispositivo (USB o SDCard) en el que las quer�is instalar.

----------------------
- Configuraci�n
----------------------

1) Lanzar la aplicaci�n ""boot-it" desde el homebrew channel. La primera vez que la lanc�is os aparecer� un men� de configuraci�n:

- Boot installed system : Permite acceder al men� para arrancar el sistema preinstalado
- Return to Wii menu : Permite cerrar el programa y volver al men� de wii.

2) Con las flechas del teclado USB, moved arriba o abajo para seleccionar la opci�n deseada, y presionad "Enter". Si hab�is seleccionado "Boot installed system" os aparecer� un men� como el siguiente:
- USB : Para arrancar desde el sistema de ficheros instalado en una partici�n de un disco USB
- SDCard : Para arrancar desde el sistema de ficheros instalado en una partici�n de una tarjeta SD
- Disc image : Para arrancar desde un archivo imagen de sistema de ficheros en una tarjeta SD o USB.

Tanto si seleccion�is USB o SDCard, os aparecer� un men� para elejir la partici�n en la que est� instalado (1,2,3...). Introduc�s el n�mero de la partici�n y le d�is a enter. Si todo ha salido bien, arrancar� el sistema de ficheros instalado ah�.

En caso de seleccionar "Disc image", os preguntar� el dispositivo en el que se encuentra (USB o SDCard), y luego preguntar� por el nombre. Ah� escrib�s el nombre del fichero (bliight.img, xwhiite.img, etc...). Es importante no usar "backspace" para borrar si os equivoc�is, ya que no funciona muy bien.

Si todo ha ido bien, se crear� un archivo de configuraci�n llamado "wiilinux.cfg" en la ra�z de la tarjeta SD. Ah� est� la informaci�n que hab�is introducido, y que usar� las pr�ximas veces para arrancar. En caso de querer ver una vez m�s el men�, borrad ese archivo.

----------------------
-  Problemas conocidos
----------------------

Q) El teclado USB no funciona en el men�
A) Si tienes conectado un rat�n usb, interc�mbiales el puerto USB , o desconecta el rat�n.

Q) Me dice que no encuentra archivos (pivot_root, chroot, old-root)
A) Si est�s arrancando desde una instalaci�n de wiilinux antigua (xwhiite o bliight instalados en la segunda partici�n de la tarjeta sd) tendr�s que copiar los contenidos de la carpeta "extras" al directorio "bin" de tu instalaci�n de , y crear una carpeta llamada "old-root" en el directorio ra�z de tu instalaci�n.

----------------------
-  Agradecimientos
----------------------
Gracias a todos los desarrolladores de wii-linux
- Al equipo gc-linux  eIsobel en concreto, quienes hicieron esto posible
- Todos los contribuidores de #wiilinux: Muzer, Bertjan, T7g... la lista es muy larga
- Agradecimientos especiales para t7g y berjan por "bliight" y "xwhiite"
- Por supuesto, gracias al Team Twiizer por su Homebrew channel y su twilight hack

Cualquier problema, preguntad en el canal  #wiilinux en efnet.net

