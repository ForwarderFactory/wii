Use arrow keys:
Up:Fire
Down:Suck
Left and right move.
z and x spin the board.
a does a 180 spin

No idea what exit is. Ctrl-alt-del :D