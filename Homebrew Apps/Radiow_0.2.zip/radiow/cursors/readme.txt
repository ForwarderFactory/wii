======================================================================

WII HOMEBREW CURSORS
Created by and (c)Copyright 2008 drmr
Release 1.1a, 2008-08-10

======================================================================

LICENSE

This artwork library is free software: you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This artwork library is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this artwork library. If not, see
<http://www.gnu.org/licenses/>.

======================================================================

PLEASE NOTE

Source code, for this artwork library, means: Raster PNG images. By
the terms of the LGPL, you are obliged to include the source code with
your software, so you may follow the practice of including the archive
of this artwork library alongside with your source code.

The exception in section 6 of the GNU Lesser General Public License
covers the use of elements of this artwork library in a GUI.

If you use parts of this artwork library in your software, alongside
with the required credits in your software, I would appreciate a
notice on my Wiibrew talk page:
http://wiibrew.org/wiki/User_talk:Drmr

======================================================================

CONTAINS THE FOLLOWING CURSOR IMAGES

* Generic pointer cursor
* Generic drag cursor
* Generic open hand cursor
* Pointer, drag, and open hand cursors for players 1 to 4
* Generic B-button cursor
* Shadow images for all cursor types

======================================================================

HOW TO USE

All images are alpha-transparent PNG icons which should be fairly easy
for you to import or load into your homebrew software. The image
format is 96x96 pixels for every image, the cursor size itself is
selected to match the original Wii cursor's size on a 640x480 canvas.

All pointers are set up to align the image's hotspot (usually the
fingertip) at the center of the image, at x:48/y:48. This enables you
to rotate the image around the hotspot if you would like to replicate
the Wii remote's roll value.

The shadow images follow the same principle as the cursor images.
Choose an appropriate offset for them to appear beneath the cursor
image (x+1 and y+2 pixels is a good starting point).

======================================================================

VERSIONS

2008-07-07, v1.0:  Initial release
2008-07-07, v1.1:  Added open hand cursors
2008-07-07, v1.1a: Re-released under the LGPL

======================================================================

CONTACT

To contact me please use my talk page at
http://wiibrew.org/wiki/User_talk:Drmr

================================================================== EOF