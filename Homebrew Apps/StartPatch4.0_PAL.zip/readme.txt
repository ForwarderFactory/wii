StartPatchv4.0

Features:
-------------------------------
Region free

Region free channels

check update 

No health check

move disc channel

---------------------------------
FAQs
---------------------------------
-risck the brik my wii?

-yes, only whether energy

-use as�?

-launch dol in (HBC)or others launchers ,gecko os,etc

-I need for work StartPatchv4.0?�

-(HBC)or others launchers

-I can use it in another sysmenu?

-no, patches are only for SM4.0,values are different in another sysmenu
------------------------------------
(HBC)=Hombrew Channel