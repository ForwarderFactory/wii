+---------------------------------------+
|   [+] SD/USB Loader v1.5              |
|       developed by Waninkoko/kwiirk   |
+---------------------------------------+
|         wwww.teknoconsolas.es         |
+---------------------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DA�O EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- SD/USB Loader es una aplicacion para la Nintendo Wii que te permite
  poder instalar y cargar tus backups desde un dispositivo de
  almacenamiento USB o SD/SDHC.


[ REQUISITOS ]:

- Custom IOS36 rev 10 o superior.
- Un dispositivo USB/SD/SDHC con una particion libre para juegos.


[ NOTAS ]:

- Reemplazar imagen de fondo (solo formato PNG):

  Para reemplazar la imagen de fondo de la aplicacion, copia el fichero de la
  imagen con el nombre "background.png" dentro del directorio "usb-loader" en
  la raiz de la tarjeta SD.


- A�adir caratula a un juego (solo formato PNG):

  Para a�adir una caratula a un juego, copia la imagen de la caratula dentro
  del directorio "usb-loader/covers" en la raiz de la tarjeta SD. El fichero
  debe tener el mismo nombre que la ID del juego (con extension .png).


[ KUDOS ]:

- Team Twiizers y devkitPRO devs por su gran trabajo en libogc.
- Todos los betatesters.
- kwiirk, por su modulo EHCI.
- neimod, por el Custom IOS module.
