//Additional libraries...
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <iostream>
#include <string>
#include <math.h>
#include <asndlib.h>
#include <fat.h>
#include <gccore.h>
#include <gctypes.h>
#include <mp3player.h>
#include <wiisprite.h>
#include <wiiuse/wpad.h>

//***Begin Includes for Linked-In files
#include <bg_music_mp3.h>
#include <effect3_wav.h>

#include <zero_left_png.h>
#include <zero_png.h>
#include <zero_right_png.h>

#include <one_left_png.h>
#include <one_png.h>
#include <one_right_png.h>

#include <two_left_png.h>
#include <two_png.h>
#include <two_right_png.h>

#include <three_left_png.h>
#include <three_png.h>
#include <three_right_png.h>

#include <four_left_png.h>
#include <four_png.h>
#include <four_right_png.h>

#include <five_left_png.h>
#include <five_png.h>
#include <five_right_png.h>

#include <six_left_png.h>
#include <six_png.h>
#include <six_right_png.h>

#include <seven_left_png.h>
#include <seven_png.h>
#include <seven_right_png.h>

#include <eight_left_png.h>
#include <eight_png.h>
#include <eight_right_png.h>

#include <nine_left_png.h>
#include <nine_png.h>
#include <nine_right_png.h>

#include <back_in_png.h>
#include <back_out_png.h>
#include <bb_status_ok_png.h>
#include <bb_status_png.h>
#include <calibrate_png.h>
#include <caution_png.h>
#include <cog_in_png.h>
#include <cog_out_png.h>
#include <cog_png.h>
#include <cursor_png.h>
#include <needle_png.h>
#include <rotary_scale_png.h>
#include <exit_in_png.h>
#include <exit_out_png.h>
#include <kg_rule1_png.h>
#include <kg_rule2_png.h>
#include <kg_rule3_png.h>
#include <lb_rule1_png.h>
#include <lb_rule2_png.h>
#include <lb_rule3_png.h>
#include <lb_rule4_png.h>
#include <lb_rule5_png.h>
#include <main_png.h>
#include <noNumber_left_png.h>
#include <noNumber_png.h>
#include <noNumber_right_png.h>
#include <pro_in_png.h>
#include <pro_out_png.h>
#include <pro_png.h>
#include <target_png.h>
#include <bulls_eye_png.h>
#include <weight_in_png.h>
#include <weight_out_png.h>
#include <weight_png.h>
#include <x_hair_png.h>
//***End Includes for Linked-In files


//Setup some required graphics objects
static void *xfb = NULL;
static GXRModeObj *rmode = NULL;

//Define libwiisprite namespace
using namespace wsp;

GameWindow gameWin;

//Sprites
Sprite cursor, proButton, weightButton, cogButton, exitButton, backButton, mainBG, weightBG, cogBG, proBG,
	   x_hair, kg_rule1, kg_rule2, kg_rule3, lb_rule1, lb_rule2, lb_rule3, lb_rule4, lb_rule5, bbStatus, 
	   bbStatusOK, calibrate, needle, rot_scale, caution1, caution2, target_button, 
	   target1, bulls_eye1, target2, bulls_eye2, target3, bulls_eye3, target4, bulls_eye4, target5, bulls_eye5, 
	   target6, bulls_eye6, target7, bulls_eye7, target8, bulls_eye8, kgfirst, kgsecond, kgthird, kgfourth, kgfifth, 
	   kg_ul_first, kg_ul_second, kg_ul_third, kg_ul_fourth, kg_ul_fifth,
	   kg_ur_first, kg_ur_second, kg_ur_third, kg_ur_fourth, kg_ur_fifth,
	   kg_ll_first, kg_ll_second, kg_ll_third, kg_ll_fourth, kg_ll_fifth,
	   kg_lr_first, kg_lr_second, kg_lr_third, kg_lr_fourth, kg_lr_fifth,
	   lbfirst, lbsecond, lbthird, lbfourth, lbfifth,
	   lb_ul_first, lb_ul_second, lb_ul_third, lb_ul_fourth, lb_ul_fifth,
	   lb_ur_first, lb_ur_second, lb_ur_third, lb_ur_fourth, lb_ur_fifth,
	   lb_ll_first, lb_ll_second, lb_ll_third, lb_ll_fourth, lb_ll_fifth,
	   lb_lr_first, lb_lr_second, lb_lr_third, lb_lr_fourth, lb_lr_fifth;


//Images for the sprites	
Image cursorImage, x_hairImage, kg_ruleImage1, kg_ruleImage2, kg_ruleImage3, lb_ruleImage1, lb_ruleImage2, needleImage, rot_scaleImage,
	  lb_ruleImage3, lb_ruleImage4, lb_ruleImage5, bbStatusImage, bbStatusOKImage, weight_in_Image, weight_out_Image, 
	  cog_in_Image, cog_out_Image, exit_in_Image, exit_out_Image, pro_in_Image, calibrateImage,
	  pro_out_Image, back_in_Image, back_out_Image, mainBGImage, weightBGImage, cogBGImage, 
	  proBGImage, cautionImage, targetImage, zeroImage, oneImage, twoImage, threeImage, 
	  fourImage, fiveImage, sixImage, sevenImage, eightImage, nineImage, noNumberImage,
	  zeroImage_left, oneImage_left, twoImage_left, threeImage_left, fourImage_left, bulls_eyeImage,
	  fiveImage_left, sixImage_left, sevenImage_left, eightImage_left, nineImage_left, noNumberImage_left,
	  zeroImage_right, oneImage_right, twoImage_right, threeImage_right, fourImage_right, 
	  fiveImage_right, sixImage_right, sevenImage_right, eightImage_right, nineImage_right, noNumberImage_right;



//Digital Helper: Puts the weight data into a string for easier manipulation
std::string formatData(int data)
{	
	std::ostringstream buffer;
	
	buffer << data;
	std::string str = buffer.str();
	
	return str;
}


long mp3Size;
unsigned char * buffer;
//For loading mp3 files from the SD card, don't call this function until FAT has been initialized.
void formatMusicFile() 
{	
	MP3Player_Init();
	
	//Find the file
	std::string filename = "fat3:/apps/BBPRO/files/bg_music.mp3";
	FILE *fd = fopen(filename.c_str(), "rb");	
	
	//Get music file info/size
	fseek(fd , 0 , SEEK_END);
	mp3Size = ftell(fd);
	rewind(fd);
	
	//Read in the music file
	buffer = (unsigned char*)malloc(sizeof(unsigned char)*mp3Size);
	fread (buffer, 1, mp3Size, fd);
	fclose(fd);
}


//Assigns a number Image for the digital display based on the string's chars
Image* assignImage(char c)
{
	if(c == '0')
		return &zeroImage;
	else if(c == '1')
		return &oneImage;
	else if(c == '2')
		return &twoImage;
	else if(c == '3')
		return &threeImage;
	else if(c == '4')
		return &fourImage;
	else if(c == '5')
		return &fiveImage;
	else if(c == '6')
		return &sixImage;
	else if(c == '7')
		return &sevenImage;
	else if(c == '8')
		return &eightImage;
	else if(c == '9')
		return &nineImage;
	else
		return &noNumberImage;
}
Image* assignImageLeft(char c)
{
	if(c == '0')
		return &zeroImage_left;
	else if(c == '1')
		return &oneImage_left;
	else if(c == '2')
		return &twoImage_left;
	else if(c == '3')
		return &threeImage_left;
	else if(c == '4')
		return &fourImage_left;
	else if(c == '5')
		return &fiveImage_left;
	else if(c == '6')
		return &sixImage_left;
	else if(c == '7')
		return &sevenImage_left;
	else if(c == '8')
		return &eightImage_left;
	else if(c == '9')
		return &nineImage_left;
	else
		return &noNumberImage_left;
}
Image* assignImageRight(char c)
{
	if(c == '0')
		return &zeroImage_right;
	else if(c == '1')
		return &oneImage_right;
	else if(c == '2')
		return &twoImage_right;
	else if(c == '3')
		return &threeImage_right;
	else if(c == '4')
		return &fourImage_right;
	else if(c == '5')
		return &fiveImage_right;
	else if(c == '6')
		return &sixImage_right;
	else if(c == '7')
		return &sevenImage_right;
	else if(c == '8')
		return &eightImage_right;
	else if(c == '9')
		return &nineImage_right;
	else
		return &noNumberImage_right;
}


//Where the magic happens...
int main(int argc, char **argv)
{
	ir_t irObject;
	//wii_board_t wbb;
	expansion_t exp;	
	
	bool running=true, decreasing=true, targets = false, calibrating = false, foundBB = false,
		 cogActions = false, weightActions = false, proActions = false, rumbling = false,
		 backActions = false, targetActions = false, exitActions = false, rotaryOn = false, debugging = false;
		 
	std::string option = "main", kgstring, lbstring;	
		
	int ave_count=0, offset_ave=0, bbport=0, counter=0;
	
	double lbs, kgs, weights, ul_weight=0, ur_weight=0, ll_weight=0, lr_weight=0, ave_weights=0, ul_ave_weight=0, 
		   ur_ave_weight=0, ll_ave_weight=0, lr_ave_weight=0, offset=0, offset_factor=0, ul_offset=0, ul_offset_factor=0, 
		   ur_offset=0, ur_offset_factor=0, ll_offset=0, ll_offset_factor=0, lr_offset=0, lr_offset_factor=0, 
		   transFade=255, zooming=1;
	
	//Various initializations
	VIDEO_Init();
	fatInitDefault();	
	ASND_Init();
	ASND_Pause(0);	
	MP3Player_Volume(255);
	MP3Player_Init();		
	gameWin.InitVideo();
	rmode = VIDEO_GetPreferredMode(NULL);
	xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
	console_init(xfb,20,20,rmode->fbWidth,rmode->xfbHeight,rmode->fbWidth*VI_DISPLAY_PIX_SZ);
	printf("\x1b[2;0H");
	printf ("\x1b[%d;%dH", 12, 30);	
	VIDEO_Configure(rmode);
	VIDEO_SetBlack(false);
	VIDEO_SetNextFramebuffer(xfb);	
	VIDEO_Flush();
	VIDEO_WaitVSync();
	if(rmode->viTVMode&VI_NON_INTERLACE) 
		VIDEO_WaitVSync();		
	
	printf("L O A D I N G . . .\n");
	GX_InvalidateTexAll();
	
	//formatMusicFile();
	MP3Player_Volume(255);
	ASND_Pause(0);
	if (!MP3Player_IsPlaying())
	{		
		MP3Player_PlayBuffer(bg_music_mp3,bg_music_mp3_size,NULL);
	}
	
	//Sets the number of sprites attached to each layer
	LayerManager menu(8), pro(65), cog(13), weight(24), load(1), rotary(5);
	
	//Direct load from SD option
	/*	
	// *** Only used if not using the default linked file option.
	// *** Linking the files directly makes for much faster load times, but makes editing the Images more cumbersome.	
	
	if(cursorImage.LoadImage("fat3:/apps/BBPRO/files/cursor.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(bgImage.LoadImage("fat3:/apps/BBPRO/files/main.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	
	if(weight_in_Image.LoadImage("fat3:/apps/BBPRO/files/weight_in.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(weight_out_Image.LoadImage("fat3:/apps/BBPRO/files/weight_out.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	
	if(cog_in_Image.LoadImage("fat3:/apps/BBPRO/files/cog_in.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(cog_out_Image.LoadImage("fat3:/apps/BBPRO/files/cog_out.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	
	if(exit_in_Image.LoadImage("fat3:/apps/BBPRO/files/exit_in.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(exit_out_Image.LoadImage("fat3:/apps/BBPRO/files/exit_out.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(pro_in_Image.LoadImage("fat3:/apps/BBPRO/files/pro_in.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(pro_out_Image.LoadImage("fat3:/apps/BBPRO/files/pro_out.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	
	if(back_in_Image.LoadImage("fat3:/apps/BBPRO/files/back_in.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(back_out_Image.LoadImage("fat3:/apps/BBPRO/files/back_out.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");	
	
	if(weightBGImage.LoadImage("fat3:/apps/BBPRO/files/weight.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");	
	if(cogBGImage.LoadImage("fat3:/apps/BBPRO/files/cog.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(proBGImage.LoadImage("fat3:/apps/BBPRO/files/pro.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(x_hairImage.LoadImage("fat3:/apps/BBPRO/files/x_hair.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(needleImage.LoadImage("fat3:/apps/BBPRO/files/needle.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(rot_scaleImage.LoadImage("fat3:/apps/BBPRO/files/rotary_scale.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(kg_ruleImage1.LoadImage("fat3:/apps/BBPRO/files/kg_rule1.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(kg_ruleImage2.LoadImage("fat3:/apps/BBPRO/files/kg_rule2.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(kg_ruleImage3.LoadImage("fat3:/apps/BBPRO/files/kg_rule3.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(lb_ruleImage1.LoadImage("fat3:/apps/BBPRO/files/lb_rule1.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(lb_ruleImage2.LoadImage("fat3:/apps/BBPRO/files/lb_rule2.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(lb_ruleImage3.LoadImage("fat3:/apps/BBPRO/files/lb_rule3.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(lb_ruleImage4.LoadImage("fat3:/apps/BBPRO/files/lb_rule4.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(lb_ruleImage5.LoadImage("fat3:/apps/BBPRO/files/lb_rule5.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(bbStatusImage.LoadImage("fat3:/apps/BBPRO/files/bb_status.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(bbStatusOKImage.LoadImage("fat3:/apps/BBPRO/files/bb_status_ok.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(cautionImage.LoadImage("fat3:/apps/BBPRO/files/caution.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(targetImage.LoadImage("fat3:/apps/BBPRO/files/target.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(bulls_eyeImage.LoadImage("fat3:/apps/BBPRO/files/bulls_eye.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	
	if(calibrateImage.LoadImage("fat3:/apps/BBPRO/files/calibrate.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	
	
	if(zeroImage.LoadImage("fat3:/apps/BBPRO/files/zero.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(oneImage.LoadImage("fat3:/apps/BBPRO/files/one.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(twoImage.LoadImage("fat3:/apps/BBPRO/files/two.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(threeImage.LoadImage("fat3:/apps/BBPRO/files/three.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fourImage.LoadImage("fat3:/apps/BBPRO/files/four.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fiveImage.LoadImage("fat3:/apps/BBPRO/files/five.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sixImage.LoadImage("fat3:/apps/BBPRO/files/six.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sevenImage.LoadImage("fat3:/apps/BBPRO/files/seven.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(eightImage.LoadImage("fat3:/apps/BBPRO/files/eight.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(nineImage.LoadImage("fat3:/apps/BBPRO/files/nine.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");	


	if(zeroImage_left.LoadImage("fat3:/apps/BBPRO/files/zero_left.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(oneImage_left.LoadImage("fat3:/apps/BBPRO/files/one_left.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(twoImage_left.LoadImage("fat3:/apps/BBPRO/files/two_left.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(threeImage_left.LoadImage("fat3:/apps/BBPRO/files/three_left.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fourImage_left.LoadImage("fat3:/apps/BBPRO/files/four_left.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fiveImage_left.LoadImage("fat3:/apps/BBPRO/files/five_left.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sixImage_left.LoadImage("fat3:/apps/BBPRO/files/six_left.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sevenImage_left.LoadImage("fat3:/apps/BBPRO/files/seven_left.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(eightImage_left.LoadImage("fat3:/apps/BBPRO/files/eight_left.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(nineImage_left.LoadImage("fat3:/apps/BBPRO/files/nine_left.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	
	if(zeroImage_right.LoadImage("fat3:/apps/BBPRO/files/zero_right.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(oneImage_right.LoadImage("fat3:/apps/BBPRO/files/one_right.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(twoImage_right.LoadImage("fat3:/apps/BBPRO/files/two_right.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(threeImage_right.LoadImage("fat3:/apps/BBPRO/files/three_right.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fourImage_right.LoadImage("fat3:/apps/BBPRO/files/four_right.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fiveImage_right.LoadImage("fat3:/apps/BBPRO/files/five_right.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sixImage_right.LoadImage("fat3:/apps/BBPRO/files/six_right.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sevenImage_right.LoadImage("fat3:/apps/BBPRO/files/seven_right.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(eightImage_right.LoadImage("fat3:/apps/BBPRO/files/eight_right.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(nineImage_right.LoadImage("fat3:/apps/BBPRO/files/nine_right.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");	
		
	
		
	if(noNumberImage.LoadImage("fat3:/apps/BBPRO/files/noNumber.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(noNumberImage_left.LoadImage("fat3:/apps/BBPRO/files/noNumber_left.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(noNumberImage_right.LoadImage("fat3:/apps/BBPRO/files/noNumber_right.png") != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	*/
	
	//Load from linked in buffer
	if(cursorImage.LoadImage(cursor_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(mainBGImage.LoadImage(main_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	
	if(weight_in_Image.LoadImage(weight_in_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(weight_out_Image.LoadImage(weight_out_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	
	if(cog_in_Image.LoadImage(cog_in_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(cog_out_Image.LoadImage(cog_out_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	
	if(exit_in_Image.LoadImage(exit_in_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(exit_out_Image.LoadImage(exit_out_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(pro_in_Image.LoadImage(pro_in_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(pro_out_Image.LoadImage(pro_out_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	
	if(back_in_Image.LoadImage(back_in_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(back_out_Image.LoadImage(back_out_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");	
	
	if(weightBGImage.LoadImage(weight_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");	
	if(cogBGImage.LoadImage(cog_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(proBGImage.LoadImage(pro_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(x_hairImage.LoadImage(x_hair_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(kg_ruleImage1.LoadImage(kg_rule1_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(kg_ruleImage2.LoadImage(kg_rule2_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(kg_ruleImage3.LoadImage(kg_rule3_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
		
	if(lb_ruleImage1.LoadImage(lb_rule1_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(lb_ruleImage2.LoadImage(lb_rule2_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(lb_ruleImage3.LoadImage(lb_rule3_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(lb_ruleImage4.LoadImage(lb_rule4_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(lb_ruleImage5.LoadImage(lb_rule5_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(bbStatusImage.LoadImage(bb_status_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(bbStatusOKImage.LoadImage(bb_status_ok_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(cautionImage.LoadImage(caution_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(targetImage.LoadImage(target_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	if(bulls_eyeImage.LoadImage(bulls_eye_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	
	if(calibrateImage.LoadImage(calibrate_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	
	
	if(needleImage.LoadImage(needle_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(rot_scaleImage.LoadImage(rotary_scale_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	
	
	if(zeroImage.LoadImage(zero_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(oneImage.LoadImage(one_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(twoImage.LoadImage(two_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(threeImage.LoadImage(three_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fourImage.LoadImage(four_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fiveImage.LoadImage(five_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sixImage.LoadImage(six_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sevenImage.LoadImage(seven_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(eightImage.LoadImage(eight_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(nineImage.LoadImage(nine_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");	


	if(zeroImage_left.LoadImage(zero_left_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(oneImage_left.LoadImage(one_left_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(twoImage_left.LoadImage(two_left_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(threeImage_left.LoadImage(three_left_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fourImage_left.LoadImage(four_left_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fiveImage_left.LoadImage(five_left_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sixImage_left.LoadImage(six_left_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sevenImage_left.LoadImage(seven_left_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(eightImage_left.LoadImage(eight_left_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(nineImage_left.LoadImage(nine_left_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
		
	
	if(zeroImage_right.LoadImage(zero_right_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(oneImage_right.LoadImage(one_right_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(twoImage_right.LoadImage(two_right_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(threeImage_right.LoadImage(three_right_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fourImage_right.LoadImage(four_right_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(fiveImage_right.LoadImage(five_right_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sixImage_right.LoadImage(six_right_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(sevenImage_right.LoadImage(seven_right_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(eightImage_right.LoadImage(eight_right_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");		
	if(nineImage_right.LoadImage(nine_right_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");	
		
	
		
	if(noNumberImage.LoadImage(noNumber_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(noNumberImage_left.LoadImage(noNumber_left_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");
	if(noNumberImage_right.LoadImage(noNumber_right_png) != IMG_LOAD_ERROR_NONE) 
		printf("Image ERROR!\n");	
	
	
	//Assign initial attributes to our sprites
	cursor.SetImage(&cursorImage);
	cursor.SetPosition(320, 240);
	
	mainBG.SetImage(&mainBGImage);
	mainBG.SetPosition(0, 0);
	mainBG.SetVisible(true);
	
	proBG.SetImage(&proBGImage);
	proBG.SetPosition(0, 0);
	proBG.SetVisible(true);
	
	weightBG.SetImage(&weightBGImage);
	weightBG.SetPosition(0, 0);
	weightBG.SetVisible(true);
	
	rot_scale.SetImage(&rot_scaleImage);
	rot_scale.SetPosition(0, 0);
	rot_scale.SetVisible(true);
	
	cogBG.SetImage(&cogBGImage);
	cogBG.SetPosition(0, 0);
	cogBG.SetVisible(true);
	
	needle.SetImage(&needleImage);
	needle.SetPosition(315, 76);
	needle.SetVisible(true);
	
	proButton.SetImage(&pro_out_Image);	
	proButton.SetPosition(74, 135);
	proButton.DefineCollisionRectangle(0, 0, 111, 99);
	
	weightButton.SetImage(&weight_out_Image);
	weightButton.SetPosition(229, 135);
	weightButton.DefineCollisionRectangle(0, 0, 111, 99);
	
	cogButton.SetImage(&cog_out_Image);	
	cogButton.SetPosition(281, 261);
	cogButton.DefineCollisionRectangle(0, 0, 111, 99);
	
	exitButton.SetImage(&exit_out_Image);	
	exitButton.SetPosition(126, 261);
	exitButton.DefineCollisionRectangle(0, 0, 111, 99);
	
	backButton.SetImage(&back_out_Image);	
	backButton.SetPosition(10, 422);
	backButton.SetVisible(true);
	
	x_hair.SetImage(&x_hairImage);
	x_hair.SetPosition(322, 233);
	x_hair.SetVisible(true);
	x_hair.DefineCollisionRectangle(5, 5, 9, 9);
	
	kg_rule1.SetImage(&kg_ruleImage1);
	kg_rule1.SetPosition(272, 122);
	kg_rule1.SetVisible(true);
	
	kg_rule2.SetImage(&kg_ruleImage2);
	kg_rule2.SetPosition(272+1024, 122);
	kg_rule2.SetVisible(true);
	
	kg_rule3.SetImage(&kg_ruleImage3);
	kg_rule3.SetPosition(272+1024+1024, 122);
	kg_rule3.SetVisible(true);
	
	caution1.SetImage(&cautionImage);
	caution1.SetPosition(272+1024+1024+272, 122);
	caution1.SetVisible(true);
	
	lb_rule1.SetImage(&lb_ruleImage1);
	lb_rule1.SetPosition(272, 275);
	lb_rule1.SetVisible(true);
	
	lb_rule2.SetImage(&lb_ruleImage2);
	lb_rule2.SetPosition(272+1024, 275);
	lb_rule2.SetVisible(true);
	
	lb_rule3.SetImage(&lb_ruleImage3);
	lb_rule3.SetPosition(272+1024+1024, 275);
	lb_rule3.SetVisible(true);	
	
	lb_rule4.SetImage(&lb_ruleImage4);
	lb_rule4.SetPosition(272+1024+1024+1024, 275);
	lb_rule4.SetVisible(true);
	
	lb_rule5.SetImage(&lb_ruleImage5);
	lb_rule5.SetPosition(272+1024+1024+1024+1024, 275);
	lb_rule5.SetVisible(true);
	
	caution2.SetImage(&cautionImage);
	caution2.SetPosition(272+1024+1024+1024+1024+924, 275);
	caution2.SetVisible(true);
	
	bbStatus.SetImage(&bbStatusImage);
	bbStatus.SetPosition(470, 349);
	bbStatus.SetVisible(true);
	bbStatus.SetTransparency(255);
	
	target_button.SetImage(&targetImage);
	target_button.SetPosition(300, 408);
	target_button.SetVisible(true);
	
	//Bull's-Eye "images" are needed because DefineCollisionRectangle was behaving very erratically with the targets
	//for some reason.
	target1.SetImage(&targetImage);
	target1.SetPosition(302, 128);
	target1.SetVisible(true);
	bulls_eye1.SetImage(&bulls_eyeImage);
	bulls_eye1.SetPosition(302+26, 128+26);
	bulls_eye1.SetVisible(true);
	
	target2.SetImage(&targetImage);
	target2.SetPosition(191, 88);
	target2.SetVisible(true);
	bulls_eye2.SetImage(&bulls_eyeImage);
	bulls_eye2.SetPosition(191+26, 88+26);
	bulls_eye2.SetVisible(true);
	
	target3.SetImage(&targetImage);
	target3.SetPosition(91, 208);
	target3.SetVisible(true);
	bulls_eye3.SetImage(&bulls_eyeImage);
	bulls_eye3.SetPosition(91+26, 208+26);
	bulls_eye3.SetVisible(true);
	
	target4.SetImage(&targetImage);
	target4.SetPosition(191, 336);
	target4.SetVisible(true);
	bulls_eye4.SetImage(&bulls_eyeImage);
	bulls_eye4.SetPosition(191+26, 336+26);
	bulls_eye4.SetVisible(true);
	
	target5.SetImage(&targetImage);
	target5.SetPosition(301, 290);
	target5.SetVisible(true);
	bulls_eye5.SetImage(&bulls_eyeImage);
	bulls_eye5.SetPosition(301+26, 290+26);
	bulls_eye5.SetVisible(true);
	
	target6.SetImage(&targetImage);
	target6.SetPosition(413, 336);
	target6.SetVisible(true);
	bulls_eye6.SetImage(&bulls_eyeImage);
	bulls_eye6.SetPosition(413+26, 336+26);
	bulls_eye6.SetVisible(true);
	
	target7.SetImage(&targetImage);
	target7.SetPosition(512, 211);
	target7.SetVisible(true);
	bulls_eye7.SetImage(&bulls_eyeImage);
	bulls_eye7.SetPosition(512+26, 211+26);
	bulls_eye7.SetVisible(true);
	
	target8.SetImage(&targetImage);
	target8.SetPosition(412, 88);
	target8.SetVisible(true);
	bulls_eye8.SetImage(&bulls_eyeImage);
	bulls_eye8.SetPosition(412+26, 88+26);
	bulls_eye8.SetVisible(true);
	
	target1.SetTransparency(0);
	target2.SetTransparency(0);
	target3.SetTransparency(0);
	target4.SetTransparency(0);
	target5.SetTransparency(0);
	target6.SetTransparency(0);
	target7.SetTransparency(0);
	target8.SetTransparency(0);
	
	calibrate.SetImage(&calibrateImage);
	calibrate.SetPosition(162, 154);
	calibrate.SetVisible(false);
	
	
	
	kgfirst.SetImage(&noNumberImage);
	kgfirst.SetPosition(285, 193);
	kgfirst.SetVisible(true);
	
	kgsecond.SetImage(&noNumberImage);
	kgsecond.SetPosition(302, 193);
	kgsecond.SetVisible(true);	
	
	kgthird.SetImage(&noNumberImage);
	kgthird.SetPosition(319, 193);
	kgthird.SetVisible(true);	
	
	kgfourth.SetImage(&noNumberImage);
	kgfourth.SetPosition(340, 193);
	kgfourth.SetVisible(true);	
	
	kgfifth.SetImage(&noNumberImage);
	kgfifth.SetPosition(357, 193);
	kgfifth.SetVisible(true);	
	
	
	
	kg_ul_first.SetImage(&noNumberImage);
	kg_ul_first.SetPosition(47, 118);
	kg_ul_first.SetVisible(true);	
	
	kg_ul_second.SetImage(&noNumberImage);
	kg_ul_second.SetPosition(59, 106);
	kg_ul_second.SetVisible(true);	
	
	kg_ul_third.SetImage(&noNumberImage);
	kg_ul_third.SetPosition(71, 94);
	kg_ul_third.SetVisible(true);	
	
	kg_ul_fourth.SetImage(&noNumberImage);
	kg_ul_fourth.SetPosition(86, 79);
	kg_ul_fourth.SetVisible(true);	
	
	kg_ul_fifth.SetImage(&noNumberImage);
	kg_ul_fifth.SetPosition(98, 67);
	kg_ul_fifth.SetVisible(true);
	
	
	
	kg_ur_first.SetImage(&noNumberImage);
	kg_ur_first.SetPosition(528, 67);
	kg_ur_first.SetVisible(true);	
	
	kg_ur_second.SetImage(&noNumberImage);
	kg_ur_second.SetPosition(540, 79);
	kg_ur_second.SetVisible(true);	
	
	kg_ur_third.SetImage(&noNumberImage);
	kg_ur_third.SetPosition(552, 91);
	kg_ur_third.SetVisible(true);	
	
	kg_ur_fourth.SetImage(&noNumberImage);
	kg_ur_fourth.SetPosition(567, 106);
	kg_ur_fourth.SetVisible(true);	
	
	kg_ur_fifth.SetImage(&noNumberImage);
	kg_ur_fifth.SetPosition(579, 118);
	kg_ur_fifth.SetVisible(true);
	
	
	
	kg_ll_first.SetImage(&noNumberImage);
	kg_ll_first.SetPosition(79, 288);
	kg_ll_first.SetVisible(true);	
	
	kg_ll_second.SetImage(&noNumberImage);
	kg_ll_second.SetPosition(91, 300);
	kg_ll_second.SetVisible(true);	
	
	kg_ll_third.SetImage(&noNumberImage);
	kg_ll_third.SetPosition(103, 312);
	kg_ll_third.SetVisible(true);	
	
	kg_ll_fourth.SetImage(&noNumberImage);
	kg_ll_fourth.SetPosition(119, 327);
	kg_ll_fourth.SetVisible(true);	
	
	kg_ll_fifth.SetImage(&noNumberImage);
	kg_ll_fifth.SetPosition(130, 339);
	kg_ll_fifth.SetVisible(true);
	
	
	
	kg_lr_first.SetImage(&noNumberImage);
	kg_lr_first.SetPosition(492, 347);
	kg_lr_first.SetVisible(true);	
	
	kg_lr_second.SetImage(&noNumberImage);
	kg_lr_second.SetPosition(504, 335);
	kg_lr_second.SetVisible(true);	
	
	kg_lr_third.SetImage(&noNumberImage);
	kg_lr_third.SetPosition(516, 323);
	kg_lr_third.SetVisible(true);	
	
	kg_lr_fourth.SetImage(&noNumberImage);
	kg_lr_fourth.SetPosition(531, 308);
	kg_lr_fourth.SetVisible(true);	
	
	kg_lr_fifth.SetImage(&noNumberImage);
	kg_lr_fifth.SetPosition(543, 296);
	kg_lr_fifth.SetVisible(true);
	
	
	
	lbfirst.SetImage(&noNumberImage);
	lbfirst.SetPosition(285, 346);
	lbfirst.SetVisible(true);	
	
	lbsecond.SetImage(&noNumberImage);
	lbsecond.SetPosition(302, 346);
	lbsecond.SetVisible(true);	
	
	lbthird.SetImage(&noNumberImage);
	lbthird.SetPosition(319, 346);
	lbthird.SetVisible(true);	
	
	lbfourth.SetImage(&noNumberImage);
	lbfourth.SetPosition(340, 346);
	lbfourth.SetVisible(true);	
	
	lbfifth.SetImage(&noNumberImage);
	lbfifth.SetPosition(357, 346);
	lbfifth.SetVisible(true);
	
	
	
	lb_ul_first.SetImage(&noNumberImage);
	lb_ul_first.SetPosition(84, 156);
	lb_ul_first.SetVisible(true);	
	
	lb_ul_second.SetImage(&noNumberImage);
	lb_ul_second.SetPosition(96, 144);
	lb_ul_second.SetVisible(true);	
	
	lb_ul_third.SetImage(&noNumberImage);
	lb_ul_third.SetPosition(108, 132);
	lb_ul_third.SetVisible(true);	
	
	lb_ul_fourth.SetImage(&noNumberImage);
	lb_ul_fourth.SetPosition(123, 117);
	lb_ul_fourth.SetVisible(true);	
	
	lb_ul_fifth.SetImage(&noNumberImage);
	lb_ul_fifth.SetPosition(135, 105);
	lb_ul_fifth.SetVisible(true);
	
	
	
	lb_ur_first.SetImage(&noNumberImage);
	lb_ur_first.SetPosition(491, 106);
	lb_ur_first.SetVisible(true);	
	
	lb_ur_second.SetImage(&noNumberImage);
	lb_ur_second.SetPosition(503, 118);
	lb_ur_second.SetVisible(true);	
	
	lb_ur_third.SetImage(&noNumberImage);
	lb_ur_third.SetPosition(515, 130);
	lb_ur_third.SetVisible(true);	
	
	lb_ur_fourth.SetImage(&noNumberImage);
	lb_ur_fourth.SetPosition(530, 145);
	lb_ur_fourth.SetVisible(true);	
	
	lb_ur_fifth.SetImage(&noNumberImage);
	lb_ur_fifth.SetPosition(542, 157);
	lb_ur_fifth.SetVisible(true);
	
	
	
	lb_ll_first.SetImage(&noNumberImage);
	lb_ll_first.SetPosition(42, 326);
	lb_ll_first.SetVisible(true);	
	
	lb_ll_second.SetImage(&noNumberImage);
	lb_ll_second.SetPosition(54, 338);
	lb_ll_second.SetVisible(true);	
	
	lb_ll_third.SetImage(&noNumberImage);
	lb_ll_third.SetPosition(66, 350);
	lb_ll_third.SetVisible(true);	
	
	lb_ll_fourth.SetImage(&noNumberImage);
	lb_ll_fourth.SetPosition(81, 365);
	lb_ll_fourth.SetVisible(true);	
	
	lb_ll_fifth.SetImage(&noNumberImage);
	lb_ll_fifth.SetPosition(93, 377);
	lb_ll_fifth.SetVisible(true);
	
	
	
	lb_lr_first.SetImage(&noNumberImage);
	lb_lr_first.SetPosition(531, 385);
	lb_lr_first.SetVisible(true);	
	
	lb_lr_second.SetImage(&noNumberImage);
	lb_lr_second.SetPosition(543, 373);
	lb_lr_second.SetVisible(true);	
	
	lb_lr_third.SetImage(&noNumberImage);
	lb_lr_third.SetPosition(555, 361);
	lb_lr_third.SetVisible(true);	
	
	lb_lr_fourth.SetImage(&noNumberImage);
	lb_lr_fourth.SetPosition(570, 346);
	lb_lr_fourth.SetVisible(true);	
	
	lb_lr_fifth.SetImage(&noNumberImage);
	lb_lr_fifth.SetPosition(582, 334);
	lb_lr_fifth.SetVisible(true);
	
	
	//Here we are adding the sprites we created to their respective layers.
	//Using the Append function adds new sprites to the end of the drawing list.
	
	//Layers for the main menu
	menu.Append(&cursor);
	menu.Append(&bbStatus);
	menu.Append(&bbStatusOK);	
	menu.Append(&cogButton);
	menu.Append(&exitButton);
	menu.Append(&proButton);
	menu.Append(&weightButton);
	menu.Append(&mainBG);
	
	
	//Layers for the Center of Gravity mode
	cog.Append(&cursor);
	cog.Append(&x_hair);
	cog.Append(&backButton);
	cog.Append(&target_button);
	cog.Append(&target1);
	cog.Append(&target2);
	cog.Append(&target3);
	cog.Append(&target4);
	cog.Append(&target5);
	cog.Append(&target6);
	cog.Append(&target7);
	cog.Append(&target8);
	cog.Append(&cogBG);
	
	
	//Layers for the Weight mode
	weight.Append(&cursor);
	weight.Append(&calibrate);
	weight.Append(&backButton);
	
	
	weight.Append(&kgfirst);
	weight.Append(&kgsecond);
	weight.Append(&kgthird);
	weight.Append(&kgfourth);
	weight.Append(&kgfifth);
	
	weight.Append(&lbfirst);
	weight.Append(&lbsecond);
	weight.Append(&lbthird);
	weight.Append(&lbfourth);
	weight.Append(&lbfifth);	
	
	weight.Append(&weightBG);
	
	weight.Append(&kg_rule1);
	weight.Append(&kg_rule2);
	weight.Append(&kg_rule3);
	weight.Append(&caution1);
	weight.Append(&lb_rule1);
	weight.Append(&lb_rule2);
	weight.Append(&lb_rule3);
	weight.Append(&lb_rule4);
	weight.Append(&lb_rule5);	
	weight.Append(&caution2);
	
	
	//Layers for the rotary scale display
	rotary.Append(&cursor);
	rotary.Append(&calibrate);
	rotary.Append(&backButton);
	rotary.Append(&needle);
	rotary.Append(&rot_scale);
	
	
	//Layers for the Pro Mode
	pro.Append(&cursor);
	pro.Append(&calibrate);
	pro.Append(&x_hair);
	pro.Append(&backButton);
	
	pro.Append(&kgfirst);
	pro.Append(&kgsecond);
	pro.Append(&kgthird);
	pro.Append(&kgfourth);
	pro.Append(&kgfifth);
	
	pro.Append(&kg_ul_first);
	pro.Append(&kg_ul_second);
	pro.Append(&kg_ul_third);
	pro.Append(&kg_ul_fourth);
	pro.Append(&kg_ul_fifth);
	
	pro.Append(&kg_ur_first);
	pro.Append(&kg_ur_second);
	pro.Append(&kg_ur_third);
	pro.Append(&kg_ur_fourth);
	pro.Append(&kg_ur_fifth);
	
	pro.Append(&kg_ll_first);
	pro.Append(&kg_ll_second);
	pro.Append(&kg_ll_third);
	pro.Append(&kg_ll_fourth);
	pro.Append(&kg_ll_fifth);
	
	pro.Append(&kg_lr_first);
	pro.Append(&kg_lr_second);
	pro.Append(&kg_lr_third);
	pro.Append(&kg_lr_fourth);
	pro.Append(&kg_lr_fifth);
	
	pro.Append(&lbfirst);
	pro.Append(&lbsecond);
	pro.Append(&lbthird);
	pro.Append(&lbfourth);
	pro.Append(&lbfifth);
	
	pro.Append(&lb_ul_first);
	pro.Append(&lb_ul_second);
	pro.Append(&lb_ul_third);
	pro.Append(&lb_ul_fourth);
	pro.Append(&lb_ul_fifth);
	
	pro.Append(&lb_ur_first);
	pro.Append(&lb_ur_second);
	pro.Append(&lb_ur_third);
	pro.Append(&lb_ur_fourth);
	pro.Append(&lb_ur_fifth);
	
	pro.Append(&lb_ll_first);
	pro.Append(&lb_ll_second);
	pro.Append(&lb_ll_third);
	pro.Append(&lb_ll_fourth);
	pro.Append(&lb_ll_fifth);
	
	pro.Append(&lb_lr_first);
	pro.Append(&lb_lr_second);
	pro.Append(&lb_lr_third);
	pro.Append(&lb_lr_fourth);
	pro.Append(&lb_lr_fifth);
	
	pro.Append(&proBG);
	
	pro.Append(&kg_rule1);
	pro.Append(&kg_rule2);
	pro.Append(&kg_rule3);
	pro.Append(&caution1);
	pro.Append(&lb_rule1);
	pro.Append(&lb_rule2);
	pro.Append(&lb_rule3);
	pro.Append(&lb_rule4);
	pro.Append(&lb_rule5);	
	pro.Append(&caution2);
	
	
	//Initialize Wiimotes and Balance Board
	WPAD_Init();
	WPAD_SetDataFormat(0, WPAD_FMT_BTNS_ACC_IR);
	WPAD_SetVRes(0,rmode->fbWidth,rmode->xfbHeight);

	while(running)
	{
		
			WPAD_ScanPads();
			
			if (!MP3Player_IsPlaying())
			{		
				MP3Player_PlayBuffer(bg_music_mp3,bg_music_mp3_size,NULL);
			}		

			//Find the Balance Board and display status
			if(!foundBB)
			{
				bbStatus.SetImage(&bbStatusImage);			
				bbStatus.SetTransparency(transFade);		
				bbStatus.SetZoom(zooming);
				
				u32 devtype;
				//(1) Check in which wiimotes expansion port the balance board is hiding in
				for (u8 i=0;i<WPAD_MAX_WIIMOTES;i++)
				{	
					WPAD_Probe(i,&devtype);
					if (devtype==WPAD_EXP_WIIBOARD) 
					{
						bbport=i; //(2) Save it
						bbStatus.SetTransparency(255);
						bbStatus.SetImage(&bbStatusOKImage);
						bbStatus.SetZoom(1);
						foundBB = true;
					}
				}
			}
			else
			{
				WPAD_Expansion(bbport, &exp); //(3) Extract the balance board struct
				//x=exp.wb.x; // The position
				//y=exp.wb.y; //  on the board
				//weight=exp.wb.tl+exp.wb.tr+exp.wb.bl+exp.wb.br; // Weight in kilograms
			}	
			
		if(!debugging)
		{			
			//Using the IR object for our pointer
			WPAD_IR(0, &irObject);
			cursor.SetPosition(irObject.sx-WSP_POINTER_CORRECTION_X, irObject.sy-WSP_POINTER_CORRECTION_Y);
			cursor.SetRotation((irObject.angle)/2);			
		
			//GUI selection and button press code
			
			if(option == "main")
			{
				if(cursor.CollidesWith(&weightButton))
				{ 	
					weightButton.SetImage(&weight_in_Image);
					weightButton.SetZoom(1);
					cogButton.SetImage(&cog_out_Image);	
					cogButton.SetZoom(1);			
					exitButton.SetImage(&exit_out_Image);
					exitButton.SetZoom(1);	
					proButton.SetImage(&pro_out_Image);
					proButton.SetZoom(1);
					if(!weightActions)
					{
						WPAD_Rumble(0,1);
						rumbling = true;
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 11000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						weightActions = true;
					}
					if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_A)
					{
						option = "weight";
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 22100, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
					}
					cogActions = false;
					proActions = false;
					exitActions = false;
				}
				else if(cursor.CollidesWith(&cogButton))
				{ 	
					cogButton.SetImage(&cog_in_Image);
					cogButton.SetZoom(1);	
					weightButton.SetImage(&weight_out_Image);
					weightButton.SetZoom(1);	
					exitButton.SetImage(&exit_out_Image);
					exitButton.SetZoom(1);	
					proButton.SetImage(&pro_out_Image);
					proButton.SetZoom(1);
					if(!cogActions)
					{
						WPAD_Rumble(0,1);
						rumbling = true;
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 11000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						cogActions = true;
					}
					if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_A)
					{
						option = "cog";
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 22100, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
					}
					weightActions = false;
					proActions = false;
					exitActions = false;
				}
				else if(cursor.CollidesWith(&exitButton))
				{	
					exitButton.SetImage(&exit_in_Image);
					exitButton.SetZoom(1);	
					weightButton.SetImage(&weight_out_Image);
					weightButton.SetZoom(1);	
					cogButton.SetImage(&cog_out_Image);
					cogButton.SetZoom(1);
					proButton.SetImage(&pro_out_Image);
					proButton.SetZoom(1);
					if(!exitActions)
					{
						WPAD_Rumble(0,1);
						rumbling = true;
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 11000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						exitActions = true;
					}
					if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_A)
					{
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 22100, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						running=false;
					}				
					weightActions = false;
					proActions = false;
					cogActions = false;
				}
				else if(cursor.CollidesWith(&proButton))
				{	
					proButton.SetImage(&pro_in_Image);
					proButton.SetZoom(1);
					weightButton.SetImage(&weight_out_Image);
					weightButton.SetZoom(1);	
					cogButton.SetImage(&cog_out_Image);
					cogButton.SetZoom(1);	
					exitButton.SetImage(&exit_out_Image);
					exitButton.SetZoom(1);
					if(!proActions)
					{
						WPAD_Rumble(0,1);
						rumbling = true;
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 11000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						proActions = true;
					}
					if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_A)
					{
						option = "pro";
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 22100, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
					}
					weightActions = false;
					exitActions = false;
					cogActions = false;
				}
				else
				{ 	
					weightButton.SetImage(&weight_out_Image);
					weightButton.SetZoom(1);	
					cogButton.SetImage(&cog_out_Image);
					cogButton.SetZoom(1);	
					exitButton.SetImage(&exit_out_Image);
					exitButton.SetZoom(1);
					proButton.SetImage(&pro_out_Image);
					proButton.SetZoom(1);
					weightActions = false;
					exitActions = false;
					cogActions = false;
					proActions = false;
				}
				menu.Draw(0,-13);
			}
			
			if(option == "cog")
			{
				x_hair.SetPosition(322+(exp.wb.x*7),233+(exp.wb.y*4));
				
				if(cursor.CollidesWith(&backButton))
				{ 	
					backButton.SetImage(&back_in_Image);
					backButton.SetZoom(1.2);
					if(!backActions)
					{
						WPAD_Rumble(0,1);
						rumbling = true;
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 11000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						backActions = true;
					}
					if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_A)
					{
						if(option != "main")
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 22100, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						option = "main";
					}
					targetActions = false;
				}
				else if(cursor.CollidesWith(&target_button))
				{ 					
					target_button.SetZoom(1.2);
					if(!targetActions)
					{
						WPAD_Rumble(0,1);
						rumbling = true;
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 11000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						targetActions = true;
					}
					if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_A)
					{
						if(targets == true)
							targets = false;
						else
							targets = true;
							
						if(targets)
						{
							target1.SetTransparency(255);
							target2.SetTransparency(255);
							target3.SetTransparency(255);
							target4.SetTransparency(255);
							target5.SetTransparency(255);
							target6.SetTransparency(255);
							target7.SetTransparency(255);
							target8.SetTransparency(255);
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 11000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						}
						
						if(!targets)
						{
							target1.SetTransparency(0);
							target2.SetTransparency(0);
							target3.SetTransparency(0);
							target4.SetTransparency(0);
							target5.SetTransparency(0);
							target6.SetTransparency(0);
							target7.SetTransparency(0);
							target8.SetTransparency(0);
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 11000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						}
					}
					backActions = false;
				}
				else
				{
					target_button.SetZoom(1);
					backButton.SetZoom(1);
					backButton.SetImage(&back_out_Image);
					targetActions = false;
					backActions = false;
				}
				
				if(targets)
				{
					if(x_hair.CollidesWith(&bulls_eye1))
					{
						if(target1.GetTransparency() != 0)
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 44000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						target1.SetTransparency(0);
					}
					if(x_hair.CollidesWith(&bulls_eye2))
					{
						if(target2.GetTransparency() != 0)
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 44000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						target2.SetTransparency(0);
					}
					if(x_hair.CollidesWith(&bulls_eye3))
					{
						if(target3.GetTransparency() != 0)
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 44000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						target3.SetTransparency(0);
					}
					if(x_hair.CollidesWith(&bulls_eye4))
					{
						if(target4.GetTransparency() != 0)
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 44000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						target4.SetTransparency(0);
					}
					if(x_hair.CollidesWith(&bulls_eye5))
					{
						if(target5.GetTransparency() != 0)
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 44000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						target5.SetTransparency(0);
					}
					if(x_hair.CollidesWith(&bulls_eye6))
					{
						if(target6.GetTransparency() != 0)
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 44000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						target6.SetTransparency(0);
					}
					if(x_hair.CollidesWith(&bulls_eye7))
					{
						if(target7.GetTransparency() != 0)
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 44000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						target7.SetTransparency(0);
					}
					if(x_hair.CollidesWith(&bulls_eye8))
					{
						if(target8.GetTransparency() != 0)
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 44000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						target8.SetTransparency(0);
					}
				}
				
				if(target1.GetTransparency() == 0 && target2.GetTransparency() == 0 && target3.GetTransparency() == 0 &&
				   target4.GetTransparency() == 0 && target5.GetTransparency() == 0 && target6.GetTransparency() == 0 && 
				   target7.GetTransparency() == 0 && target8.GetTransparency() == 0)
						targets = false;
				
				cog.Draw(0,-13);
			}
			
			if(option == "weight")
			{
				if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_2)
				{
					calibrating = true;
				}
				
				if(calibrating)
				{			
					
					offset+=exp.wb.tl+exp.wb.tr+exp.wb.bl+exp.wb.br;
					offset_ave++;
					
					offset_factor = (offset/offset_ave);
					calibrate.SetVisible(true);
					
					if(offset_ave >= 400)
						calibrating = false;				
				}
				else
				{
					calibrate.SetVisible(false);
					offset = 0;
					offset_ave = 0;	
				}
				
				if(WPAD_ButtonsHeld(WPAD_CHAN_0) & WPAD_BUTTON_1)
				{
					if(ave_count <= 222)
					{
						ave_weights+=exp.wb.tl+exp.wb.tr+exp.wb.bl+exp.wb.br;
						ave_count++;
					}
					
					weights = (ave_weights/ave_count) - offset_factor;
					
				}
				else
				{
					weights = (exp.wb.tl+exp.wb.tr+exp.wb.bl+exp.wb.br) - offset_factor;
					ave_weights = 0;
					ave_count = 0;
				}

				if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_B)
				{
					if(rotaryOn == true)
						rotaryOn = false;
					else
						rotaryOn = true;
				}
				
				needle.SetRotation(weights*1.202521429);
				
				kg_rule1.SetPosition(272 - 15*(weights), 122);
				kg_rule2.SetPosition((272+1024) - 15*(weights), 122);
				kg_rule3.SetPosition((272+1024+1024) - 15*(weights), 122);
				caution1.SetPosition((272+1024+1024+272) - 15*(weights), 122);
				
				lb_rule1.SetPosition(272 - (15*(weights*2.20462262))                            , 275);
				lb_rule2.SetPosition((272+1024) - (15*(weights*2.20462262))                     , 275);
				lb_rule3.SetPosition((272+1024+1024) - (15*(weights*2.20462262))                , 275);
				lb_rule4.SetPosition((272+1024+1024+1024) - (15*(weights*2.20462262))           , 275);
				lb_rule5.SetPosition((272+1024+1024+1024+1024) - (15*(weights*2.20462262))      , 275);
				caution2.SetPosition((272+1024+1024+1024+1024+924) - (15*(weights*2.20462262)) , 275);
				
				if(kg_rule1.GetX() > 272)
					kg_rule1.SetX(272);
					
				if(lb_rule1.GetX() > 272)
					lb_rule1.SetX(272);
				
				

				//KG
				kgs = (int)(weights*100);
				kgstring = formatData(kgs);

				if(kgs<0)
					kgs=0;			
				
				
				if(kgs > 9999)
				{
					kgfifth.SetImage(assignImage(kgstring[4]));
					kgfourth.SetImage(assignImage(kgstring[3]));
					kgthird.SetImage(assignImage(kgstring[2]));
					kgsecond.SetImage(assignImage(kgstring[1]));
					kgfirst.SetImage(assignImage(kgstring[0]));
				}
				else if(kgs > 999)
				{
					kgfifth.SetImage(assignImage(kgstring[3]));
					kgfourth.SetImage(assignImage(kgstring[2]));
					kgthird.SetImage(assignImage(kgstring[1]));
					kgsecond.SetImage(assignImage(kgstring[0]));
					kgfirst.SetImage(&noNumberImage);
				}
				else if(kgs > 99)
				{
					kgfifth.SetImage(assignImage(kgstring[2]));
					kgfourth.SetImage(assignImage(kgstring[1]));
					kgthird.SetImage(assignImage(kgstring[0]));
					kgsecond.SetImage(&noNumberImage);
					kgfirst.SetImage(&noNumberImage);
				}			
				else if(kgs > 9)
				{
					kgfifth.SetImage(assignImage(kgstring[1]));
					kgfourth.SetImage(assignImage(kgstring[0]));
					kgthird.SetImage(&zeroImage);
					kgsecond.SetImage(&noNumberImage);
					kgfirst.SetImage(&noNumberImage);
				}
				else
				{
					kgfifth.SetImage(assignImage(kgstring[0]));
					kgfourth.SetImage(&zeroImage);
					kgthird.SetImage(&zeroImage);
					kgsecond.SetImage(&noNumberImage);
					kgfirst.SetImage(&noNumberImage);
				}
				
				if(kgs == 0)
				{
					kgfifth.SetImage(&zeroImage);
					kgfourth.SetImage(&zeroImage);
					kgthird.SetImage(&zeroImage);
					kgsecond.SetImage(&noNumberImage);
					kgfirst.SetImage(&noNumberImage);
				}
				
				
				//LB
				lbs = (int)((weights*2.20462262)*100);
				lbstring = formatData(lbs);
				
				if(lbs<0)
					lbs=0;
				
				
				if(lbs > 9999)
				{
					lbfifth.SetImage(assignImage(lbstring[4]));
					lbfourth.SetImage(assignImage(lbstring[3]));
					lbthird.SetImage(assignImage(lbstring[2]));
					lbsecond.SetImage(assignImage(lbstring[1]));
					lbfirst.SetImage(assignImage(lbstring[0]));
				}
				else if(lbs > 999)
				{
					lbfifth.SetImage(assignImage(lbstring[3]));
					lbfourth.SetImage(assignImage(lbstring[2]));
					lbthird.SetImage(assignImage(lbstring[1]));
					lbsecond.SetImage(assignImage(lbstring[0]));
					lbfirst.SetImage(&noNumberImage);
				}
				else if(lbs > 99)
				{
					lbfifth.SetImage(assignImage(lbstring[2]));
					lbfourth.SetImage(assignImage(lbstring[1]));
					lbthird.SetImage(assignImage(lbstring[0]));
					lbsecond.SetImage(&noNumberImage);
					lbfirst.SetImage(&noNumberImage);
				}
				else if(lbs > 9)
				{
					lbfifth.SetImage(assignImage(lbstring[1]));
					lbfourth.SetImage(assignImage(lbstring[0]));
					lbthird.SetImage(&zeroImage);
					lbsecond.SetImage(&noNumberImage);
					lbfirst.SetImage(&noNumberImage);
				}
				else
				{
					lbfifth.SetImage(assignImage(lbstring[0]));
					lbfourth.SetImage(&zeroImage);
					lbthird.SetImage(&zeroImage);
					lbsecond.SetImage(&noNumberImage);
					lbfirst.SetImage(&noNumberImage);
				}
				
				if(lbs == 0)
				{
					lbfifth.SetImage(&zeroImage);
					lbfourth.SetImage(&zeroImage);
					lbthird.SetImage(&zeroImage);
					lbsecond.SetImage(&noNumberImage);
					lbfirst.SetImage(&noNumberImage);
				}			
				
				
				
				if(cursor.CollidesWith(&backButton))
				{ 	
					backButton.SetImage(&back_in_Image);
					backButton.SetZoom(1.2);
					if(!backActions)
					{
						WPAD_Rumble(0,1);
						rumbling = true;
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 11000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						backActions = true;
					}
					if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_A)
					{
						if(option != "main")
							ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 22100, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						option = "main";
					}
				}
				else 
				{ 	
					backButton.SetImage(&back_out_Image);
					backButton.SetZoom(1);
					backActions = false;
				}
				
				if(rotaryOn)
					rotary.Draw(0,-13);
				else
					weight.Draw(0,-13);
			}
			
			if(option == "pro")
			{
				if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_2)
				{
					calibrating = true;
				}
				
				if(calibrating)
				{			
					
					offset+=exp.wb.tl+exp.wb.tr+exp.wb.bl+exp.wb.br;		
					ul_offset+=exp.wb.tl;
					ur_offset+=exp.wb.tr;
					ll_offset+=exp.wb.bl;
					lr_offset+=exp.wb.br;
					
					offset_ave++;
					
					offset_factor = (offset/offset_ave);
					ul_offset_factor = (ul_offset/offset_ave);
					ur_offset_factor = (ur_offset/offset_ave);
					ll_offset_factor = (ll_offset/offset_ave);
					lr_offset_factor = (lr_offset/offset_ave);
					
					
					calibrate.SetVisible(true);
					
					if(offset_ave >= 400)
						calibrating = false;				
				}
				else
				{
					calibrate.SetVisible(false);
					offset = 0;
					ul_offset = 0;
					ur_offset = 0;
					ll_offset = 0;
					lr_offset = 0;
					offset_ave = 0;	
				}
				
				if(WPAD_ButtonsHeld(WPAD_CHAN_0) & WPAD_BUTTON_1)
				{
					if(ave_count <= 222)
					{
						ave_weights+=exp.wb.tl+exp.wb.tr+exp.wb.bl+exp.wb.br;
						ul_ave_weight+=exp.wb.tl;
						ur_ave_weight+=exp.wb.tr;
						ll_ave_weight+=exp.wb.bl;
						lr_ave_weight+=exp.wb.br;
						
						ave_count++;
					}
					
					weights = (ave_weights/ave_count) - offset_factor;
					ul_weight = (ul_ave_weight/ave_count) - ul_offset_factor;
					ur_weight = (ur_ave_weight/ave_count) - ur_offset_factor;
					ll_weight = (ll_ave_weight/ave_count) - ll_offset_factor;
					lr_weight = (lr_ave_weight/ave_count) - lr_offset_factor;
					
				}
				else
				{
					weights = (exp.wb.tl+exp.wb.tr+exp.wb.bl+exp.wb.br) - offset_factor;
					ul_weight = exp.wb.tl - ul_offset_factor;
					ur_weight = exp.wb.tr - ur_offset_factor;
					ll_weight = exp.wb.bl - ll_offset_factor;
					lr_weight = exp.wb.br - lr_offset_factor;
					
					ave_weights = 0;
					ul_ave_weight = 0;
					ur_ave_weight = 0;
					ll_ave_weight = 0;
					lr_ave_weight = 0;
					ave_count = 0;
				}			
				
				
				kg_rule1.SetPosition(272 - 15*(weights), 122);
				kg_rule2.SetPosition((272+1024) - 15*(weights), 122);
				kg_rule3.SetPosition((272+1024+1024) - 15*(weights), 122);
				caution1.SetPosition((272+1024+1024+272) - 15*(weights), 122);
				
				lb_rule1.SetPosition(272 - (15*(weights*2.20462262))                            , 275);
				lb_rule2.SetPosition((272+1024) - (15*(weights*2.20462262))                     , 275);
				lb_rule3.SetPosition((272+1024+1024) - (15*(weights*2.20462262))                , 275);
				lb_rule4.SetPosition((272+1024+1024+1024) - (15*(weights*2.20462262))           , 275);
				lb_rule5.SetPosition((272+1024+1024+1024+1024) - (15*(weights*2.20462262))      , 275);
				caution2.SetPosition((272+1024+1024+1024+1024+924) - (15*(weights*2.20462262)) , 275);
				
				if(kg_rule1.GetX() > 272)
					kg_rule1.SetX(272);
					
				if(lb_rule1.GetX() > 272)
					lb_rule1.SetX(272);
				
				

				//KG
				kgs = (int)(weights*100);
				kgstring = formatData(kgs);

				if(kgs<0)
					kgs=0;			
				
				
				if(kgs > 9999)
				{
					kgfifth.SetImage(assignImage(kgstring[4]));
					kgfourth.SetImage(assignImage(kgstring[3]));
					kgthird.SetImage(assignImage(kgstring[2]));
					kgsecond.SetImage(assignImage(kgstring[1]));
					kgfirst.SetImage(assignImage(kgstring[0]));
				}
				else if(kgs > 999)
				{
					kgfifth.SetImage(assignImage(kgstring[3]));
					kgfourth.SetImage(assignImage(kgstring[2]));
					kgthird.SetImage(assignImage(kgstring[1]));
					kgsecond.SetImage(assignImage(kgstring[0]));
					kgfirst.SetImage(&noNumberImage);
				}
				else if(kgs > 99)
				{
					kgfifth.SetImage(assignImage(kgstring[2]));
					kgfourth.SetImage(assignImage(kgstring[1]));
					kgthird.SetImage(assignImage(kgstring[0]));
					kgsecond.SetImage(&noNumberImage);
					kgfirst.SetImage(&noNumberImage);
				}			
				else if(kgs > 9)
				{
					kgfifth.SetImage(assignImage(kgstring[1]));
					kgfourth.SetImage(assignImage(kgstring[0]));
					kgthird.SetImage(&zeroImage);
					kgsecond.SetImage(&noNumberImage);
					kgfirst.SetImage(&noNumberImage);
				}
				else
				{
					kgfifth.SetImage(assignImage(kgstring[0]));
					kgfourth.SetImage(&zeroImage);
					kgthird.SetImage(&zeroImage);
					kgsecond.SetImage(&noNumberImage);
					kgfirst.SetImage(&noNumberImage);
				}
				
				if(kgs == 0)
				{
					kgfifth.SetImage(&zeroImage);
					kgfourth.SetImage(&zeroImage);
					kgthird.SetImage(&zeroImage);
					kgsecond.SetImage(&noNumberImage);
					kgfirst.SetImage(&noNumberImage);
				}
				
				
				//LB
				lbs = (int)((weights*100)*2.20462262);
				lbstring = formatData(lbs);
				
				if(lbs<0)
					lbs=0;
				
				
				if(lbs > 9999)
				{
					lbfifth.SetImage(assignImage(lbstring[4]));
					lbfourth.SetImage(assignImage(lbstring[3]));
					lbthird.SetImage(assignImage(lbstring[2]));
					lbsecond.SetImage(assignImage(lbstring[1]));
					lbfirst.SetImage(assignImage(lbstring[0]));
				}
				else if(lbs > 999)
				{
					lbfifth.SetImage(assignImage(lbstring[3]));
					lbfourth.SetImage(assignImage(lbstring[2]));
					lbthird.SetImage(assignImage(lbstring[1]));
					lbsecond.SetImage(assignImage(lbstring[0]));
					lbfirst.SetImage(&noNumberImage);
				}
				else if(lbs > 99)
				{
					lbfifth.SetImage(assignImage(lbstring[2]));
					lbfourth.SetImage(assignImage(lbstring[1]));
					lbthird.SetImage(assignImage(lbstring[0]));
					lbsecond.SetImage(&noNumberImage);
					lbfirst.SetImage(&noNumberImage);
				}
				else if(lbs > 9)
				{
					lbfifth.SetImage(assignImage(lbstring[1]));
					lbfourth.SetImage(assignImage(lbstring[0]));
					lbthird.SetImage(&zeroImage);
					lbsecond.SetImage(&noNumberImage);
					lbfirst.SetImage(&noNumberImage);
				}
				else
				{
					lbfifth.SetImage(assignImage(lbstring[0]));
					lbfourth.SetImage(&zeroImage);
					lbthird.SetImage(&zeroImage);
					lbsecond.SetImage(&noNumberImage);
					lbfirst.SetImage(&noNumberImage);
				}
				
				if(lbs == 0)
				{
					lbfifth.SetImage(&zeroImage);
					lbfourth.SetImage(&zeroImage);
					lbthird.SetImage(&zeroImage);
					lbsecond.SetImage(&noNumberImage);
					lbfirst.SetImage(&noNumberImage);
				}
				
				
				
				kgs = (int)(ul_weight*100);
				kgstring = formatData(kgs);

				if(kgs<0)
					kgs=0;
					
				if(kgs > 9999)
				{
					kg_ul_fifth.SetImage(assignImageLeft(kgstring[4]));
					kg_ul_fourth.SetImage(assignImageLeft(kgstring[3]));
					kg_ul_third.SetImage(assignImageLeft(kgstring[2]));
					kg_ul_second.SetImage(assignImageLeft(kgstring[1]));
					kg_ul_first.SetImage(assignImageLeft(kgstring[0]));
				}
				else if(kgs > 999)
				{
					kg_ul_fifth.SetImage(assignImageLeft(kgstring[3]));
					kg_ul_fourth.SetImage(assignImageLeft(kgstring[2]));
					kg_ul_third.SetImage(assignImageLeft(kgstring[1]));
					kg_ul_second.SetImage(assignImageLeft(kgstring[0]));
					kg_ul_first.SetImage(&noNumberImage_left);
				}
				else if(kgs > 99)
				{
					kg_ul_fifth.SetImage(assignImageLeft(kgstring[2]));
					kg_ul_fourth.SetImage(assignImageLeft(kgstring[1]));
					kg_ul_third.SetImage(assignImageLeft(kgstring[0]));
					kg_ul_second.SetImage(&noNumberImage_left);
					kg_ul_first.SetImage(&noNumberImage_left);
				}			
				else if(kgs > 9)
				{
					kg_ul_fifth.SetImage(assignImageLeft(kgstring[1]));
					kg_ul_fourth.SetImage(assignImageLeft(kgstring[0]));
					kg_ul_third.SetImage(&zeroImage_left);
					kg_ul_second.SetImage(&noNumberImage_left);
					kg_ul_first.SetImage(&noNumberImage_left);
				}
				else
				{
					kg_ul_fifth.SetImage(assignImageLeft(kgstring[0]));
					kg_ul_fourth.SetImage(&zeroImage_left);
					kg_ul_third.SetImage(&zeroImage_left);
					kg_ul_second.SetImage(&noNumberImage_left);
					kg_ul_first.SetImage(&noNumberImage_left);
				}
				
				if(kgs == 0)
				{
					kg_ul_fifth.SetImage(&zeroImage_left);
					kg_ul_fourth.SetImage(&zeroImage_left);
					kg_ul_third.SetImage(&zeroImage_left);
					kg_ul_second.SetImage(&noNumberImage_left);
					kg_ul_first.SetImage(&noNumberImage_left);
				}
				
				
				lbs = (int)((ul_weight*2.20462262)*100);
				lbstring = formatData(lbs);
				
				if(lbs<0)
					lbs=0;
					
				if(lbs > 9999)
				{
					lb_ul_fifth.SetImage(assignImageLeft(lbstring[4]));
					lb_ul_fourth.SetImage(assignImageLeft(lbstring[3]));
					lb_ul_third.SetImage(assignImageLeft(lbstring[2]));
					lb_ul_second.SetImage(assignImageLeft(lbstring[1]));
					lb_ul_first.SetImage(assignImageLeft(lbstring[0]));
				}
				else if(lbs > 999)
				{
					lb_ul_fifth.SetImage(assignImageLeft(lbstring[3]));
					lb_ul_fourth.SetImage(assignImageLeft(lbstring[2]));
					lb_ul_third.SetImage(assignImageLeft(lbstring[1]));
					lb_ul_second.SetImage(assignImageLeft(lbstring[0]));
					lb_ul_first.SetImage(&noNumberImage_left);
				}
				else if(lbs > 99)
				{
					lb_ul_fifth.SetImage(assignImageLeft(lbstring[2]));
					lb_ul_fourth.SetImage(assignImageLeft(lbstring[1]));
					lb_ul_third.SetImage(assignImageLeft(lbstring[0]));
					lb_ul_second.SetImage(&noNumberImage_left);
					lb_ul_first.SetImage(&noNumberImage_left);
				}
				else if(lbs > 9)
				{
					lb_ul_fifth.SetImage(assignImageLeft(lbstring[1]));
					lb_ul_fourth.SetImage(assignImageLeft(lbstring[0]));
					lb_ul_third.SetImage(&zeroImage_left);
					lb_ul_second.SetImage(&noNumberImage_left);
					lb_ul_first.SetImage(&noNumberImage_left);
				}
				else
				{
					lb_ul_fifth.SetImage(assignImageLeft(lbstring[0]));
					lb_ul_fourth.SetImage(&zeroImage_left);
					lb_ul_third.SetImage(&zeroImage_left);
					lb_ul_second.SetImage(&noNumberImage_left);
					lb_ul_first.SetImage(&noNumberImage_left);
				}
				
				if(lbs == 0)
				{
					lb_ul_fifth.SetImage(&zeroImage_left);
					lb_ul_fourth.SetImage(&zeroImage_left);
					lb_ul_third.SetImage(&zeroImage_left);
					lb_ul_second.SetImage(&noNumberImage_left);
					lb_ul_first.SetImage(&noNumberImage_left);
				}
				
				
				
				
				
				kgs = (int)(ur_weight*100);
				kgstring = formatData(kgs);

				if(kgs<0)
					kgs=0;
					
				if(kgs > 9999)
				{
					kg_ur_fifth.SetImage(assignImageRight(kgstring[4]));
					kg_ur_fourth.SetImage(assignImageRight(kgstring[3]));
					kg_ur_third.SetImage(assignImageRight(kgstring[2]));
					kg_ur_second.SetImage(assignImageRight(kgstring[1]));
					kg_ur_first.SetImage(assignImageRight(kgstring[0]));
				}
				else if(kgs > 999)
				{
					kg_ur_fifth.SetImage(assignImageRight(kgstring[3]));
					kg_ur_fourth.SetImage(assignImageRight(kgstring[2]));
					kg_ur_third.SetImage(assignImageRight(kgstring[1]));
					kg_ur_second.SetImage(assignImageRight(kgstring[0]));
					kg_ur_first.SetImage(&noNumberImage_right);
				}
				else if(kgs > 99)
				{
					kg_ur_fifth.SetImage(assignImageRight(kgstring[2]));
					kg_ur_fourth.SetImage(assignImageRight(kgstring[1]));
					kg_ur_third.SetImage(assignImageRight(kgstring[0]));
					kg_ur_second.SetImage(&noNumberImage_right);
					kg_ur_first.SetImage(&noNumberImage_right);
				}			
				else if(kgs > 9)
				{
					kg_ur_fifth.SetImage(assignImageRight(kgstring[1]));
					kg_ur_fourth.SetImage(assignImageRight(kgstring[0]));
					kg_ur_third.SetImage(&zeroImage_right);
					kg_ur_second.SetImage(&noNumberImage_right);
					kg_ur_first.SetImage(&noNumberImage_right);
				}
				else
				{
					kg_ur_fifth.SetImage(assignImageRight(kgstring[0]));
					kg_ur_fourth.SetImage(&zeroImage_right);
					kg_ur_third.SetImage(&zeroImage_right);
					kg_ur_second.SetImage(&noNumberImage_right);
					kg_ur_first.SetImage(&noNumberImage_right);
				}
				
				if(kgs == 0)
				{
					kg_ur_fifth.SetImage(&zeroImage_right);
					kg_ur_fourth.SetImage(&zeroImage_right);
					kg_ur_third.SetImage(&zeroImage_right);
					kg_ur_second.SetImage(&noNumberImage_right);
					kg_ur_first.SetImage(&noNumberImage_right);
				}
				
				lbs = (int)((ur_weight*2.20462262)*100);
				lbstring = formatData(lbs);
				
				if(lbs<0)
					lbs=0;
					
				if(lbs > 9999)
				{
					lb_ur_fifth.SetImage(assignImageRight(lbstring[4]));
					lb_ur_fourth.SetImage(assignImageRight(lbstring[3]));
					lb_ur_third.SetImage(assignImageRight(lbstring[2]));
					lb_ur_second.SetImage(assignImageRight(lbstring[1]));
					lb_ur_first.SetImage(assignImageRight(lbstring[0]));
				}
				else if(lbs > 999)
				{
					lb_ur_fifth.SetImage(assignImageRight(lbstring[3]));
					lb_ur_fourth.SetImage(assignImageRight(lbstring[2]));
					lb_ur_third.SetImage(assignImageRight(lbstring[1]));
					lb_ur_second.SetImage(assignImageRight(lbstring[0]));
					lb_ur_first.SetImage(&noNumberImage_right);
				}
				else if(lbs > 99)
				{
					lb_ur_fifth.SetImage(assignImageRight(lbstring[2]));
					lb_ur_fourth.SetImage(assignImageRight(lbstring[1]));
					lb_ur_third.SetImage(assignImageRight(lbstring[0]));
					lb_ur_second.SetImage(&noNumberImage_right);
					lb_ur_first.SetImage(&noNumberImage_right);
				}
				else if(lbs > 9)
				{
					lb_ur_fifth.SetImage(assignImageRight(lbstring[1]));
					lb_ur_fourth.SetImage(assignImageRight(lbstring[0]));
					lb_ur_third.SetImage(&zeroImage_right);
					lb_ur_second.SetImage(&noNumberImage_right);
					lb_ur_first.SetImage(&noNumberImage_right);
				}
				else
				{
					lb_ur_fifth.SetImage(assignImageRight(lbstring[0]));
					lb_ur_fourth.SetImage(&zeroImage_right);
					lb_ur_third.SetImage(&zeroImage_right);
					lb_ur_second.SetImage(&noNumberImage_right);
					lb_ur_first.SetImage(&noNumberImage_right);
				}
				
				if(lbs == 0)
				{
					lb_ur_fifth.SetImage(&zeroImage_right);
					lb_ur_fourth.SetImage(&zeroImage_right);
					lb_ur_third.SetImage(&zeroImage_right);
					lb_ur_second.SetImage(&noNumberImage_right);
					lb_ur_first.SetImage(&noNumberImage_right);
				}			
				
				
				
				kgs = (int)(ll_weight*100);
				kgstring = formatData(kgs);

				if(kgs<0)
					kgs=0;
					
				if(kgs > 9999)
				{
					kg_ll_fifth.SetImage(assignImageRight(kgstring[4]));
					kg_ll_fourth.SetImage(assignImageRight(kgstring[3]));
					kg_ll_third.SetImage(assignImageRight(kgstring[2]));
					kg_ll_second.SetImage(assignImageRight(kgstring[1]));
					kg_ll_first.SetImage(assignImageRight(kgstring[0]));
				}
				else if(kgs > 999)
				{
					kg_ll_fifth.SetImage(assignImageRight(kgstring[3]));
					kg_ll_fourth.SetImage(assignImageRight(kgstring[2]));
					kg_ll_third.SetImage(assignImageRight(kgstring[1]));
					kg_ll_second.SetImage(assignImageRight(kgstring[0]));
					kg_ll_first.SetImage(&noNumberImage_right);
				}
				else if(kgs > 99)
				{
					kg_ll_fifth.SetImage(assignImageRight(kgstring[2]));
					kg_ll_fourth.SetImage(assignImageRight(kgstring[1]));
					kg_ll_third.SetImage(assignImageRight(kgstring[0]));
					kg_ll_second.SetImage(&noNumberImage_right);
					kg_ll_first.SetImage(&noNumberImage_right);
				}			
				else if(kgs > 9)
				{
					kg_ll_fifth.SetImage(assignImageRight(kgstring[1]));
					kg_ll_fourth.SetImage(assignImageRight(kgstring[0]));
					kg_ll_third.SetImage(&zeroImage_right);
					kg_ll_second.SetImage(&noNumberImage_right);
					kg_ll_first.SetImage(&noNumberImage_right);
				}
				else
				{
					kg_ll_fifth.SetImage(assignImageRight(kgstring[0]));
					kg_ll_fourth.SetImage(&zeroImage_right);
					kg_ll_third.SetImage(&zeroImage_right);
					kg_ll_second.SetImage(&noNumberImage_right);
					kg_ll_first.SetImage(&noNumberImage_right);
				}
				
				if(kgs == 0)
				{
					kg_ll_fifth.SetImage(&zeroImage_right);
					kg_ll_fourth.SetImage(&zeroImage_right);
					kg_ll_third.SetImage(&zeroImage_right);
					kg_ll_second.SetImage(&noNumberImage_right);
					kg_ll_first.SetImage(&noNumberImage_right);
				}
				
				
				lbs = (int)((ll_weight*2.20462262)*100);
				lbstring = formatData(lbs);
				
				if(lbs<0)
					lbs=0;
					
				if(lbs > 9999)
				{
					lb_ll_fifth.SetImage(assignImageRight(lbstring[4]));
					lb_ll_fourth.SetImage(assignImageRight(lbstring[3]));
					lb_ll_third.SetImage(assignImageRight(lbstring[2]));
					lb_ll_second.SetImage(assignImageRight(lbstring[1]));
					lb_ll_first.SetImage(assignImageRight(lbstring[0]));
				}
				else if(lbs > 999)
				{
					lb_ll_fifth.SetImage(assignImageRight(lbstring[3]));
					lb_ll_fourth.SetImage(assignImageRight(lbstring[2]));
					lb_ll_third.SetImage(assignImageRight(lbstring[1]));
					lb_ll_second.SetImage(assignImageRight(lbstring[0]));
					lb_ll_first.SetImage(&noNumberImage_right);
				}
				else if(lbs > 99)
				{
					lb_ll_fifth.SetImage(assignImageRight(lbstring[2]));
					lb_ll_fourth.SetImage(assignImageRight(lbstring[1]));
					lb_ll_third.SetImage(assignImageRight(lbstring[0]));
					lb_ll_second.SetImage(&noNumberImage_right);
					lb_ll_first.SetImage(&noNumberImage_right);
				}
				else if(lbs > 9)
				{
					lb_ll_fifth.SetImage(assignImageRight(lbstring[1]));
					lb_ll_fourth.SetImage(assignImageRight(lbstring[0]));
					lb_ll_third.SetImage(&zeroImage_right);
					lb_ll_second.SetImage(&noNumberImage_right);
					lb_ll_first.SetImage(&noNumberImage_right);
				}
				else
				{
					lb_ll_fifth.SetImage(assignImageRight(lbstring[0]));
					lb_ll_fourth.SetImage(&zeroImage_right);
					lb_ll_third.SetImage(&zeroImage_right);
					lb_ll_second.SetImage(&noNumberImage_right);
					lb_ll_first.SetImage(&noNumberImage_right);
				}
				
				if(lbs == 0)
				{
					lb_ll_fifth.SetImage(&zeroImage_right);
					lb_ll_fourth.SetImage(&zeroImage_right);
					lb_ll_third.SetImage(&zeroImage_right);
					lb_ll_second.SetImage(&noNumberImage_right);
					lb_ll_first.SetImage(&noNumberImage_right);
				}
				
				
				
				
				kgs = (int)(lr_weight*100);
				kgstring = formatData(kgs);

				if(kgs<0)
					kgs=0;
					
				if(kgs > 9999)
				{
					kg_lr_fifth.SetImage(assignImageLeft(kgstring[4]));
					kg_lr_fourth.SetImage(assignImageLeft(kgstring[3]));
					kg_lr_third.SetImage(assignImageLeft(kgstring[2]));
					kg_lr_second.SetImage(assignImageLeft(kgstring[1]));
					kg_lr_first.SetImage(assignImageLeft(kgstring[0]));
				}
				else if(kgs > 999)
				{
					kg_lr_fifth.SetImage(assignImageLeft(kgstring[3]));
					kg_lr_fourth.SetImage(assignImageLeft(kgstring[2]));
					kg_lr_third.SetImage(assignImageLeft(kgstring[1]));
					kg_lr_second.SetImage(assignImageLeft(kgstring[0]));
					kg_lr_first.SetImage(&noNumberImage_left);
				}
				else if(kgs > 99)
				{
					kg_lr_fifth.SetImage(assignImageLeft(kgstring[2]));
					kg_lr_fourth.SetImage(assignImageLeft(kgstring[1]));
					kg_lr_third.SetImage(assignImageLeft(kgstring[0]));
					kg_lr_second.SetImage(&noNumberImage_left);
					kg_lr_first.SetImage(&noNumberImage_left);
				}			
				else if(kgs > 9)
				{
					kg_lr_fifth.SetImage(assignImageLeft(kgstring[1]));
					kg_lr_fourth.SetImage(assignImageLeft(kgstring[0]));
					kg_lr_third.SetImage(&zeroImage_left);
					kg_lr_second.SetImage(&noNumberImage_left);
					kg_lr_first.SetImage(&noNumberImage_left);
				}
				else
				{
					kg_lr_fifth.SetImage(assignImageLeft(kgstring[0]));
					kg_lr_fourth.SetImage(&zeroImage_left);
					kg_lr_third.SetImage(&zeroImage_left);
					kg_lr_second.SetImage(&noNumberImage_left);
					kg_lr_first.SetImage(&noNumberImage_left);
				}
				
				if(kgs == 0)
				{
					kg_lr_fifth.SetImage(&zeroImage_left);
					kg_lr_fourth.SetImage(&zeroImage_left);
					kg_lr_third.SetImage(&zeroImage_left);
					kg_lr_second.SetImage(&noNumberImage_left);
					kg_lr_first.SetImage(&noNumberImage_left);
				}
				
				
				lbs = (int)((lr_weight*2.20462262)*100);
				lbstring = formatData(lbs);
				
				if(lbs<0)
					lbs=0;
					
				if(lbs > 9999)
				{
					lb_lr_fifth.SetImage(assignImageLeft(lbstring[4]));
					lb_lr_fourth.SetImage(assignImageLeft(lbstring[3]));
					lb_lr_third.SetImage(assignImageLeft(lbstring[2]));
					lb_lr_second.SetImage(assignImageLeft(lbstring[1]));
					lb_lr_first.SetImage(assignImageLeft(lbstring[0]));
				}
				else if(lbs > 999)
				{
					lb_lr_fifth.SetImage(assignImageLeft(lbstring[3]));
					lb_lr_fourth.SetImage(assignImageLeft(lbstring[2]));
					lb_lr_third.SetImage(assignImageLeft(lbstring[1]));
					lb_lr_second.SetImage(assignImageLeft(lbstring[0]));
					lb_lr_first.SetImage(&noNumberImage_left);
				}
				else if(lbs > 99)
				{
					lb_lr_fifth.SetImage(assignImageLeft(lbstring[2]));
					lb_lr_fourth.SetImage(assignImageLeft(lbstring[1]));
					lb_lr_third.SetImage(assignImageLeft(lbstring[0]));
					lb_lr_second.SetImage(&noNumberImage_left);
					lb_lr_first.SetImage(&noNumberImage_left);
				}
				else if(lbs > 9)
				{
					lb_lr_fifth.SetImage(assignImageLeft(lbstring[1]));
					lb_lr_fourth.SetImage(assignImageLeft(lbstring[0]));
					lb_lr_third.SetImage(&zeroImage_left);
					lb_lr_second.SetImage(&noNumberImage_left);
					lb_lr_first.SetImage(&noNumberImage_left);
				}
				else
				{
					lb_lr_fifth.SetImage(assignImageLeft(lbstring[0]));
					lb_lr_fourth.SetImage(&zeroImage_left);
					lb_lr_third.SetImage(&zeroImage_left);
					lb_lr_second.SetImage(&noNumberImage_left);
					lb_lr_first.SetImage(&noNumberImage_left);
				}
				
				if(lbs == 0)
				{
					lb_lr_fifth.SetImage(&zeroImage_left);
					lb_lr_fourth.SetImage(&zeroImage_left);
					lb_lr_third.SetImage(&zeroImage_left);
					lb_lr_second.SetImage(&noNumberImage_left);
					lb_lr_first.SetImage(&noNumberImage_left);
				}			
				
				
				x_hair.SetPosition(322+(exp.wb.x*7),233+(exp.wb.y*4));
				
				
				if(cursor.CollidesWith(&backButton))
				{ 	
					backButton.SetImage(&back_in_Image);
					backButton.SetZoom(1.2);
					if(!backActions)
					{
						WPAD_Rumble(0,1);
						rumbling = true;
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 11000, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
						backActions = true;
					}
					if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_A)
					{
						option = "main";
						ASND_SetVoice(SND_GetFirstUnusedVoice(), VOICE_MONO_16BIT, 22100, 0, (char *) effect3_wav, effect3_wav_size, 200, 200, NULL);
					}
				}
				else 
				{ 	
					backButton.SetImage(&back_out_Image);
					backButton.SetZoom(1);
					backActions = false;
				}
				pro.Draw(0,-13);		
			}
			
			gameWin.Flush();		
			
			//Fading & Zooming effects
			if (!foundBB)
			{
				if(decreasing)
				{
					transFade-=2;
					zooming-=.008;
					if(zooming < 0)
						zooming = 0;
				}
				if(!decreasing)
				{
					transFade+=2;
					zooming+=.008;
				}
				if(transFade >= 253)
					decreasing = true;
				if(transFade < 127)
					decreasing = false;
			}
			
			//If 'HOME' is EVER pressed, we exit!
			if(WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_HOME)
				running=false;		
				
			if(counter < 3 && rumbling)
			{			
				counter++;			
			}
			else
			{
				counter = 0;
				WPAD_Rumble(0,0);
				rumbling = false;
			}
			
			if((WPAD_ButtonsHeld(WPAD_CHAN_0) & WPAD_BUTTON_MINUS) && (WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_PLUS))
			{
				//Reset the video for pure console readouts
				console_init(xfb,20,20,rmode->fbWidth,rmode->xfbHeight,rmode->fbWidth*VI_DISPLAY_PIX_SZ);
				VIDEO_Configure(rmode);
				VIDEO_SetBlack(false);
				VIDEO_SetNextFramebuffer(xfb);	
				VIDEO_Flush();
				VIDEO_WaitVSync();
				if(rmode->viTVMode&VI_NON_INTERLACE) 
					VIDEO_WaitVSync();
					
				debugging = true;
			}
			
		}
		else
		{			
			printf("\x1b[2;0H");
			
			printf("\nCURRENT READOUTS OF ALL AVAILABLE BOARD DATA: \n\n");
			
			printf("Weight Top Left: KG: %f LB: %f    \n", exp.wb.tl, exp.wb.tl*2.20462262); 
			printf("Weight Top Right: KG: %f LB: %f    \n", exp.wb.tr, exp.wb.tr*2.20462262);
			printf("Weight Bottom Left: KG: %f LB: %f    \n", exp.wb.bl, exp.wb.bl*2.20462262);
			printf("Weight Bottom Right: KG: %f LB: %f    \n\n", exp.wb.br, exp.wb.br*2.20462262);
			
			printf("TOTAL WEIGHT: KG: %f LB: %f    \n\n", exp.wb.tl+exp.wb.tr+exp.wb.bl+exp.wb.br, (exp.wb.tl+exp.wb.tr+exp.wb.bl+exp.wb.br)*2.20462);
			
			printf("Raw Data Top Left: %d    \n", exp.wb.rtl); 
			printf("Raw Data Top Right: %d    \n", exp.wb.rtr);
			printf("Raw Data Bottom Left: %d    \n", exp.wb.rbl);
			printf("Raw Data Bottom Right: %d    \n\n", exp.wb.rbr);
			
			printf("Calibration Data Top Left: %d    \n", exp.wb.ctl[3]); 
			printf("Calibration Data Top Right: %d    \n", exp.wb.ctr[3]);
			printf("Calibration Data Bottom Left: %d    \n", exp.wb.cbl[3]);
			printf("Calibration Data Bottom Right: %d    \n\n", exp.wb.cbr[3]);
			
			printf("Position X: %f    \n", exp.wb.x);
			printf("Position Y: %f    \n", exp.wb.y*(-1));	

			if((WPAD_ButtonsHeld(WPAD_CHAN_0) & WPAD_BUTTON_MINUS) && (WPAD_ButtonsDown(WPAD_CHAN_0) & WPAD_BUTTON_PLUS))
			{
				debugging = false;
			}
		}
		
	}
	
	//Exiting...
	WPAD_Disconnect(WPAD_CHAN_0);
	//WPAD_Disconnect(bbport);
	return 0;
}


