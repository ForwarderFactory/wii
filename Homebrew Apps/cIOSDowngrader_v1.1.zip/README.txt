+------------------------------------+
|   [+] Custom IOS Downgrader v1.1   |
|       developed by Waninkoko       |
+------------------------------------+
|       wwww.teknoconsolas.info      |
+------------------------------------+


[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.


[ DESCRIPTION ]:

- This application allows you to downgrade your Wii firmware to any
  available version.

  Also it allows you to change the Wii console region to match the
  new installed firmware region.


[ REQUISITES ]:

- Custom IOS37 rev 03 or higher.
- Internet connection.


[ HOW TO USE ]:

- Run the application and select the firmware to install.


[ KUDOS ]:

- Team Twiizers and devkitPRO devs for their great work in libogc.
- All the betatesters.
- nitrotux, for his IOS5.
