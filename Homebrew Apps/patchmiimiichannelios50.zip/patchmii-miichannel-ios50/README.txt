Shop Channel and IOS51 Installer
by tona

Since so many people have been yelling about "Oh noes, the updates are the
fear! And how will I ever purchase legal Wii content again!" I decided
to whip up a quick 'n' pretty (dirty) installer for the shop channel
and IOS51. You can choose to install the latest IOS51, the latest shop 
channel, or both. 

Please be warned that this release will *always* grab the latest IOS51
and shop channel, even a year from now. The version numbers are not
hard coded.

I tried it once and it seemed to work just dandy. Just make sure you don't
have weird region settings and whatnot. It seems rather picky this time around.
I'm still testing things out with it.


Slight update:
I've added the Signature Hash Checking patch now.
It's not worth much, but I'm sure people will say "Yay!"
You can choose whether or not to apply this patch.

(c) 2008 tona / the internet