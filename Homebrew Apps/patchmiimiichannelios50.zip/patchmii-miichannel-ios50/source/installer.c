/*-------------------------------------------------------------

installer.c -- simple one-use application to install
 IOS50 
 
Copyright (C) 2008 tona
Modified by Requiem for IOS50 and Mii Channel
 
This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any
damages arising from the use of this software.
 
Permission is granted to anyone to use this software for any
purpose, including commercial applications, and to alter it and
redistribute it freely, subject to the following restrictions:
 
1.The origin of this software must not be misrepresented; you
must not claim that you wrote the original software. If you use
this software in a product, an acknowledgment in the product
documentation would be appreciated but is not required.
 
2.Altered source versions must be plainly marked as such, and
must not be misrepresented as being the original software.
 
3.This notice may not be removed or altered from any source
distribution.
 
-------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <gccore.h>
#include <wiiuse/wpad.h>

#include "wiibasics.h"
#include "patchmii_core.h"

//---------------------------------------------------------------------------------
int main(int argc, char **argv) {
//---------------------------------------------------------------------------------
	int ret = 0;
    
	//ret = IOS_ReloadIOS(35);
	
	basicInit();
	WPAD_Init();
	
    printf("\x1b[2J\n\n");
	printf("IOS50 and Mii Channel installer:\n");
    patchmii_network_init();
	printf("Network initialized.\n");
    
    printf("\nAre you sure you want to install IOS50?\n");
    if (yes_or_no()) {
        printf("Patch Sig Hash Check in IOS50?\n");
        ret = patchmii_install(1, 50, 0, 1, 50, 0, yes_or_no());
        if (ret < 0) {
            printf("Something failed. Sorry.\n");
            printf("Press any key to quit.\n");
            wait_anyKey();
            exit(1);
        }
        printf("Press any key to continue");
        wait_anyKey();
    }
   
    printf("\nAre you sure you want to install the latest Mii Channel?\n");
    if (yes_or_no()) {
        ret = patchmii_install(0x10002, 0x48414341, 0, 0x10002, 0x48414341, 0, 0);
        if (ret < 0) {
            printf("Something failed. Sorry.\n");
            printf("Press any key to quit.\n");
            wait_anyKey();
            exit(1);
        }
    }

    printf("Press any key to exit.\n");
    wait_anyKey();
    
	//STM_RebootSystem();
	return 0;
}
