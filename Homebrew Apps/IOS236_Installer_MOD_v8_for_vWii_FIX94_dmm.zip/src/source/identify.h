#ifdef __cplusplus
extern "C"
{
#endif

#ifndef _PATCHER_H_
#define _PATCHER_H_

void Patch_AHB();
void PatchIOS(bool enable);

#endif

#ifdef __cplusplus
}
#endif
