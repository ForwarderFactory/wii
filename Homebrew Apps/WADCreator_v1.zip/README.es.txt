+--------------------------------+
|   [+] WAD Creator v1.0         |
|       developed by Waninkoko   |
+--------------------------------+
|     wwww.teknoconsolas.es      |
+--------------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DA�O EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- WAD Creator es una aplicacion que permite extraer cualquier titulo (aplicacion)
  instalado en la Nintendo Wii a un dispositivo de almacenamiento en formato WAD.


[ REQUISITOS ]:

- Custom IOS36 rev 09 o superior.


[ COMO USARLO ]:

- Ejecuta la aplicacion con cualquier metodo de carga de homebrew. Elige el titulo
  a extraer de la lista y selecciona el dispositivo de almacenamiento donde quieres
  guardarlo.


[ KUDOS ]:

- Team Twiizers y devkitPRO devs por su gran trabajo en libogc.
- Todos los betatesters.