+--------------------------------+
|   [+] WAD Creator v1.0         |
|       developed by Waninkoko   |
+--------------------------------+
|     wwww.teknoconsolas.es      |
+--------------------------------+


[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.


[ DESCRIPTION ]:

- WAD Creator is an application that allows you to extract any title (application)
  installed on the Nintendo Wii to a storage device in WAD format.


[ REQUISITES ]:

- Custom IOS36 rev 09 or above.


[ HOW TO USE ]:

- Run the application with any method to load homebrew. Choose the title you want to
  extract from the list and select the storage device where you want to save it.


[ KUDOS ]:

- Team Twiizers and devkitPRO devs for their great work in libogc.
- All the betatesters.
