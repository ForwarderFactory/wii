// "GoSub" Demo v0.1
// Copyright (C) 2010 Chris Read

#include "libgccvb.h"
#include "treasurechar.h"
#include "treasuremap.h"
#include "smallsubchar.h"
#include "smallsubmap.h"
#include "font.h"
#include "submarinemap.h"
#include "submarinechar.h"
#include "gosublogochar.h"
#include "gosublogomap.h"
#include "coralchar.h"
#include "level1map.h"
#include "level2map.h"
#include "level3map.h"
#include "level4map.h"
#include "level5map.h"
#include "level6amap.h"
#include "level6bmap.h"
#include "level7amap.h"
#include "level7bmap.h"
#include "level8amap.h"
#include "level8bmap.h"
#include "level9map.h"
#include "level10map.h"
#include "level11map.h"
#include "level12map.h"


int u=0;



	int a=0;





/*////////////////////////////
// Functions /////////////////
////////////////////////////*/

	int vert=0, horz=0, xpos=11, ypos=160, lives=3, level=1; // the level setting here doesn't matter.
	int treasurexpos=334, treasureypos=166, bgmap=1, b=2, sub_width=48, sub_height=48;
	int c=513, d=0, level6timer=1, e=0, level_select=0, f=0, g=1, h=0;
	int i=0, j=0, octox=200, octoy=70, octohorz=0, octovert=0, k=0, l=0;
	int p=0, q=0, r=0;

	// int z=362436069, w=521288629, jsr=123456789, jcong=380116160;
	// int t=0, v=0;

 	HWORD getBGMapChar(bgmap, x, y)
    	{ 
     	return (BGMM[(0x1000) + (y * 64) + x]&0x7FF);  
    	} 

 

int main ()




{	
	char lives_str[3];
	char level_str[3];

	// copymem(destination address, source address, number of bytes)
	copymem ((void*)CharSeg3, (void*)FONT, 8192);



	vbSetWorld(31, WRLD_ON, 119, 0, 50, 0, 0, 0, 384, 224);
	vbSetWorld(30, WRLD_ON|1, 101, 0, 0, 0, 0, 0, 384, 224);

	WORLD_SET_HEAD(25, WRLD_END);

	vbDisplayOn();
	vbDisplayShow();

	// Fading in has been used to death, so I just set the brightness directly... ;)
	VIP_REGS[BRTA] = 32;
	VIP_REGS[BRTB] = 64;
	VIP_REGS[BRTC] = 32;
	// line 50

        vbTextOut(0, 1, 7,"IMPORTANT:");
        vbTextOut(0, 1, 8,"READ INSTRUCTION AND");
        vbTextOut(0, 1, 9,"PRECAUTION BOOKLETS");
        vbTextOut(0, 1, 10,"BEFORE OPERATING");



	{
	while(!(vbReadPad()&K_ANY)){}
	while(vbReadPad()&K_ANY);
	}



start_1:

	copymem((void*)CharSeg1, (void*)GOSUBLOGOCHAR, 256*16);
	copymem((void*)BGMap(1), (void*)GOSUBLOGOMAP, 256*16);

 	level=1, k=0, r=0;
	vbSetWorld(26, WRLD_ON, 0, 0, 0, 0, 0, 0, 0, 0);
	vbSetWorld(30, WRLD_ON|1, 0, 0, 0, 0, 0, 0, 0, 0);
	vbSetWorld(29, WRLD_ON|2, 0, 0, 0, 0, 0, 0, 0, 0);
	vbSetWorld(31, WRLD_ON, 119, 0, 50, 0, 0, 0, 384, 224);
	vbSetWorld(28, WRLD_ON|1, 101, 0, 0, 0, 0, 0, 384, 224);
	vbSetWorld(27, WRLD_ON|1, 0, 0, 0, 0, 0, 0, 0, 0);
	lives=3;

	copymem((void*)CharSeg0, (void*)SUBMARINECHAR, 256*16);
	copymem((void*)BGMap(0), (void*)SUBMARINEMAP, 256*16);



start:
	octox=200, octoy=70;
	vbTextOut(0, 1, 16,"/2010 AEGIS GAMES");
	if(vbReadPad()&(K_SEL)) goto choose_level;
	if(vbReadPad()&(K_STA)) goto begin_game;
	goto start;

  	// while(!(vbReadPad()&K_STA)){}
	// while(vbReadPad()&K_STA);


	{

begin_game:

	vbFXFadeOut(2);
	vbSetWorld(28, WRLD_ON|3, 0, 0, 0, 0, 0, 0, 0, 0);
	vbSetWorld(31, WRLD_ON, xpos, 0, ypos, 0, 0, 0, 384, 224);	// sub
	vbSetWorld(30, WRLD_ON|3, 0, 0, 0, 0, 0, 0, 384, 224);		// text
	// vbSetWorld(26, WRLD_ON, octox, 0, octoy, 0, 0, 0, 384, 224);	// octopus
	vbSetWorld(27, WRLD_ON|1, 0, 0, 22, 0, 0, 0, 384, 224);		// mazes 
	vbSetWorld(29, WRLD_ON|2, treasurexpos, 0, treasureypos, 0, 0, 0, 384, 224);	// treasure
	lives=3;
	if (level==22) treasurexpos=220;
	if (level==23) treasurexpos=11, treasureypos=110;

	r=0;

	copymem((void*)CharSeg1, (void*)CORALCHAR, 256*16);

	setmem((void*)BGMap(3), 255, 1024*16);

	// copymem((void*)CharSeg0, (void*)OCTOPUSCHAR, 256*16);
	// copymem((void*)BGMap(0), (void*)OCTOPUSMAP, 256*16);

	copymem((void*)CharSeg0, (void*)SMALLSUBCHAR, 256*16);
	copymem((void*)BGMap(0), (void*)SMALLSUBMAP, 256*16);

	copymem((void*)CharSeg2, (void*)TREASURECHAR, 256*16);
	copymem((void*)BGMap(2), (void*)TREASUREMAP, 256*16);



	if (level_select==1) 	
	{
	// vbFXFadeOut(1);
	vbTextOut(3, 7, 1,lives_str);
	vbTextOut(3, 16, 1,level_str);
	goto start_secret;
	}
	vbTextOut(3, 1, 1,"LIVES");
	vbTextOut(3, 10, 1,"LEVEL");
	level_str[2]=0;
	lives_str[2]=0;

	level_str[0]=(level/10)+'0';
	level_str[1]=(level%10)+'0';
	lives_str[0]=(lives/10)+'0';
	lives_str[1]=(lives%10)+'0';
	vbTextOut(3, 7, 1,lives_str);
	vbTextOut(3, 16, 1,level_str);


	// vbFXFadeIn(2);
	


	}

	while(1)
	{



	vbTextOut(3, 1, 1,"LIVES");
	vbTextOut(3, 10, 1,"LEVEL");

	level_str[2]=0;
	lives_str[2]=0;

	level_str[0]=(level/10)+'0';
	level_str[1]=(level%10)+'0';
	lives_str[0]=(lives/10)+'0';
	lives_str[1]=(lives%10)+'0';
	vbTextOut(3, 7, 1,lives_str);
	vbTextOut(3, 16, 1,level_str);



	l=0;
	
	goto choose_levels;
	 
	{

	// goto choose_levels;


start_2:
	vbFXFadeOut(2);
	level6timer=1;
        level=level+1;
	l=0, k=0;
	octox=200, octoy=70;
	horz=0, vert=0, lives=3;	
	



start_secret:
	
	lives=3;

	level_str[2]=0;
	lives_str[2]=0;

	vbTextOut(3, 7, 1,lives_str);

	level_str[0]=(level/10)+'0';
	level_str[1]=(level%10)+'0';
	lives_str[0]=(lives/10)+'0';
	lives_str[1]=(lives%10)+'0';

	vbTextOut(3, 1, 1,"LIVES");
	vbTextOut(3, 10, 1,"LEVEL");

	d=0;
	xpos=12, ypos=161;



	vbSetWorld(29, WRLD_ON|2, treasurexpos, 0, treasureypos, 0, 0, 0, 384, 224);	// treasure
	vbSetWorld(30, WRLD_ON|3, 0, 0, 0, 0, 0, 0, 384, 224);		// text
	vbSetWorld(27, WRLD_ON|1, 0, 0, 22, 0, 0, 0, 384, 224);		// mazes 
	// vbSetWorld(26, WRLD_ON, octox, 0, octoy, 0, 0, 0, 384, 224);	// octopus
	vbSetWorld(31, WRLD_ON, xpos, 0, ypos, 0, 0, 0, 384, 224);	// sub
	


choose_levels:
	
	if (level==1) copymem((void*)BGMap(1), (void*)LEVEL1MAP, 256*16); 
	if (level==2) copymem((void*)BGMap(1), (void*)LEVEL2MAP, 256*16), k=1; 
	if (level==3) copymem((void*)BGMap(1), (void*)LEVEL3MAP, 256*16), k=1;
	if (level==4) copymem((void*)BGMap(1), (void*)LEVEL4MAP, 256*16), k=1;
	if (level==5) copymem((void*)BGMap(1), (void*)LEVEL5MAP, 256*16), k=1;
	if (level==8) copymem((void*)BGMap(1), (void*)LEVEL5MAP, 256*16), k=1;
	if (level==9) copymem((void*)BGMap(1), (void*)LEVEL9MAP, 256*16), k=1;
	// if (level==10) copymem((void*)BGMap(1), (void*)LEVEL10MAP, 256*16), k=1;
	// if (level==11) copymem((void*)BGMap(1), (void*)LEVEL11MAP, 256*16), k=1;
	// if (level==12) copymem((void*)BGMap(1), (void*)LEVEL12MAP, 256*16), k=1;
	
	if (k==0) l=1;
	if (k==0) goto k_equals_1;
	vbTextOut(3, 7, 1,lives_str);
	vbTextOut(3, 16, 1,level_str);
	vbFXFadeIn(2);
	}


		


k_equals_1:


	vbTextOut(3, 1, 1,"LIVES");
	vbTextOut(3, 10, 1,"LEVEL");

	level_str[2]=0;
	lives_str[2]=0;

	level_str[0]=(level/10)+'0';
	level_str[1]=(level%10)+'0';
	lives_str[0]=(lives/10)+'0';
	lives_str[1]=(lives%10)+'0';





	vbTextOut(3, 7, 1,lives_str);
	vbTextOut(3, 16, 1,level_str);

	
	if (level6timer>0 && level==6) copymem((void*)BGMap(1), (void*)LEVEL6AMAP, 256*16);
	if (level6timer>70 && level==6) copymem((void*)BGMap(1), (void*)LEVEL6BMAP, 256*16);
	if (level6timer>0 && level==7) copymem((void*)BGMap(1), (void*)LEVEL7AMAP, 256*16);
	if (level6timer>70 && level==7) copymem((void*)BGMap(1), (void*)LEVEL7BMAP, 256*16);


	if (l==1) vbFXFadeIn(2);
	if (l==1) l=0;

	
		// walls collision



	if (getBGMapChar(1, (xpos/8)+0, (ypos/8)+2)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+1, (ypos/8)+2)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+2, (ypos/8)+2)==512) j=1;
 	if (getBGMapChar(1, (xpos/8)+3, (ypos/8)+2)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+4, (ypos/8)+2)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+5, (ypos/8)+2)==512) j=1;

	if (getBGMapChar(1, (xpos/8)+0, (ypos/8)+1)==512) j=1;
	// if (getBGMapChar(1, (xpos/8)+1, (ypos/8)+1)==512) j=1;
	// if (getBGMapChar(1, (xpos/8)+2, (ypos/8)+1)==512) j=1;
 	// if (getBGMapChar(1, (xpos/8)+3, (ypos/8)+1)==512) j=1;
	// if (getBGMapChar(1, (xpos/8)+4, (ypos/8)+1)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+5, (ypos/8)+1)==512) j=1;

	if (getBGMapChar(1, (xpos/8)+0, (ypos/8)+0)==512) j=1;
	// if (getBGMapChar(1, (xpos/8)+1, (ypos/8)+0)==512) j=1;
	// if (getBGMapChar(1, (xpos/8)+2, (ypos/8)+0)==512) j=1;
 	// if (getBGMapChar(1, (xpos/8)+3, (ypos/8)+0)==512) j=1;
	// if (getBGMapChar(1, (xpos/8)+4, (ypos/8)+0)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+5, (ypos/8)+0)==512) j=1;

	if (getBGMapChar(1, (xpos/8)+2, (ypos/8)-1)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+3, (ypos/8)-1)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+4, (ypos/8)-1)==512) j=1;
	// if (getBGMapChar(1, (xpos/8)+5, (ypos/6)-1)==512) j=1;

	if (getBGMapChar(1, (xpos/8)+2, (ypos/8)-2)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+3, (ypos/8)-2)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+4, (ypos/8)-2)==512) j=1;
	// if (getBGMapChar(1, (xpos/8)+5, (ypos/8)-2)==512) j=1;

	// if (getBGMapChar(1, (xpos/8)+2, (ypos/8)-3)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+3, (ypos/8)-3)==512) j=1;
	if (getBGMapChar(1, (xpos/8)+4, (ypos/8)-3)==512) j=1;
	// if (getBGMapChar(1, (xpos/8)+5, (ypos/8)-3)==512) j=1;

	if (level6timer>280 && level>20) level6timer=1;
	if (level6timer>140 && level<21) level6timer=1;

	// treasure collision
	if ((abs(treasurexpos - xpos) < sub_width-10) && (abs(treasureypos - ypos) < (sub_height-8))) goto start_2;



	vbSetWorld(31, WRLD_ON, xpos, 0, ypos, 0, 0, 0, 384, 224);	// sub
	vbSetWorld(30, WRLD_ON|3, 0, 0, 0, 0, 0, 0, 384, 224);		// text
	// vbSetWorld(26, WRLD_ON, octox, 0, octoy, 0, 0, 0, 384, 224);	// octopus
	vbSetWorld(29, WRLD_ON|2, treasurexpos, 0, treasureypos, 0, 0, 0, 384, 224);	// treasure
	vbSetWorld(27, WRLD_ON|1, 0, 0, 22, 0, 0, 0, 384, 224);		// mazes 








	if(j==1)  lives=lives-1, xpos=12, ypos=161, horz=0, vert=0, d=1, j=0, octox=200, octoy=70;
	if(lives<0) goto start_1;

	if (k==0) level6timer=level6timer+1;


	if(d==1) vbWaitFrame(40);


	d=0;


	
		if(vbReadPad()&(K_LD)) vert=1, horz=0; 
		if(vbReadPad()&(K_LU)) vert=-1, horz=0;
		if(vbReadPad()&(K_LL)) horz=-1, vert=0; 
		if(vbReadPad()&(K_LR)) horz=1, vert=0;






	i=i+1;	
	xpos+=horz;
	ypos+=vert;
	if(i>2) xpos+=horz;
	if(i>2) i=0, ypos+=vert;
	
 	vbWaitFrame(1);

	goto k_equals_1;




	
choose_level:

	copymem((void*)CharSeg0, (void*)SMALLSUBCHAR, 256*16);
	copymem((void*)BGMap(0), (void*)SMALLSUBMAP, 256*16);

	setmem((void*)BGMap(2), 255, 1024*16);
	xpos=85;
	
	level_select=1;

choose_level_main:
	level_str[2]=0;

	level_str[0]=(level/10)+'0';
	level_str[1]=(level%10)+'0';

	vbSetWorld(31, WRLD_ON|3, 119, 0, 50, 0, 0, 0, 384, 224);
	vbSetWorld(30, WRLD_ON|1, 0, 0, 0, 0, 0, 0, 0, 0);
	vbSetWorld(29, WRLD_ON|2, 0, 0, 0, 0, 0, 0, 0, 0);
	vbSetWorld(28, WRLD_ON|1, 0, 0, 0, 0, 0, 0, 0, 0);
	vbSetWorld(27, WRLD_ON, xpos, 0, 150, 0, 0, 0, 384, 224);

	if (g==1 && xpos>300) g=0;
	if (g==0 && xpos<84) g=1;

	if (g==1) xpos=xpos+1, vbWaitFrame(1);
	if (g==0) xpos=xpos-1, vbWaitFrame(1);

	if (f>5) f=0, level=level-1; 
	if (h>5) h=0, level=level+1;

	vbTextOut(3, 1, 1,"START ON LEVEL");
	vbTextOut(3, 16, 1,level_str);
		if(vbReadPad()&(K_LL)) f=f+1;
		if(vbReadPad()&(K_LR)) h=h+1;
		if (level==0) level=9;
		if (level>9) level=1;
		if(vbReadPad()&(K_STA)) goto begin_game;
	goto choose_level_main;

	}
}
	




        
