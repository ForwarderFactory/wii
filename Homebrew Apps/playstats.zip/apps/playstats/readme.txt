*** Playstats v.1.0 ***

Utility for analysing the play history on your Wii.

This can be distributed in any non-chargeable format as long as this notice is retained and no charge is made for this program or anything derived from its source.  No warranty, etc, etc.

Programming and graphics by chris
Modeling by helen
Uses DolLZ, GRRLIB, libpng, libogc, etc.

Bugs, feedback to chris@toxicbreakfast.com

www.toxicbreakfast.com
TOX 010
