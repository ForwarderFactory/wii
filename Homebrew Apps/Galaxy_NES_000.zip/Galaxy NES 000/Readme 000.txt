(This document assumes that whatever
you use to read TXT documents has word
wrap. It really, really should, so
I'm not going to bother making
accomodations if it doesn't)

Release #000

Table of Contents:
     #$00 Quick Notes/Before We Begin
     #$01 Why make this?
     #$02 General Gameplay
     #$03 Controls
     #$04 Modes
     #$05 Known Bugs/Quirks
     #$06 FAQs
     #$07 Possible Features For Future Releases
     
     #$FE Contact
     #$FF Disclaimer

#$00 Quick Notes/Before We Begin:

     I'm proud of you. You actually opened the readme. I can't expect you to actually read all of it. IF NOTHING ELSE, PLEASE READ THE CONTROLS SECTION!(#$03) Specifically its notes on "turret mode". The rest of the game is easy enough to figure out. However, before you report any bugs I'd also appreciate it if you read the Known Bugs section (#$05).

     I'd also like to take the time to say this. Buy "Geometry Wars: Retro Evolved" if you like this game. There's a version for Windows XP and a version for Windows Vista you can buy if you don't have an Xbox 360. (Or you don't have access to the Xbox Live Arcade). They also have versions for DS and Wii. This game is just a watered down version of the super cool arcade shooter with a brilliant visual style. If you like the watered down NES version, you're bound to love the actual game. So I want you to buy it. Though I imagine most people who will find this game will have already bought Geometry Wars: Retro Evolved or its sequel, if you found and enjoy this game and have not yet bought the game it's based on, I would really appreciate it if you did. Here's the url where you can buy the windows versions: http://www.bizarrecreations.com/games/geometry_wars_retro_evolved/windows.php

     I'd consider it a personal favor if you included this readme and the making of.txt (even though there's almost nothing in it) if you feel like distributing/uploading/emailing this. Even if you're just sending it to a friend, please include all the files. Thank you.

     Last but not least... I'm a wordy person. I overexplain stuff. I apologize in advance about that. 

#$01 Why make this?: (Skip if you don't care about rants from the creator. If all you want to do is play, this section's not worth your time)

     I made this because I am an old school gamer. I play almost nothing but games that are at least seven years old. New games have become more and more disappointing to me. But occasionally there is an exception. The first time I played Geometry Wars: Retro Evolved, I absolutely loved it. It more or less looked and played like an old school game. It's got lots of pretty particle effects and rotations that use the power of the Xbox 360, but the core gameplay is very simple. It made me happy that a game like that could still be played and enjoyed by the current generation of gamers. After I played a few rounds, I started thinking, "Wow. This game could totally work on the NES." And after a few more rounds I thought, "I'm going to try to be the one who makes it for NES." 

     I tried to make NES games before, but I always gave up. I tried to do things that were too complex. I basically sucked at NES programming and was trying to make RPGs with multidirectional scrolling, and platformers with highly compressed level data. When I thought through how Geometry Wars could work for the NES, I couldn't really think of anything that I wouldn't be able to do with my newbie assembly knowledge. So I thought, "Why not?" and I started. I made this because I love Geometry Wars, to show respect for a simple game that still appeals to the current generation of gamers, and to prove that NES is still powerful, capable and relevant. (Not that this game is particuarly impressive. I didn't even do anything "tricky" with assembly. The code is really straight forward. Anyone who knows the 6502 assembly language could've made this. It just so happened that "anyone" was me.)

If you're super interested in what went into making this game and what problems I faced, see "making of.txt" which should be included. (Just kidding. There's a making of.txt included, but there's almost nothing in it yet.)

#$02 General Gameplay:

     If you've already played Geometry Wars: Retro Evolved, you know what to do. The Geometry Wars veterans may want to read about the differences between this game and the ones they're used to in the FAQ (#$06) though. Another quick note for those who have played Geometry Wars before: This game is based on Geometry Wars: Retro Evolved from the Xbox Live Arcade. It's not based on the sequel, which actually came out after I started making this. See the FAQ for more info.

     If you've never played Geometry Wars, or have no idea what it is... You're basically a little ship that shoots stuff. Simple really. There are only a few kinds of enemies.

Wanderers (Purple Enemies): They just kind of move around. They don't chase you or anything. Plus they're slow. Shoot them to kill them.

Grunts (Blue Enemies): These chase you. You're faster than them. Shoot them to kill them.

Weavers (Green Enemies): They chase you. You're faster than them... until you shoot at them. They dodge the bullets and move at incredibly high speeds. Shoot them to kill them. (A message to Geometry Wars veterans: I believe the green enemies in the NES game are MUCH scarier than in the official games)

Spinners (Pink Enemies): They chase you. You're faster than them. Shoot them, and two tiny spinners come out. Shoot the tiny spinners to kill them.

Snakes (Blue Head, Yellow Tail Pieces): They chase you. A segmented tail follows them. If a bullet hits a tail piece, the bullet is destroyed and the snake is left unharmed. Shoot the head to kill them.

Repulsars (Red Enemies with Red Shields): They chase you for a little, then stop. They have a shield that protects them from your bullets. They're also quite fast. Shoot the Repulsar and not the shield to kill them.

Mayflies (Light Blue triangle-looking enemies): They chase you. They warp around a little. Shoot them to kill them, but keep in mind bullets don't go through them like other enemies. If one is killed, the bullet that killed it is also destroyed.

Note: You can also kill all the enemies on screen by using a bomb, but it does not award you any points.

     The gameplay revolves around shooting enemies trying to get a high score you can brag about online where no one believes you didn't cheat. The large number in the top left is your score. The number to the right of that is the number of lives you have left. The number to the right of that is the number of bombs you have left.

#$03 Controls:

     I'm not gonna lie. The controls take a little time to get used to. Here they are:

     D-Pad: Moves the ship and highlights menu options (Left and Right only control horizontal movement. Up and down only control vertical movement. See the quirks section [#$05] for an example of what this means.)

     A Button: Shoots Forwards (You can hold it down instead of rapidly pressing it) and selects menu options

     B Button: Shoots Backwards (You can hold it down instead of rapidly pressing it) and selects menu options

     Select: Uses a bomb. You cannot use a bomb while you are flashing invincible after dying. Also ends the current game and goes back to the title screen when the game is paused.

     Start: Pauses/unpauses the game. Also selects menu options and returns the game to the titlescreen after you lose all your lives.

     Hold Down the A and B Buttons: Enter "Turret Mode" (Explained below)

     Turret Mode: When you enter turret mode, your ship stops moving. You can then use the d-pad to shoot all around you. If you let go of the A or the B button, you'll exit turret mode. If you let go of the B button first, your ship will start travelling in the direction you're shooting. If you let go of the A button first, your ship will not move until you move in a direction with the d-pad. Even if you don't use it to shoot, entering then immediately exiting turret mode can be useful if you want to stop your ship from moving quickly. 

     Shooting outside of turret mode is based on the direction you're travelling. If you're moving very slowly horizontally, your bullets will move slowly horizontally. This allows for joystick style shooting with a d-pad. It's the best I could do, so I apologize in advance if you hate it. 

#$04 Modes:

     One Player:

          In One Player, you battle the enemies alone. You can play One Player with either controller. Simply Press A or Start with One Player selected on the controller you would like to play with. Losing a life when you have one life left ends the game. There can only be five bullets on the screen at a time.

     Two Players:

          In Two Players, you and a friend work together to get a high score. Whoever presses A or Start with Two Players selected on the menu becomes first player. Enemies only chase first player. However, enemies can spawn on top of second player. Both players share lives and bombs. If either player dies the multiplier is reset. Also, there can only be five bullets on screen at a time, so alternate between who's shooting if it's needed. Player Two should focus on protecting Player One. The game ends when both players die once when the lives counter reads zero.


     Secret Mode (Controls Test):

          Activated by a super secret cheat code. It can be played by one or two players. It allows for 62 bullets on screen at once. Bullets are not destroyed as they leave the screen. They wrap around instead. There are no enemies. The only thing this mode is really good for is making neat bullet patterns. I've thrown it in as a fun little thing to look for when you're bored. This secret mode also allows you to see what version of the game you're currently playing in the bombs counter, but since this is the only release at the moment, I feel no need to give the code to you.

#$05 Known Bugs/Quirks:

     These are just the ones I can think of off the top of my head. I'm aware of a lot of things I don't know how to fix. :(

Bugs: (That I'm Aware Can Still Happen)
     1. Sometimes killing a snake will get rid of another snake's tail pieces, or get rid of a Repulsar's shield. I may not fix this. I don't see it as a big deal.
     2. Likewise, killing a Repulsar may get rid of a snake's tail pieces or another Repulsar's shield. This also keeps the Repulsar from updating which direction it's facing. It's most possible whenever more than one Repulsar is on screen. (It's actually possible for a Repulsar enemy to lose its shield with just one enemy. I did my best. These things can still happen).
     3. The Title Screen Flashes when you press Start or A to bring up the menu.
     4. Things related to enemies dying are bugged. When you kill an enemy its velocity might be transfered to another enemy. And when you kill an enemy, the multiplier indicator (x 2) might show up in the wrong place. I'm really not sure why this is. If I could figure it out, it'd probably also fix bug #1 and bug #2.
     5. In two player mode when one player is completely dead and the remaining player gains an extra life, it's supposed to bring the dead player back to life. After this (Or maybe it even happens without bringing a dead player back) occasionally having one of the players die again will kill both players. I have no idea why this happens, or how to make it happen consistently. If you can make it happen consistenly, let me know how. (Section #$FE)


Bugs: (That can in theory still happen, but they most likely won't.)
          If you ever run into any of these bugs in normal gameplay make a savestate and contact me. (See section #$FE)

     1. Occasionally killing a snake will not kill the tail pieces following it. This results in some unkillable obstacles on the playfield. I can only think through ONE way this could ever happen, and it will probably NEVER come up in normal gameplay. I've never had it happen in the current release, even when deliberately trying to make it happen with debug mode, but I still believe it's possible. If this ever DOES happen, you can get rid of them by using a bomb, but please remember to pause and make me a savestate first.
	 2. If you kill a LOT of enemies in a single frame, you may not get all the points you earned, and it'll most likely cause the score counter to lose a number giving you "impossible" scores. (Like the last two digits are 40, instead of 50, or 65 instead of 75. It may also end in 9 or something equally weird.). It's more likely to happen when the multiplier is higher. I think I fixed all the causes of this, but I'm only 98% sure. So don't be too surprised if you get a weird score like 1,919 or something. I tried my best on this one. But I think it can still happen.
     3. When snakes or repulsars spawn, they may be able to replace your ship sprite. That means your game is instantly over. I'm actually pretty sure this one can't happen, but you've been warned. 
     4. It's probably possible to get cheated out of extra lives/bombs. You should get a bomb every 100,000 points, and a life every 75,000 points. (Though you can never have more than nine. This is intentional.) I did all the reasonable checks I could think of, but it's probably still possible. Want more bad news? Missing one means missing roughly eight more. Then the checks (should) right themselves.


Quirks: (Things you may think are bugs, but they aren't.)
     1. In Two Player mode all the enemies chase Player 1. I can't come up with a good way to make them follow both players that doesn't slow the NES down. Sorry.
     2. You're travelling (or shooting in turret mode) diagonally downward to the right. You want to move (or shoot in turret mode) straight downward. You press down and nothing happens. Up and down only control vertical movement. Left and right only control horizontol movement. So in the situation described above pressing down would not stop you from travelling right. I may change this eventually... but it's probably more trouble than it's worth. 
     3. When there are 8 objects in the same 8 x 8 pixel horizontal line, additional objects (Be they enemies, bullets or whatever) won't show up. While this is technically a limitation with the actual NES as opposed to my program, I felt compelled to list it here. It IS possible for me to get around this limitation, but I need a fast way to do it, because this program already saps a lot of NES processing power with a lot of enemies on screen. I rarely see it as a problem since the enemies you can't see tend to just group together with ones you can. It's something on the list to "fix" but not a real priority as of now. Keep in mind that some emulators have an option to disable this limitation. Since I imagine the majority of you will be playing this on an emulator anyway, I recommend NesterJ or Nestopia (There's a Macintosh version of Nestopia!)as an emulator that allows you to have more sprites in a horizontal line. If you want to see how the game would display on a real NES, try Nintendulator (My first choice) or Nestopia (with the previously mention option disabled of course). If you're using Nesticle, please delete it from your computer. It's no longer considered any good. This game may not even run on it. (I don't know. I haven't tried).
     4. When there are a lot of enemies on screen, you may see a white dot indicating an enemy is about to spawn, but nothing ever comes out of the white dot. This means either a snake or repulsar was about to spawn, but it couldn't because there were already too many enemies on screen. (Both Snakes and Repulsars use more than one sprite, which is why this only happens with them)
     5. Your bullets have more range than it looks like. They're 2 by 2 pixels, but their collision box is 8 by 8 pixels. It's really nothing to complain about. Also, the mini pink enemies have more range then they appear. You should never be flying close enough to an enemy that this would matter, but at least now you know about it.
     6. The direction your ship is facing has nothing to do with the direction you're travelling. It simply changes depending on what the last direction you pressed was. 

#$06 FAQs:

     1. Which Geometry Wars is this NES game based on?
          This game is based on Geometry Wars: Retro Evolved from the Xbox live arcade. Not its sequel.

     2. What are the differences between this game and Retro Evolved?
          Besides the obvious control differences (NES doesn't even have enough buttons to do controls like the DS version had), these are the differences I can think of. This list will most likely get a lot longer.
               1. The snakes chase you instead of snaking around. I may change this.
               2. There are no gravity wells. There will most likely never be. I can't come up with a fast way to make them work. 
               3. The way enemies spawn is a little different. I took a lot of notes about what scores certain enemies spawned at. I tried my best to make it close, but it's tough and almost not worth the effort. It's hard to take notes while playing the game, and I suck anyway. So I have to take notes while my brother plays, but he's much better, and plays to survive, not for me to take notes. So it's hard to see what exactly appeared when he's killing things as fast as possible. And youtube videos are kinda blurry... :(
               4. When Pink Enemies are killed in Retro Evolved, three mini pink enemies come out of them immediately. When they're killed in this game, just two mini pink enemies come out, and it happens slightly after the enemies are killed.
               5. The Green Enemies don't have a limit on their speed when you're shooting at them, so they can move at VERY high speeds to dodge bullets. This is a decision I had to make, because their bullet dodging subroutine already makes them one of the most CPU intensive enemies. I still find it easy to kill them. You just gotta find a good strategy.
               6. The Snake Enemies can be different lengths in this game. (They may be in the original too. I actually don't know, but I don't think so.)

     3. Why is it called Galaxy Nes? Why not Geometry NES? Or Geometry Wars: Retro Retro etc.
          For two reasons: 
              1. I wanted to use as few graphics blocks as possible for the titlescreen. 11 different 8 by 8 blocks make up the "GALAXY NES" logo. Because I used non specific blocks, I could barely fit Galaxy Nes. Anything else would be too long.
              2. The folder that I keep the source code of this game in has been called "GalaxyNES" since I started the project. I meant to name it "GeometryNES" but I spaced out and put Galaxy. I never changed it.

     4. The grid shakes and rattles when there's a lot of enemies on screen. Can you please remove it?
          I can't. But you can. Hold down select while starting a game to disable the grid. Then you can play on just a black screen where only the score will shake if things get hectic.  But... it doesn't feel much like Geometry Wars then, does it? Sadly, there is no way to disable the grid midgame. I may add a way later.

     5. Can I add you on Xbox Live/Will you add me on Xbox Live?
          No. 
		  
     6. Can you remake Halo 3/Little Big Planet/Some random game I've never heard of on NES?
          No. I'm not gonna take requests. Making ANY kind of game takes lots of time, and I'm not gonna spend it doing something some stranger wants. 

#$07 Possible Features For Future Releases: (If there are any. I'm rather hesitant about releasing this at all. They're in no particular order)
     1. Further the gameplay. Maybe...? I wanted it to keep getting harder past where it stops in the current build, but I can't think of any ways to do that.
     2. Create new modes? (Ones like deadline and king maybe?) This is unlikely. I've nearly run of space in this rom and I am NOT going to use a mapper any time soon.
     3. Create a control mode for single player that works like the original game. (You'd have to use two controllers. One d-pad for movement. One for shooting.)
     4. Perhaps just add general control options.
     5. Music? There are several things in the way of adding music to this game. Here's the deal: I have a problem (or inhibition or whatever you'd call it) with people I don't know in real life directly contributing to my projects. So I don't want to get a random epic famitracker user from the internet to create music for this. I'm working on recreating the original song myself, but I think my version sounds awful. Another problem is that the famitracker player port to the assembler I use (NESASM. Yes it sucks. Yes I should have used something else. No, I didn't) doesn't seem to work with my songs past a certain point. I may just try to put a short original song in, (Since the player seems to only crash with songs past a certain length) but that kinda defeats the purpose of what I was trying to accomplish with this game.
     6. Sound effects: I don't even pretend to know how to create and good/small sound effects on the NES. They will probably be one of the dead last things I do with this program, if I do them at all.
     7. Pretty effects/animations: Anything that's only related to how the game looks and not related to how the game plays is really low priority right now. This game already slows down with about 40 enemies on the screen, and animating them would just slow the game down more. I can speed the game up by wasting prg-rom with repeated functions so that I don't have to waste cycles by jumping to and returning from subroutines, but that's something I'm only going to do when I feel I'm not going to add that many more things to the game, since it'll drastically reduce the amount of space I have to add stuff. If, and when I do this, I'll consider adding animations since they'll just use the small speed gain I get from wasting prg-rom.
     8. Some form of indication that shows when the game is paused. Right now you might think the game froze, when it's really just paused. 
     9. Saveable high scores, and a high score table. For now you'll have to make due with making screenshots and bragging online.
	 10. Take television "safe area" into account. For those that are playing on a real NES or at least another console emulating the NES (like Wii or Dreamcast), the game is a tad more difficult because cornerspawns happen almost entirely offscreen on a TV. If you're playing on a computer emulator look for an option that will "display all 240 scanlines" to make it easier on yourself.
	 
#$FE Contact

     If you need to contact me, you can do it at nescoder@gmx.com. Do NOT expect fast responses. Have a subject line that allows me to generally understand what you're asking about in the actual email. Be as specific as possible in the actual email, since I don't want a huge back and forth of emails if we could have done it in less time if you'd been specific. If you're sending a bug report, include a save state and the name of the emulator the save state belongs to, as well as any details you can think of like what was happening before the bug happened. Note that I won't help you with NES programming or anything like that, since I don't actually feel very qualified to give advice on that. I just started myself. I would also appreciate if you didn't contact me "just to chat". You can also PM me (Kasumi) on the nesdev forums. http://nesdev.parodius.com/bbs/

#$FF Disclaimer

     I don't own the rights to Geometry Wars. This game should never be sold for profit. If the rights holders of Geometry Wars ask me to remove this game, I will comply. If you choose to host this on your website, you agree to comply that if the rights holders (or I) ask you to remove this game that you will. I won't take responsibility if this file messes up your NES, or your emulator, or your computer, or your marriage. There's no reason it should do any of those things, but if it does you're on your own. 