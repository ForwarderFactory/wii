+---------------------------------------+
|   [+] USB Loader v1.1                 |
|       developed by Waninkoko/kwiirk   |
+---------------------------------------+
|         wwww.teknoconsolas.es         |
+---------------------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DA�O EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- USB Loader es una aplicacion para la Nitendo Wii que te permite
  poder instalar y cargar tus backups desde un dispositivo de
  almacenamiento USB.


[ REQUISITOS ]:

- Custom IOS36 rev 09 o superior.
- Un dispositivo USB con una particion libre para juegos.


[ KUDOS ]:

- Team Twiizers y devkitPRO devs por su gran trabajo en libogc.
- Todos los betatesters.
- kwiirk, por su modulo EHCI.
- neimod, por el Custom IOS module.
