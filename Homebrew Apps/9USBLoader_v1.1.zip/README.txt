+---------------------------------------+
|   [+] USB Loader v1.1                 |
|       developed by Waninkoko/kwiirk   |
+---------------------------------------+
|         wwww.teknoconsolas.es         |
+---------------------------------------+


[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.


[ DESCRIPTION ]:

- USB Loader is a Nintendo Wii application that allows you to install and
  boot your backups from a USB storage device.


[ REQUISITES ]:

- Custom IOS36 rev 09 or above.
- USB device with one free partition for games.


[ KUDOS ]:

- Team Twiizers and devkitPRO devs for their great work in libogc.
- All the betatesters.
- kwiirk, for his EHCI module.
- neimod, for the Custom IOS module.