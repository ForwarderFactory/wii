+-------------------------------+
| WAD Manager v1.3 by Waninkoko |
+-------------------------------+
|    www.teknoconsolas.info     |
+--------------------------------+


[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.


[ DESCRIPTION ]:

- WAD Manager is an application that allows you to (un)install
  WAD packages.

  It lists all the available WAD packages in a storage device
  so you can select which ones to (un)install.


[ SUPPORTED DEVICES ]:

- SDGecko.
- Internal SD slot (with SDHC support).
- USB device.


[ HOW TO USE ]:

1. Create a folder called "wad" in the root of the storage device.
2. Copy all the WAD packages in the folder created in the step 1.
3. Run the application with any method to load homebrew.


[ NOTES ]:

- If a Custom IOS is detected, WAD Manager will load it automatically to
  take advantage of its benefits.


[ KUDOS ]:

- Team Twiizers/devkitPRO -> libogc
- svpe                    -> usbstorage driver
- All my betatesters.
