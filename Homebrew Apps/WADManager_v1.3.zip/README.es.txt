+-------------------------------+
| WAD Manager v1.3 by Waninkoko |
+-------------------------------+
|    www.teknoconsolas.info     |
+-------------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DA�O EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- WAD Manager es una aplicacion que te permite (des)instalar paquetes WAD.

  La aplicacion muestra todos los paquetes WAD disponibles en un
  dispositivo de almacenamiento para asi poder elegir cuales (des)instalar.


[ DISPOSITIVOS SOPORTADOS ]:

- SDGecko.
- Puerto SD interno (con soporte SDHC).
- Dispositivo USB.


[ COMO USARLO ]:

1. Crea un directorio llamado "wad" en la raiz del dispositivo de almacenamiento.
2. Copia todos los paquetes WAD en el directorio creado en el paso 1.
3. Ejecuta la aplicacion con cualquier metodo para cargar homebrew.


[ NOTAS ]:

- Si un Custom IOS es detectado, WAD Manager lo cargara automaticamente para
  poder aprovecharnos de sus ventajas.


[ KUDOS ]:

- Team Twiizers/devkitPRO -> libogc
- svpe                    -> driver usbstorage
- Todos mis betatesters.
