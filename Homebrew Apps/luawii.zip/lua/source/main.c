/*
	When you build lua, you may want to look into the Makefile,
	I don't have a "$(DEVKITPPC)/libogc/ folder, I just put my
	libs in with the other libs, and the other includes similarly.

	Just to throw a spanner in the works there hehe.

	This example loads "test.lua" from the root of your SD card
	and executes it.

	It runs the "test_main" function in the lua file.
*/

#include <ogcsys.h>
#include <ogcsys.h>
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
#include <wiiuse/wpad.h>
#include <fat.h>

GXRModeObj *rmode = NULL;
void *xfb = NULL;

int main(int argc, char **argv)
{
	VIDEO_Init();
	rmode = VIDEO_GetPreferredMode(NULL);
	VIDEO_Configure(rmode);
	xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
   console_init(xfb,20,20,rmode->fbWidth,rmode->xfbHeight,rmode->fbWidth*VI_DISPLAY_PIX_SZ);
	VIDEO_SetNextFramebuffer(xfb);
	VIDEO_SetBlack(FALSE);
	VIDEO_Flush();
	VIDEO_WaitVSync();
	if(rmode->viTVMode&VI_NON_INTERLACE) VIDEO_WaitVSync();
	VIDEO_ClearFrameBuffer (rmode,xfb,COLOR_BLACK);


	WPAD_Init();
	WPAD_SetIdleTimeout(120);
	fatInitDefault();	
	struct lua_State *l = lua_open();
	if(!l)
	{
		printf("\n\n\tFailed to create a Lua state - Push A to Exit\n");
		while(!WPAD_ButtonsDown(0)&WPAD_BUTTON_A)
			WPAD_ScanPads();
		return 0;
	}
	luaL_openlibs(l);
	if(luaL_loadfile(l,"/test.lua"))
	{
		printf("\n\n\tError Occured: Couldn't open /test.lua\n");
		while(!WPAD_ButtonsDown(0)&WPAD_BUTTON_A)
			WPAD_ScanPads();
		return 0;
	}
	
	if(lua_pcall(l,0,0,0)) /* Initial run through of file */
	{
		printf("\n\n\tFailed running file initially - Could be a syntax error\n");
		return 0;
	}

	while(1)
	{
		WPAD_ScanPads();
		lua_getglobal(l,"test_main");
		int err = lua_pcall(l,0,0,0);
		if(err)
		{
			printf("\n\n\tError Occured: %s\n",lua_tostring(l, -1));
			break;
		}
		if(!(WPAD_ButtonsHeld(0)&WPAD_BUTTON_A))
			sleep(2);
		if(WPAD_ButtonsHeld(0)&WPAD_BUTTON_B)
			break;
	}
	printf("Terminated\nPush A To Quit\n");
	while(!(WPAD_ButtonsDown(0)&WPAD_BUTTON_A))
		WPAD_ScanPads();
	return 0;
}
