-- INTRO --

This package contains the following WaninKoKo apps:
* WAD Manager v1.0
* Mii Extractor v1.1
* Mii Installer v1.1
* Savegame Extractor v2.0
* Savegame Installer v2.0
* WAD Installer v2.1
* WAD Uninstaller v1.1

For each app i created it's own icon.png and meta.xml.
Each meta.xml is filled with information from it's own app readme.txt and the icon i created myself.

Hopefully it saves you from a little bit of trouble. 

-- LATEST UPDATE --

Added some more WaninKoKo apps, included the spanish readme's, fixed some minor text bugs and gave the app icons a little tweak.

-- SMALL FAQ --

Q: How do i install these apps on the Homebrew Channel?
A: Please refer to the Homebrew Channel readme.txt

Q: How do i create my own WaninKoKo icon?
A: Checkout the folder /icon.psd. First install the font and then open up icon.psd!

Q: Why did you include the WAD In-/Uninstaller as the WAD Manager is more superior?
A: It's up to you to decide what you put on your SD card!

Q: Why didn't you include WaninKoKo app X?
A: I only included the apps i like ;]

-- OUTRO --

Credit goes to WaninKoKo for his awesome work.
Visit his website at http://wii.waninkoko.info

This package was uploaded at gbatemp.net and last updated on 28-05-2008

GrtZ
sparkle