+---------------------------------+
| Mii Extractor v1.1 by Waninkoko |
+---------------------------------+
|      www.teknoconsolas.info     |
+---------------------------------+


+--------------+
| DESCRIPCION: |
+--------------+

Esta aplicacion extrae todos los Miis de tu Wii
a una tarjeta SD.


+--------------+
| COMO USARLO: |
+--------------+

1. Ejecuta esta aplicacion y todos tus Miis se
   copiaran al directorio "miis" de la tarjeta
   SD.


+--------+
| KUDOS: |
+--------+

- bushing and marcan.
- www.elotrolado.net
