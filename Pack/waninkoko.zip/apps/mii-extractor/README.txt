+---------------------------------+
| Mii Extractor v1.1 by Waninkoko |
+---------------------------------+
|      www.teknoconsolas.info     |
+---------------------------------+


+--------------+
| DESCRIPTION: |
+--------------+

This application extracts all the Mii's from your
Wii to a SD card.


+-------------+
| HOW TO USE: |
+-------------+

1. Just run this application and all your Mii's
   will be copied to the "miis" directory at the
   SD card.


+--------+
| KUDOS: |
+--------+

- bushing and marcan.
- www.elotrolado.net