+--------------------------------------+
| Savegame Extractor v2.0 by Waninkoko |
+--------------------------------------+
|        www.teknoconsolas.info        |
+--------------------------------------+


+--------------+
| DESCRIPCION: |
+--------------+

Esta aplicacion te permite copiar una savegame de
tu Wii a una tarjeta SD (incluso aquellos saves que
no se pueden copiar a traves del menu del sistema).


+--------------+
| COMO USARLO: |
+--------------+

1. Ejecuta esta aplicacion.
2. Inserta el DVD del juego y pulsa el boton RESET o A
   (Wiimote no soportado).


+--------+
| KUDOS: |
+--------+

- bushing and marcan
- danny.ml
- ElOtroLado.net (I like the new look :P)
