+--------------------------------------+
| Savegame Installer v2.0 by Waninkoko |
+--------------------------------------+
|        www.teknoconsolas.info        |
+--------------------------------------+


+--------------+
| DESCRIPTION: |
+--------------+

This application allows you to install a savegame dumped
by the "Savegame Extractor" in your Wii.

(data.bin files not supported).


+-------------+
| HOW TO USE: |
+-------------+

1. Copy the savegame you want to install to the SD card
   (directory "wiisaves/<game id>", just keep the directory
    structure created by the "Savegame Extractor").
2. Run this application.
3. Insert the game DVD and press RESET or A button
   (Wiimote not supported).


+--------+
| KUDOS: |
+--------+

- bushing and marcan
- danny.ml
- ElOtroLado.net (I like the new look :P)
