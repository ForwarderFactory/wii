+--------------------------------------+
| Savegame Installer v2.0 by Waninkoko |
+--------------------------------------+
|        www.teknoconsolas.info        |
+--------------------------------------+


+--------------+
| DESCRIPCION: |
+--------------+

Esta aplicacion te permite instalar los savegames extraidos
por el "Savegame Extractor" en tu Wii.

(los ficheros "data.bin" no estan soportados).


+--------------+
| COMO USARLO: |
+--------------+

1. Copia el savegame que quieras instalar a la tarjeta SD
   (directorio "wiisaves/<id juego>", simplemente deja la
    estructura de directorios creada por el "Savegame Extractor").
2. Ejecuta esta aplicacion.
3. Inserta el DVD del juego y pulsar el boton RESET o A
   (Wiimote no soportado).

+--------+
| KUDOS: |
+--------+

- bushing and marcan
- danny.ml
- ElOtroLado.net (Me gusta el nuevo dise�o :P)
