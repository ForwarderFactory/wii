+---------------------------------+
| WAD Installer v2.1 by Waninkoko |
+---------------------------------+
|      www.teknoconsolas.info     |
+---------------------------------+


+--------------+
| COMO USARLO: |
+--------------+

1. Crea en la raiz de la tarjeta SD una carpeta llamada "wad".
2. Copia los WAD que quieras instalar dentro de la carpeta.
3. Ejecuta la aplicacion.


+--------+
| KUDOS: |
+--------+

- Michael Laforest, por su libreria wiiuse.
- bushing and marcan, por su ayuda.
- A todos los que me ayudaron en el proceso de testeo.


+--------+
| NOTAS: |
+--------+

No hay mas soporte para el Wiimote pero ahora ya puedes apagar
la Wii ;)


+-------------+
| DISCLAIMER: |
+-------------+

�No uses esta aplicacion para instalar software ilegal!
