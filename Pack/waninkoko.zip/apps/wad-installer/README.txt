+---------------------------------+
| WAD Installer v2.1 by Waninkoko |
+---------------------------------+
|      www.teknoconsolas.info     |
+---------------------------------+


+-------------+
| HOW TO USE: |
+-------------+

1. Create a folder called "wad" in the root of the SD card.
2. Copy every WAD you want to install in the "wad" folder.
3. Run this application.


+--------+
| KUDOS: |
+--------+

- Michael Laforest, for the great wiiuse library.
- bushing and marcan, for their help.
- Everybody who helped me in the testing process.


+--------+
| NOTES: |
+--------+

No more Wiimote support but now you can power off your Wii ;)


+-------------+
| DISCLAIMER: |
+-------------+

Do not use this program to install illegal software!
