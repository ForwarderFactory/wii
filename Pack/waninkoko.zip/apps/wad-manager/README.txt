+-------------------------------+
| WAD Manager v1.0 by Waninkoko |
+-------------------------------+
|    www.teknoconsolas.info     |
+-------------------------------+


+--------------+
| DESCRIPTION: |
+--------------+

WAD Manager is an application for (un)install WAD packages.

It lists all the available WAD packages in a SD card so you can
select which ones to (un)install.

Includes Wiimote support.


+-------------+
| HOW TO USE: |
+-------------+

1. Create a folder called "wad" in the root of a SD card.
2. Copy all the WAD packages in the folder created in the step 1.
3. Run the application with any method to load homebrew.


+--------+
| KUDOS: |
+--------+

- bushing and marcan (the homebrew channel is great)
- all my testers (pistu, SoraK05, danny.ml...)
