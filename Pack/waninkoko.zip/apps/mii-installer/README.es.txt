+---------------------------------+
| Mii Installer v1.0 by Waninkoko |
+---------------------------------+
|      www.teknoconsolas.info     |
+---------------------------------+


+--------------+
| DESCRIPCION: |
+--------------+

Esta aplicacion instala todos los Miis almacenados
en una tarjeta SD en tu Wii.


+--------------+
| COMO USARLO: |
+--------------+

1. Crea un directorio llamado "miis" en la raiz
   de una tarjeta SD.

2. Copia todos los Miis que quieras instalar al
   directorio creado en el paso anterior.

3. Ejecuta esta aplicacion y todos tus Miis se
   copiaran de la tarjeta SD a tu Wii.


+--------+
| KUDOS: |
+--------+

- bushing and marcan.
- www.elotrolado.net
