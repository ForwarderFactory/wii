+---------------------------------+
| Mii Installer v1.0 by Waninkoko |
+---------------------------------+
|      www.teknoconsolas.info     |
+---------------------------------+


+--------------+
| DESCRIPTION: |
+--------------+

This application installs all the Mii's from a
SD card to your Wii.


+-------------+
| HOW TO USE: |
+-------------+

1. Create a directory called "miis" in the root
   of a SD card.

2. Copy the Mii's you want to install in the
   directory created in the previous step.

3. Run this application and all your Mii's
   will be copied from the SD card to your Wii.


+--------+
| KUDOS: |
+--------+

- bushing and marcan.
- www.elotrolado.net
