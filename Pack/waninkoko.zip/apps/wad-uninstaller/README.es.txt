+-----------------------------------+
| WAD Uninstaller v1.1 by Waninkoko |
+-----------------------------------+
|       www.teknoconsolas.info      |
+-----------------------------------+


+--------------+
| DESCRIPCION: |
+--------------+

Esta aplicacion desinstala POR COMPLETO (borra los tickets
y los contenidos) de la Wii los titulos especificados.


+--------------+
| COMO USARLO: |
+--------------+

1. Crea en la raiz de la tarjeta SD una carpeta llamada "wad".
2. Copia los WAD que quieras instalar dentro de la carpeta.
3. Ejecuta la aplicacion.


+--------+
| KUDOS: |
+--------+

- bushing and marcan, por su ayuda.
- A todos los que me ayudaron en el proceso de testeo.
