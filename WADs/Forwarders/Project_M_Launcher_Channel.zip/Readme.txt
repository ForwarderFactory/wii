Thank you for downloading my Project M Launcher channel.

This is a Project M styled forwarder channel for Gecko OS, designed for people that have access to the Homebrew Channel and load Project M via a retail copy of Super Smash Bros Brawl. It creates an entirely separate channel onto your Wii Menu and forwards the Gecko OS application in your SD card when opened, so that you can load up Project M  without having to go through the Homebrew channel. While it's not too entirely useful for most people, it does make for a rather unique novelty channel, filling up space and giving your Wii Menu a little something to spice it up.

Included within this download are the following:
-IOS 236 Installer app for the Homebrew Channel
-WAD Manager app for the Homebrew Channel
-Project M Launcher Gecko OS app for the Homebrew channel
-Project M Launcher forwarder channel WAD

Installation Instructions

IMPORTANT NOTE: As a small precaution, please make sure you have no Nintendo Gamecube memory cards or USB devices inserted, as these may cause unintended and/or harmful effects during the installation process. To navigate the menus of the Homebrew apps, you will need a regular Nintendo Wii Remote (without Wii Motion plus) or a Nintendo Gamecube controller plugged into port 1.

(If you already have IOS 236 previously installed, you can skip ahead to Step 5)

Step 1). After the download is finished, extract the folders to the root of your SD card.
Step 2). Turn on your Wii, go to the Homebrew Channel and load the "IOS236 Installer" app.
Step 3). Let the app load for a moment. Press the 1 button whem prompted to, select "Download IOS from NUS", and press A to continue.
Step 4. After a few seconds, there will be an option that asks you if you intend on using this to pirate games, so please press 2, otherwise the application is designed to lock itself from being used. Once finished, exit back to the Homebrew Channel.
Step 5). Once you're in the Homebrew Channel, load the "WAD Manager" app.
Step 6). Press left on the D-pad until IOS 236 is selected, then press A. Select your Wii SD Slot, then scroll down to the "wad" folder and press A to open it.
Step 7). Scroll down some more, press A to select the Project M Launcher WAD file, and press A to install it.
Step 8). After a few seconds, the channel will finish installing. Press A and then HOME to exit to the Homebrew Channel, then press HOME and scroll down to "Exit to System Menu" to exit back to the Wii Menu.

In the closest available empty spot in your Wii Menu, you will have my Project M Launcher channel appear.

I hope you enjoy this channel, as well as Project M and any future updates.

-Xenozoa425

